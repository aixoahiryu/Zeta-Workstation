html{
        filter: invert(1) hue-rotate(180deg) !important;
}