cd "/cygdrive/d/Git/ZL-Temp"
git add .
git commit -m "Commit script"

git push github master
git push gitlab master
git push codeberg master
git push tildegit master

eval `ssh-agent -s`
ssh-add /home/Administrator/.ssh/vio
git push github2 master
pkill ssh-agent
