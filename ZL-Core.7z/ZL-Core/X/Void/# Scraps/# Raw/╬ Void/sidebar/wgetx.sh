cd /cygdrive/c/Users/Administrator/Desktop/
head -n 1 /dev/clipboard | xargs wget