cd /cygdrive/c/Users/Administrator/Desktop/Video
head -n 1 /dev/clipboard | xargs youtube-dl  -f 'bestvideo[height<=?480]+bestaudio/best' --no-playlist --user-agent Googlebot