import requests
from bs4 import BeautifulSoup
url = 'https://www.google.com/search?q=arcadiahl=en-us'
print('URL: ' + url)
response = requests.get(url)

soup = BeautifulSoup(response.text, 'html.parser')
print(soup.title)
print(soup.h2)
#print(soup.p)
#print(soup.li)

blog_titles = soup.findAll(['h3', 'h4', 'h5'])
for title in blog_titles:
    print(title.text)
 
#blog_titles = soup.select('h3, h4, h5:not(:contains("Most popular articles"))')
#for title in blog_titles:
    #print(title.text)
