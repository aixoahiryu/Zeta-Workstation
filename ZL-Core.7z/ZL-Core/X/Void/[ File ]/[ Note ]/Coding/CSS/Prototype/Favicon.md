filter:
sepia(100%) invert(0%) brightness(100%) saturate(150%) contrast(500%) hue-rotate(85deg) !important;

sepia(100%) invert(100%) brightness(225%) saturate(300%) contrast(100%) hue-rotate(-45deg) !important