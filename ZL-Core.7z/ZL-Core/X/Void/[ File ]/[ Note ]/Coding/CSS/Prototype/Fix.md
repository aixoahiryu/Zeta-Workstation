# Commit
# Old
Background
```
.vector-menu-tabs li, .yui-navset .yui-nav a
```

Google
```
.GyAeWb{margin-left: 0px !important;}
```