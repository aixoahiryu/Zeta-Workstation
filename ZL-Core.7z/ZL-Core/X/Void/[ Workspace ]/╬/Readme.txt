So I'm making a parasitic desktop environment, you won't even notice it's installed unless you know where to look.
It has 9 invisible 1-pixel thin activation zone along the edges of the screen. Each are bound to an overlay Workspace like picrel.
Very incomplete. Made this thing because I wanted a cross-platform sidebar and it got out of hand.
The Tcl/Tk interface run fine on X11 and Windows, haven't tested on mac and wayland