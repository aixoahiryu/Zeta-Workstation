eval `ssh-agent -s`
#ssh-add ~/.ssh/id_ed25519
cd "/cygdrive/d/Git/Zeta-Workstation"
git add .
git commit -m "Commit script"
git push github master


ssh-add /home/Administrator/.ssh/vio
cd "/cygdrive/d/Git/madcat28651.github.io"
git add .
git commit -m "Commit script"
git push github master
pkill ssh-agent
