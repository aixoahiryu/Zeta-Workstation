import os
import subprocess
import sublime
import sublime_plugin

class OpenFolder(sublime_plugin.WindowCommand):
	def run(self, dirs):
		for d in dirs:
			self.window.run_command("open_dir", {"dir": d})