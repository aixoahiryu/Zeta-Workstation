BLOCKED TEXAS FROM INCREASING POWER AFTER BEGGING FOR HELP 1 WEEK BEFORE POLAR VORTEX
https://boards.4chan.org/pol/thread/309363711

![1614490767301 biden grabbing baby crotch.jpg](https://i.imgur.com/GOX9smH.jpg)