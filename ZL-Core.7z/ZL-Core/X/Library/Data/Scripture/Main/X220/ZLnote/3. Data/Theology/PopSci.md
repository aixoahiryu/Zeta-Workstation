# PopSci: Science Worship
**Not to be confused with the scientific method.**

Science is one of the most beautiful and awe inspiring accomplishments of mankind, but many people seem to be in denial about the power and clarity that science brings to our understanding of the world, and insist taking us all back into the dark ages.

If that was not bad enough, ridiculous and stupid things are said and done in the name of Science again and again, either out of interest to push a certain agenda or out of pure ignorance and ineptitude.


Reward:
Punishment:
Dogma:
Leader:
Medium:
Worshipper: