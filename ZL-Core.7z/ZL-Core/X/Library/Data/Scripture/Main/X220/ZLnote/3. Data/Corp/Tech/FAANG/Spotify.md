Don't be fooled by Spotify. You pay a stupid monthly premium just so you can have a choice of what to listen to without ads. Furthermore, you can “download” music to listen to it offline. The catch is that you will never truly own that file as it has DRM slapped onto it so it will always be susceptible to Spotify's rules. Spotify has started [censoring music that has misinformation](https://reclaimthenet.org/spotify-censors-ian-browns-anti-lockdown-track/ "https://reclaimthenet.org/spotify-censors-ian-browns-anti-lockdown-track/"). Furthermore, like many companies, they are sellouts to Big Data as it has an [egregious overreaching privacy policy](https://www.theguardian.com/technology/2015/aug/21/spotify-faces-user-backlash-over-new-privacy-policy "https://www.theguardian.com/technology/2015/aug/21/spotify-faces-user-backlash-over-new-privacy-policy"). They harvest so much data they can even [predict your emotions](https://www.theguardian.com/commentisfree/2018/sep/16/spotify-can-tell-if-youre-sad-heres-why-that-should-scare-you "https://www.theguardian.com/commentisfree/2018/sep/16/spotify-can-tell-if-youre-sad-heres-why-that-should-scare-you"). They are still [following up with it after years of criticism](https://www.bbc.com/news/entertainment-arts-55839655 "https://www.bbc.com/news/entertainment-arts-55839655"). Lastly, if you listen to podcasts, you should avoid them because they censor certain podcasts and episodes.

###### Music

-   [Nuclear](https://nuclear.js.org/ "https://nuclear.js.org/"): Desktop-only, multi-platform Spotify-like application. Similar to mps-youtube except it is more focused on music and uses a GUI. Streams free music from sources like YouTube Music (with Invidious APIs), Bandcamp, Soundcloud, BandCamp and [Audius](https://audius.co/ "https://audius.co/"). Completely free software(as in speech not just beer). Not targeted for people that hate Electron.js framework. Here is the developer's [personal opinions on the framework](https://github.com/nukeop/nuclear/blob/master/docs/electron.md "https://github.com/nukeop/nuclear/blob/master/docs/electron.md").
    

**Federation Alternative:**

-   [Funkwhale](https://funkwhale.audio/ "https://funkwhale.audio/"): Community-driven project that aims to make open source platform which lets you listen and share music and audio within a decentralized, open network. Anyone can host a pod that is open to the public.
    
    -   [Client Apps](https://funkwhale.audio/en_US/apps "https://funkwhale.audio/en_US/apps")
        
    

**Other:** Consider self-hosting your own music server using software like [mStream](https://mstream.io/ "https://mstream.io/") or [Jellyfin](https://jellyfin.org/ "https://jellyfin.org/"). For more information, check out the music section on the [music-streaming](https://dokuwiki.techxodus.org/doku.php?id=en_home_server_setup_media_streaming#music-streaming "en_home_server_setup_media_streaming").