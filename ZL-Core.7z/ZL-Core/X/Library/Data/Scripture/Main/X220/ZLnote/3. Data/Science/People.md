ID|Data
---|---
Albert Einstein|Just steal viq breakthroughs from students or other people online. That's what Einstein did and once he was in a position where he couldnt he was so famous he just made shit up and it took 75 years to prove him a liar.