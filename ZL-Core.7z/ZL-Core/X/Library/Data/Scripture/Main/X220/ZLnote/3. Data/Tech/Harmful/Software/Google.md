Format:
- WebP
- AVIF