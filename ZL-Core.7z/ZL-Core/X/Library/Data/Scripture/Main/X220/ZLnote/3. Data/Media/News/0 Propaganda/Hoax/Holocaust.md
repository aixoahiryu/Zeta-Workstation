Jews were repeatedly asked to leave the country all through the 30's, most famously under the Haavara agreement.

After WW2 was under way, the jews that had refused to leave were put into camps, just like the Japanese-Americans the US put into camps. They were seen (rightfully) as a security risk. They were treated well by POW standards, better than the US treated the Japanese. Typhus was a major problem in the early 20th century.The camps were riddled with typhus (a disease spread by lice, hence ALL the camps having Zyklon B on site, it's a pesticide) and eventually as the war turned against Germany (24/7 bombings by the allies, invasions on all fronts, food and material supplies cut-off etc.) you saw a lot of disease and starvation in the camps... just like you saw in the German civilian population and what you would have seen in the US camps had the US come under such duress.

![Haavara agreement.jpg](https://i.imgur.com/iWlYD0f.jpg)

https://boards.4chan.org/pol/thread/310193959