[ Henry VIII mask](https://m.youtube.com/watch?v=A3pMxvS_bI4)
![37dc12d6d4b3c69a284d3d9d4ce21ccb.jpg](https://i.imgur.com/frB6wE7.jpeg)