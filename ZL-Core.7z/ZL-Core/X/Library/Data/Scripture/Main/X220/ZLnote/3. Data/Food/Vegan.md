Facts:
I.Nobody ate salad a hundred years ago. It was a side dish to make things more interesting.
II.What we always ate and what we are adapted for is: animal products, especially
>Meat
>Organs
>Fish
>(Aryans only) organic/raw Milk - this was our big advantage which allowed us to conquer the world, over and over again
>Blood, especially in soups and sausages
>eggs

III.Vegan food falls into two categories:
>useless greens, chock full of anti nutrients/toxins
>mass produced carbs, nutrionally empty and the cause of obesity

IV.The whole propaganda apparatus works for this astoturfed "revolution" and its full of lies
>eat $ 0y, goyim!
>just limit your calories, goy!
>fat is bad, especially saturated (the kind you carry in your belly and burns best!), goyim!
>buy this crappy, overpriced stuff instead supporting your local farmer, goy!
>traditional farming and animal husbandry is desastrous for the environment, goy!

V.Since going more and more vegetarian and vegan, avoidable chronic illnesses have skyrocketed. Most of these can be cured through simply following a meat based diet. Sometimes people who experienced symptoms their whole life are better after a couple of days! How is this possible if the green theories are correct?!

VI.Veganism suffers from the great dissonance that for some reason
>it's the healthiest diet
>delivering avocados by plane is also the most eco friendly diet
>and it's been discovered only now

VII.Wild animals live a short life and are then eaten by predators. In captivity they live nice lives and can be slaughtered quickly. That is ok.

VIII.Most vegans don't look healthy and it's obvious they need a cult to feel the void in their brain.