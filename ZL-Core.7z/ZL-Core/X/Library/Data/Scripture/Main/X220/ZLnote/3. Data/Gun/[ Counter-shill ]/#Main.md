Its funny because besides magazine sizes, guns are already regulated alot like cars, and even more so in some states
Buying a gun is like renting a car. You can't get one if you're an asshole, without any cash, untrustworthy, or mentally unstable
Of course, anti-gun activists don't know this because gun bad stop having guns everyone