# Cookies Hacking

## Hacking cookies

If you find some kind of custom cookie containing sensitive data \(sessionID, username, emails...\) you should definitely try to exploit it

### Decoding the cookie

If the **cookie** is using some **Base encoding** \(like Base64\) or similar you may be able to **decode it**, **change** the **content** and **impersonate** arbitrary users.

### Session Hijacking

Steal a cookie and use it to impersonate the user inside an application

### Session fixation

The attacker get a cookie from a web page and send to the victim a link so the victim logins using the cookie of the attacker. If the cookie is not changed when a user logs in, this could be useful because the attacker could be able to impersonate the user using the cookie.

### Session donation

The attacker sends his own session to the victim. The victim will see that he is already loged and will suppose that he is inside his own account but the actions will be performed inside the attackers account.

### [JWT Cookie](hacking-jwt-json-web-tokens.md)

Click on the previous link to access a page explaining possible flaws in JWT.

### Checking Cookies

#### **Basic checks**

* The **cookie** are the **same** every time you **login**
* Log out and try to use the same cookie
* Try to login with 2 devices \(or browsers\) to the same account using the same cookie
* Check if the cookie has any information in it and try to modify it
* Try to create several accounts with almost the same username and check if you can see similarities.
* Check "**remember me**" option if it exists and check how does it works. If it exists and could be vulnerable, always use the cookie of **remember me** without any other cookie.
* If you change the password and previous cookie still works

#### **Advanced cookies attacks**

If the cookie remains the same \(or almost\) when you log in, this probably means that the cookie is related to some field of your account \(probably the username\). Then you can:

* Try to create a lot of **accounts** with usernames very **similar** and try to **guess** how is working the algorithm
* Try to **bruteforce the username**. If the cookie saves only as authentication method your username, then you can create an account with username "**Bmin**" and **bruteforce** every single **bit** of your cookie because one of the cookies that you will try will the one belonging to "**admin**".
* Try **Padding** **Oracle** \(you can decrypt the content of the cookie\). Use **padbuster**.

**Padding Oracle - Padbuster examples**

```bash
padbuster <URL/path/when/successfully/login/with/cookie> <COOKIE> <PAD[8-16]>
# When cookies and regular Base64
padbuster http://web.com/index.php u7bvLewln6PJPSAbMb5pFfnCHSEd6olf 8 -cookies auth=u7bvLewln6PJPSAbMb5pFfnCHSEd6olf

# If Base64 urlsafe or hex-lowercase or hex-uppercase --encoding parameter is needed, for example:
padBuster http://web.com/home.jsp?UID=7B216A634951170FF851D6CC68FC9537858795A28ED4AAC6
7B216A634951170FF851D6CC68FC9537858795A28ED4AAC6 8 -encoding 2
```

Padbuster will make several attempts and will ask you which condition is the error condition \(the one that is not valid\).

Then it will start decrypting the cookie \(it may take several minutes\)

If the attack has been successfully performed, then you could try to encrypt a string of your choice. For example,  if you would want to **encrypt** **user=administrator**

```text
padbuster http://web.com/index.php 1dMjA5hfXh0jenxJQ0iW6QXKkzAGIWsiDAKV3UwJPT2lBP+zAD0D0w== 8 -cookies thecookie=1dMjA5hfXh0jenxJQ0iW6QXKkzAGIWsiDAKV3UwJPT2lBP+zAD0D0w== -plaintext user=administrator
```

This execution will give you the cookie correctly encrypted and encoded with the string **user=administrator** inside.

**CBC-MAC**

Maybe a cookie could have some value and could be signed using CBC. Then, the integrity of the value is the signature created by using CBC with the same value. As it is recommended to use as IV a null vector, this type of integrity checking could be vulnerable.

**The attack**

1. Get the signature of username **administ** =  **t**
2. Get the signature of username **rator\x00\x00\x00 XOR t** = **t'**
3. Set in the cookie the value **administrator+t'** \(**t'** will be a valid signature of **\(rator\x00\x00\x00 XOR t\) XOR t** = **rator\x00\x00\x00**

**ECB**

If the cookie is encrypted using ECB it could be vulnerable.  
When you login the cookie that you receive has to be always the same.

**How to detect and attack:**

Create 2 users with almost the same data \(username, password, email...\) and try to discover some pattern inside the given cookie

Create a user called form example "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" and check if there is any pattern in the cookie \(as ECB encrypts with the same key every block, the same encrypted bytes could appear if the username is encrypted\).

There should be a pattern \(with the size of a used block\). So, knowing how are a bunch of "a" encrypted you can create a username: "a"\*\(size of block\)+"admin". Then, you could delete the encrypted pattern of a block of "a" from the cookie. And you will have the cookie of the username "admin".

## Cookies Flags

### SameSite

This will indicate the browser if the **cookie** can be sent **from other domains**. It has 3 possible values:

* **Strict**: The cookie will not be sent along with request by third party websites.
* **Lax**: The cookie will be sent along with the GET request initiated by third party websites.
* **None**: The cookie is sent from any third party domain

| **Request Type** | **Example Code** | **Cookies sent** |
| :--- | :--- | :--- |
| Link | &lt;a href="..."&gt;&lt;/a&gt; | Normal, Lax |
| Perender | &lt;link rel="prerender" href=".."/&gt; | Normal, Lax |
| Form GET | &lt;form method="GET" action="..."&gt; | Normal, Lax |
| Form POST | &lt;form method="POST" action="..."&gt; | Normal |
| iframe | &lt;iframe src="..."&gt;&lt;/iframe&gt; | Normal |
| AJAX | $.get\("..."\) | Normal |
| Image | &lt;img src="..."&gt; | Normal |

Table from [here](https://www.netsparker.com/blog/web-security/same-site-cookie-attribute-prevent-cross-site-request-forgery/)  
A cookie with _**SameSite**_ attribute will **mitigate CSRF attacks** where a logged session is needed.

**Notice that from Chrome80 \(feb/2019\) the default behaviour of a cookie without a cookie** _**samesite**_ **attribute will be lax** \([https://www.troyhunt.com/promiscuous-cookies-and-their-impending-death-via-the-samesite-policy/](https://www.troyhunt.com/promiscuous-cookies-and-their-impending-death-via-the-samesite-policy/)\). Notice that temporary, after applying this change, the **cookies without a SameSite** **policy** in Chrome will be **treated as None during the first 2 minutes and then as Lax**.

### HttpOnly

This avoids the **client** to access the cookie \(Via **Javascript** for example: `document.cookie`\)

#### **Bypasses**

* This could be Bypassed with **TRACE** **HTTP** requests as the response from the server \(if this HTTP method is available\) will reflect the cookies sent. This technique is called **Cross-Site Tracking**.
  * This technique is avoided by **modern browsers by not permitting sending a TRACE** request from JS. However, some bypassed to this have been found in specific software like sending `\r\nTRACE` instead of `TRACE` to IE6.0 SP2.
* Another way is the exploitation of zero/day vulnerabilities of the browsers.

### Secure

The request will **only** send the cookie in an HTTP request only if the request is transmitted over a secure channel \(typically **HTTPS**\).

