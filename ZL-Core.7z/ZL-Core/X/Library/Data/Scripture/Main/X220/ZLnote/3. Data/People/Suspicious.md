ID|Data
------------|------------
Lee Rosenberg ![](http://i.4pcdn.org/pol/1543029431373.gif) | `AIPAC` `Alien`