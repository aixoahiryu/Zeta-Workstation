There are many ways to do IPC on Linux. Dbus is the most retarded and idiotic way to do it.
Zero transparency and discoverability, it requires a fucking demon to run and uses a format that looks like JSON but is not JSON compatible (That would be to user friendly).
It's the stereotypical brainchild of the freedesktop.org crowd.