https://nosystemd.org/
https://ihatesystemd.com/
https://suckless.org/sucks/systemd/

---

Since the release of systemd in 2010 the project has been getting a continuous and steady stream of new features and added capabilities, and with a code count of more than 1.3 million lines of code, where Lennart Poettering has just added yet another 20.000 new lines of code with the merge of his personal systemd-homed git tree into systemd, and with a continuous open issue counter at about 1.400 issues, where new issues keep popping up, systemd should be considered experimental and not safe to run anywhere.

Considering how systemd is being developed where the code hasn't even undergone (as far as I know) a single code audit, and the developers keep adding new features instead of focusing on bugs, security, and stability, the project doesn't belong in any GNU/Linux distribution except as in a "testing stage", and any kind of GNU/Linux distribution with systemd is not suited as a production system if security matters.

Even Debian GNU/Linux, with its extended testing in its "testing" and "unstable" releases, before anything goes into the "stable" release, isn't suited for production because systemd still has many open issues and even open bugs dating back all the way to 2015.

The GNU/Linux many of us know so well, is slowly turning into a disaster, an operating system apocalypse of security issues just waiting to happen. Just because everyone wanted a new init system, but somehow ended up with everything but a new kernel.

The main problem with systemd is that its continued development is motivated by a company's economic interests and not the Open Source Linux community interests. As time goes by more and more "issues" will most likely pop-up and the other major Linux distributions will possibly regret the integration and adoption of systemd into their projects. Not because of systemd as an init system in itself, systemd init is pretty good and Lennart Poettering and Co. have contributed and implemented some great features. What I mean by "issues" is not the software bugs, but the way user concerns, privacy concerns, and other important security issues are dealt with by Lennart Poettering and Co.

OpenRC is as easy to use as SystemD but it's way less harmful. Even if SystemD is supposedly faster at booting the computer (actually, RunIT is faster), it takes forever to shutdown the computer because SystemD somehow fails to kill the services (it might sometimes get magically fixed but it breaks again randomly and often) Also, is it a good idea to have a huge and bloated PID1? If the PID1 is kill, the whole system goes down. And what about the security implications? Imo, it's absolutely insane to bundle ntpd, boot-loader, (crappy) logger that can't filter logs and produces binary logs by default (good luck reading those logs if your system crashes), sudo, etc into init system. Not to mention the attitudes of core SystemD developers who say things like "it's totally not a bug!" and "that bug is pretty insignificant" (+ a few years ago, the same developers tried to push patches into the Linux kernel (!) to get a new SystemD feature working)

Overall, systemd has some good ideas. If my computer is off when a cron job is scheduled it's not going to run after first boot, even if I wanted it to, whereas a systemd timer would be more "smart" about this. This pattern appears with most of the, let's say "venerable", programs that systemd intends to replace.
Problem is the developers only care about their products, such that they reject patches to e.g. work with musl libc, and while the components are modular, they aren't individually reusable without basically forking them, which isn't bad design technologically but it is if I want to have just systemd timers on my system.
It's another "compatibility through homogeneity" thing, rather than "compatibility through sane file formats, filesystem structures, and filesystems themselves", which leaves a bad taste in my mouth to the point where I don't want to take responsibility for this code running on my system, which I'm happy to do with e.g. linux itself, musl, and so on. For other pieces of software, I take that responsibility begrudgingly, but systemd has alternatives, so I'm not stuck with it like I am with gcc. 
Software that depends on systemd without being "a systemd program" is pretty :/ regardless of whether you like it or not, e.g. piper/libratbag. For this kind of "system" software, it's incredibly important that it's portable, which means (standard) C and posix, and this portability is more important than fixing any of their (numerous) technical failures.

---

I used systemd for a reasonable amount of time, and bluntly I just wasn't impressed. It didn't bring anything new to the table, but did introduce a lot of problems. Crashing during boot (unacceptable for any init, I'm sorry, but that is just trash), and sticking its fingers all over the system where it didn't belong. Also, you should take a look at news revolving around security holes, and take a look at the bug tracker (sort by oldest still open). It isn't pretty. (also, I found out recently from an acquaintance that a bug that existed and was causing serious problems for me ~10 years ago is still present and requires manual intervention to fix today...). Let's assume the software isn't crap, but unfortunately the developers are so full of themselves with their heads so far up their own asses, they actually believe they can dictate terms to the linux kernel (kid you not). However, that isn't the situation - they're arrogant, impossible to work with and think they can dictate terms. Hilarious, but also troubling for software with such a significant amount of buy in. Personally, I'll be sticking with OpenRC or literally any other system, at least until they reform their development and security practices. 
 
But really, the problem is that it forcefully monopolizes the application environment and at the same time unjustifiably hampers other init systems by forcing people to put it as a dependency for anything and everything.
If it wasn't buggy and untrustworthy, such situation wouldn't be a big problem, but unfortunately that's not the case.

I see this as a huge opportunity for a new wave of baby-tier linux rootkits that somehow are tailored for specific ring negative access applications and soykaffed motherboards/CPU all the while systemd being the needful bridge to that gap.
Imagine, if some package dependent on such thing had a severe fontconfig or imagemagick bug, a series of overflows plus a sandbox bypass if it has one. Definitely not the best scenario with a really "modernized" soykaf init system that does and has something that it shouldn't have in the first place.
Future of linux is bleak.

---

Lots of bugs
>kernel panics
>file corruption
>300 years stop job on shutdown
>actually restarts instead of "shutdown"
>file corruption again
>aggressive coredump causing severe corruption and hardware failure
>you even had to turn it off manually because sane default https://wiki.archlinux.org/index.php/Core_dump
>coredump of death if your DE crashes, again, filling up the drive to full (the size of your entire RAM dumped) and you just wake up with bad sectors from aggressive thrashing and overall failure.
 
---
 
 >Works on my machine. Was the problem displayed in the logs?
 
I've also had severe problems, and no, they weren't in the logs. I ended up having to fix it blind, and no, nobody was around to help me since they all gave me the same non-advice you're trying to give this guy. A major problem with systemd is the developers like to say "works on my machine" while creating problems for people. This is well documented.

>Where doesn't it belong? systemd was never meant to be "just an init system", that's just FUD that was spread by haters. 

No, false. The original project stated they wanted to make a basic init system. From there, they ballooned out into other areas. You can argue and try to retcon this all you want, but it is the unfortunate history. 
>was actually a Linux bug, which systemd was unjustly blamed for.
>iT wAs LiNuX's fAuLt

Don't cover for bad developers.

>Userspace software inefitably influences kernel development, like it or not, to the point that Trovalds makes it very clear that all changes to Linux breaking userspace programs are kernel bugs, and they shouldn't blame others

And hence why they rightfully reject systemd's buggery. 

>Are the Wireguard developers assholes as well for "dictating terms to the Linux kernel"?
>These other people did get their way, does that make them assholes?

Nice.

>Sorry, but that's how free software works. Contributors decide what direction software takes, non-contributors don't. Thousands of PRs have been accepted and merged, you could try submitting one too if you want to be heard.

You're making quite a presumptuous claim. No, PRs are not going to make a fuarrrking damn difference. The whole thing is a corporate project, and they dictate terms. Your contributions won't stand a rat's chance making a dent. 

It's pretty sad that systemd zealots need to resort to such bogus lying and bullshit to make their software look even remotely reasonable.

>systemd was never meant to be "just an init system"

Then it's broken by design and will always be bad no matter how good the implementation becomes.
 
 ---

\>\>80951681 (OP)

https://lkml.org/lkml/2014/8/12/459

>systemd is a coup. It is a subversive interloper designed to destroy
Linux as we know it, foisted upon us by the snarky
we-know-better-than-you CamelCase crowd. They just don't get it down
deep where it matters. systemd is not pointing in a direction that we
should be going. It does not encourage freedom. It does not encourage
choice. It does not display transparency. It does not embrace
simplicity. It seizes control and forces you to cede it. It makes
applications and major system components depend on it, and they cannot
function without it. It's gaining speed by luring naive or lazy or just
plain clueless developers into the fold with the promise of making
their lives easier. Buying into this way of thinking ignores the
greater dangers that systemd represents.

---

What is intelligence? Not exactly the spook kind, but rather what is
the definition of intelligence in humans? This is pretty good:
http://en.wikipedia.org/wiki/Intelligence#Definitions

By most accounts, the self-appointed and arguably too influential
creators and thinkers of the day around the 'One Linux' idea fit the
definition of intelligent people - at least in the technical realm.

And their messages are pretty compelling:
* Simplify cross-distro development.
* Enable faster boot times.
* Enable an on-demand, event driven architecture, similar to 'Modern'
  Operating Systems.
* Bring order and control to subsystems that have had as many different
  tools as there were distros.

All seemingly noble goals. All apparently come from a deep desire to
contribute and make things better.

Almost anyone could argue that these intelligent people thought hard
about these issues, and put an enormous amount of effort into a
solution to these problems. Unfortunately, the solution they came up
with, as you may have guessed by now, is 'systemd'.

While not new, it's grotesque impact has finally reached me and I must
speak to it publicly. 

So, what is systemd? Well, meet your new God. You may have been praying
at the alter of simplicity, but your religion is being deprecated. It
likely already happened without your knowledge during an upgrade of
your Linux box. systemd is the all knowing, all controlling meta-deity
that sees all and supervises all. It's the new One Master Process that
aspires to control everything it can - and it's already doing a lot.
It's what init would look like if it were a transformer on steroids.
It's complicated, multi-faceted, opaque, and supremely powerful.

I had heard about systemd a few years back, when upstart and some other
init replacements I can't remember were showing up on the scene. And
while it seemed mildly interesting, I was not in favor of using it, nor
any of them for that matter. init was working just fine for me. init
was simple and robust. While configuration had it's distro-specific
differences, it was often these differences that made one pick the
distro to use in the first place, and to stay with that distro. The
tools essentially *were* the distro. I just dist-upgraded to Jessie,
and voila - PID 1 was suddenly systemd. What a clusterfuck.

In a 'One Linux' world, what would distros actually be? Deprecated. No
longer relevant. Archaic shells of their once proud individualism.
Basically, they're now just a logo and a default desktop background
image. Because let's face it, there only needs to be One Modern
'competitor' to the Windows/Mac ownership of personal computing. A
unified front to combat the evil empires of Redmond and Cupertino is
what's needed. The various differences that made up different 'flavors'
of Linux needed to be corralled and brought into compliance for the war
to proceed efficiently. Um, what war?

For me, Linux had already won that war way back in 1994 when I started
using it. It did it without firing a shot or attempting to be just like
the other OSes. It won it it by not giving a flying fuck about market
share. It won it by being exactly NOT them. It won it by being simple
and understandable and configurable to be exactly how *I* wanted it to
be. It won it by being a collection of simple modular components that
could be plugged together at will to do real work. It won it by
adhering to a deeply considered philosophy of the user being in the
drivers seat, and being free to run the things she wanted to, without
layers and layers of frameworks wrapping their tendrils into all manor
of stuff they should not be touching. It won it without the various
'CrapKit' shit that's begun to insinuate itself into the heart of my
system of late. It won it without being overly complex and unknowable.
That kind of opacity was was the core of Windows and Mac, and that's
exactly what I despise about them, and exactly why I chose to use Linux
in the first goddamn place. systemd is embracing *all* that I hate about
Windows and Mac, and doing so in the name of 'modernity' and
'simplifying' a developer's job.

So why would very smart people who love and use Linux want to create or
embrace such a creepy 'Master of All' daemon? Ostensibly, it's for the
reasons they say, as I mentioned at the top. But partially I think it's
from a lack of experience. Not a lack as in programming hours, but a
lack as in time on the Planet. Intelligence alone is not a substitute
for life experience and, yes I'll say it, wisdom. There's no manual for
wisdom. Implementing systemd by distros is not a wise move for them over
the long term. It will, in fact, be their ultimate undoing.

Partially it's the larger-than-life egos of the people involved. Has
anyone actually read what Poettering says about things? Wow. This guy
is obviously convinced he has all the answers for everyone. Traditional
ideas about simplicity and freedom are quaint, but have no real place
in a 'modern' OS. Look, he's just smarter than you, so get over it and
move aside. He knows what's best, and he has it under control. How old
is this guy anyway? 12 or so? He's a fucking tool (IMHO).

Partially it's roiling subsurface commercial interests. Look, We can
make more money selling stuff to Linux users if there were a simpler
distro agnostic way to do that. Fuck choice, they'll like what they get.

Partially it may well be nefarious and shadowy in nature. With One Ring
to rule them all, having access to it sure would be sweet for those
hell-bent on total information awareness. Trust is not real high on my
list of things to give out these days.

Partially it's a belief that the Linux Community must fight against the
hegemony of Windows and Mac - as if the existence of Linux depends upon
the vanquishing of alternatives. Those who think Linux should cater to
idiots and droolers should go back to their Macs and Windoze boxen, and
stop trying to 'fix' Linux. It wasn't fucking broken!

Partially - and this is what I cannot abide - it is a blatant disregard
and disrespect - whether knowingly or not - of the major tenets of
*NIX. It's a thoughtless discarding of, and a trampling on the values
that I personally hold to be true and just, and I am not alone here.
systemd is the exact opposite of what defines *NIX. And I'm not
blathering on about POSIX compliance either. It's the Philosophy stupid.

systemd is a coup. It is a subversive interloper designed to destroy
Linux as we know it, foisted upon us by the snarky
we-know-better-than-you CamelCase crowd. They just don't get it down
deep where it matters. systemd is not pointing in a direction that we
should be going. It does not encourage freedom. It does not encourage
choice. It does not display transparency. It does not embrace
simplicity. It seizes control and forces you to cede it. It makes
applications and major system components depend on it, and they cannot
function without it. It's gaining speed by luring naive or lazy or just
plain clueless developers into the fold with the promise of making
their lives easier. Buying into this way of thinking ignores the
greater dangers that systemd represents.

Debian has always held the line against this kind of thing in the past,
and has always earned my utmost respect and loyalty for their
integrity. Debian's decision here was as a hand forced. Debian has made
a grave and cowardly mistake here, and they need a course correction
immediately. Incorporating systemd was not an intelligent choice, and
certainly not one very well considered. Debian must reject systemd and
its ilk, and restore itself to the values that got Linux to this
point in history, in no small part *led* by Debian. They must loudly and
publicly divorce themselves from GNOME, however painful and upsetting
that may seem in the sort term, and focus on the core values of
simplicity and freedom. Put systemd and it's cabal in non-free where it
belongs if you must. Let the user decide if that's what
they want. Enlightenment is an excellent choice for a default desktop
that does not have the bloated baggage of GNOME. And to the Debian
Leaders - after 20 years of my loyalty and evangelism, you really let
me and all of us down. You need to grow a fucking pair and do the right
thing here and now.

Kick these fucking carpetbaggers to the curb!

Gnome. The Linux Foundation. freedesktop.org, and others. These are all
groups with agendas. These are not those who believe in freedom. They
believe in control and standardization. They believe in sameness. Who
are these people anyway? Who are these self-appointed keepers of the
Linux flame? (subliminal malware reference intended). What are their
true agendas? Who funds these people? Why do they so aggressively want
to change the core of Linux away from it's true philosophy? Let them go
off and create their own 'competitor' to Windows and Mac. If they did,
it would be the same opaque, backdoored, user-tracking bullshit that
Windows and Mac have become. They DO NOT speak for me, and you should
not passively allow them to speak for you either.

systemd is a trojan. systemd is a medusa. systemd is Substance D.
systemd is scary - not just because it's tools suck, or because it's
a massive fucking hairball - but because architecturally it has way
too much concentrated power. We all need to collectively expel it from
our midst because it will own Linux, and by extension us and our
freedoms. systemd will *be* Linux. Sit idly by and ignore this fact at
all of our collective peril.

OneLinux == zero-choice


--
Regards,
Christopher Barry