It's about how things get managed by Red Hat / Gnome. Not only Wayland, but GTK, Glib, everything else they developed.

People, never touching this stack, just don't understand what they are talking about. It's not stack for developing third party applications, like you would expect (since it's default on many distros). It's only developed exclusively for Red Hat and on-purpose vendor-lock.

Bugs, bugs, bugs. Literally not possible to do anything non-trivial. That's why all Linux applications consist of just a bunch of buttons, no more.

Some time ago I tried to implement new, modern photo manager for Linux using GTK.
I need to render infinite list of image thumbnails.
No support for this out of the box, while in Web stack you just take https://github.com/bvaughn/react-virtualized and it should work. You have to develop own low-level component like GtkFlowBox yourself, 5000 lines of C code.

Tried just to render 10000 empty components. It took 300 seconds to render just 10000 empty components on modern computer. What??? It should take at most under one second.

I've spent two weeks and figured out the problem is in their custom CSS engine implementation. Fixing it I could make performance 6750x times faster, from 80 seconds to 0.012 seconds. But the other dominated part (required to make my application working as I expected) still existed.

You know what, they didn't help me. No interest in providing more info to complete the patch at all. It's just not their use case (rendering several buttons is all what they need). So that was blocker for my application. I stopped working on it and sworn ever touching GTK / Gnome. This is the original issue
https://gitlab.gnome.org/GNOME/gtk/-/issues/2165.

Also Nautilus freezing on every keystroke by exactly the same reason - it can't render so many components and hangs on.

So, never ever, touch GTK, Glib or any other Gnome stuff.
For most problems https://gitlab.gnome.org/GNOME/gtk/-/issues?scope=all&utf8=%E2%9C%93&state=closed&author_username=likern you are either on your own to implement / support youself, or they are not going to implement in near future, etc...etc.