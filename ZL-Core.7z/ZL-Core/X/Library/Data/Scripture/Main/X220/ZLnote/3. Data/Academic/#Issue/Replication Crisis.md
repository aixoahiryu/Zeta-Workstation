It's partially due to the way papers get published and how studies get funding, they cram any shit through to maintain funding and that creates a lot of nonsense

Then you have paid studies where data is tortured until it spits out what someone wants and is cited to try and give a claim validity when it doesn't have it

Then you have ideological studies that do the same thing but not for particular profit, though this usually leads to something more nefarious, false consensus where they try and turn science into a democracy that agrees with it's self using qualitative evidence instead of quantitative evidence.