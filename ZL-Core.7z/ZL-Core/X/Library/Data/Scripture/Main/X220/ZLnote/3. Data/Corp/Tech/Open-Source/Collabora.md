Type|Data
------------|------------
Industry|	Software Consulting, Software Products, Open Source
Founded|	July 2005
Founder|	Robert McQueen and Robert Taylor
Key people|	Philippe Kalaf, Michael Meeks, Guy Lunardi
Location| Cambridge, United Kingdom; Montreal, Canada; https://collabora.com/

Past key people|Type|Date
------------|:------------:|------------

Product:
- Wayland
- PulseAudio
- Blink `Google`
- Webkit `Apple`
- LibreOffice `Icewarp` [SUSE](a "The former LibreOffice development team of SUSE joined Collabora in September 2013.") [NextCloud](a "There is a distribution of LibreOffice Online on NextCloud Server")
- Telepathy (software) `D-Bus`
- GStreamer `freedesktop.org`
- Digital Living Network Alliance (DLNA) `Intel`
- Collabora GovOffice + Collabora CloudSuite `Crown Commercial Service`
- [CODE](a "Collabora Online Development Edition") `ownCloud`

Sponsored:
- D-Bus
- Linux Kernel >Collabora employs multiple kernel subsystem maintainers (e.g. Chromebooks, I3C, battery drivers) and actively contributed to every release in the last few years
- Pitivi
- vkmark
- Zink
- Monado

Org|Description
------------|------------
Linux Foundation | Collabora is a Silver member of the Linux Foundation since 2010.
GENIVI Alliance | Collabora is a member of the GENIVI Alliance since 2011.
Khronos Group | Collabora is a Contributor member of the Khronos Group since 2014.
Bluetooth SIG | Collabora is an Adopter member of the Bluetooth SIG since 2014.
ARM Connected | Collabora is a member of the ARM Connected Community since 2014.
Rockchip | Collabora has been working with Rockchip since 2015.
Automotive Grade Linux | Collabora is a member of Automotive Grade Linux since 2016.
R-Car Consortium | Collabora is a member of the Renesas R-Car Consortium since 2016.
Renesas Alliance Partner | Collabora is a member of the Renesas Alliance Partners since 2016.
Cambridge Network | Since its founding in 2005, Collabora has been a member of the Cambridge Network.
Debian | Collabora is a long-time member of the Debian community.
Outreachy | Collabora has been a recurring sponsor of Outreachy for years.
GNOME | Collabora is a long-time member of the GNOME community.
LOT Network | Collabora is a member of LOT Network in support of patent non-aggression.
Open Innovation Network | Collabora is an OIN licensee in support of patent non-aggression