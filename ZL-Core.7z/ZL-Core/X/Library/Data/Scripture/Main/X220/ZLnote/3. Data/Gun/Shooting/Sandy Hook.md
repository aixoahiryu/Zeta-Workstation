It's 100% perfectly normal that they bulldozed the school right after it happened. Standard operating procedure.

Lanza's home bulldozed as well.
Happens every time a crime happens, right?

FBI EOY murder statistics for the state didn't include sandy hook "out of respect"
fuckin bang up job

![parkerr.webm](https://i.4pcdn.org/pol/1466953320126.webm)
![1608406665193.jpg](https://i.imgur.com/wmiGWo7.jpeg)
![1608404906157.jpg](https://i.imgur.com/QjA4sOn.jpeg)