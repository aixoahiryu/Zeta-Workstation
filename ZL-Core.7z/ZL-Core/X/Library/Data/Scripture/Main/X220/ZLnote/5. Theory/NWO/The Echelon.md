Type|Data
---|---
Paragon| ![](https://madcat28651.neocities.org/Eye_of_ProvidenceOG.png)
Unknown| ??? ???
Unknown| ???
Unknown| ??? ???
Unknown| ??? ??? ???
Unknown|Bronfman Payseur
Errand boys| Rothschild Rockefeller Soros
Puppets| [Corp](Corp.md) [People](People.md) [Media](Media.md) [Shill](Shill.md) [Academic](Academic.md) [Politics](Politics.md) [Education](Education.md) [Finance](Finance.md)

Type|Data
---|---
Unknown| ??? ???
Unknown| ???
Unknown| ??? ???
Unknown| ??? ??? ???
Nobody| ![](https://madcat28651.neocities.org/Eye_of_ProvidenceOG.png)

♖	♘	♗	♕	♔	♗	♘	♖

♙	♙	♙	♙	♙	♙	♙	♙

♟	♟	♟	♟	♟	♟	♟	♟

♜	♞	♝	♛	♚	♝	♞	♜
