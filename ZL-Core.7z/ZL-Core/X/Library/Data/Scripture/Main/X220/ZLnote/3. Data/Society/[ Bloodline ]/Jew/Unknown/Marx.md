ID|Data
---|---
Marx HaLevi Mordechai|
Heinrich Marx|
Karl Marx|