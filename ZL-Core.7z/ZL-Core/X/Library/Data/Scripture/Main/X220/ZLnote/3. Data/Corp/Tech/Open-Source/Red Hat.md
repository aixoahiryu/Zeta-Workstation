Parent: IBM

Product:
- Wayland
- D-bus
- glib
- Pipewire
- freedesktop.org

Dominate:
- GNOME
- Flatpak

Regret:
- [Xorg](a "Suspiciously all of those traitors are somehow full time employees of IBM and Collabora, but that's just a coincidence.")

https://www.redhat.com/en/blog/red-hat-statement-about-richard-stallmans-return-free-software-foundation-board

Redhat is squeezing out community because their business model is training and consulting. They keep this business model moving by forcing paradigm change in their products to make sure that skills don't transfer over time. I will be attacked for this observation which will prove my point.