ID|Data|Death
------------|------------|------------
Joan Rivers| `Tranvestigation` Exposing Michella Obama| `Aug28-2014` Yorkville, Manhattan `Sep4-2014` Mount Sinai Hospital `Sep7 memorial` Temple Emanu-El
Michael Jackson||`Jun25-2009` 12:22 pm > 2:26 pm **Propofol overdose** <br>`Jul7 memorial`
John F. Kennedy||`Nov22-1963`
Tupac|`Anti-NWO`
Stephen Goodson| `Holocaust` `Book` A history of central banking and the enslavement of mankind| `Aug4-2018`
Kerry Mullins

https://boards.4chan.org/pol/thread/310191790