
![The Ugly Truth About the ADL - EIR (1992).pdf](https://files.catbox.moe/o4uqbk.pdf)