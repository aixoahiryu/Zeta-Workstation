# Registration Vulnerabilities

## Takeover

### Duplicate Registration

* Try to generate using an existing username
* Check varying the email:
  * uppsercase
  * +1@
  * add some some in the email
  * special characters in the email name \(%00, %09, %20\)
  * Put black characters after the email: `test@test.com                    a`
  * victim@gmail.com@attacker.com
  * victim@attacker.com@gmail.com

### Username Enumeration

Check if you can figure out when a username has already been registered inside the application.

### Password Policy

Creating a user check the password policy \(check if you can use weak passwords\).  
In that case you may try to bruteforce credentials.

### SQL Injection

\*\*\*\*[**Check this page** ](sql-injection/#insert-statement)to learn how to attempt account takeovers or extract information via **SQL Injections** in registry forms.

### Oauth Takeovers

{% page-ref page="oauth-to-account-takeover.md" %}

### SAML Vulnerabilities

{% page-ref page="saml-attacks/" %}

### Change Email

when registered try to change the email and check if this change is correctly validated or can change it to arbitrary emails.

## More Checks

* Check if you can use **disposable emails**
* **Long** **password** \(&gt;200\) leads to **DoS**
* **Check rate limits on account creation**
* Use username@**burp\_collab**.net and analyze the **callback**

