Type|Data
------------|------------
Industry|	Software Consulting
Founded|	September 2001
Headquarters|	Bugallal Marchesi, 22, 1º A Coruña - Spain

Products:
- Gstreamer
- GNOME Web
- Webkit WPE
- WebkitGTK+
- Orca

Contribute:
- Blink, Gecko, Webkit
- Chromium
- Wayland
- Mesa
- NodeJS

Org|Description
------------|------------
Linux Foundation| including the Automotive Grade Linux (AGL) project
GNOME Mobile & Embedded Initiative| Founder
The World Wide Web Consortium (W3C)| Igalia is a member since 2013
The Khronos Group
ECMA International| Igalia is a member since 2018 where they participate in TC39.
WHATWG.
GENIVI® Alliance
The Software Freedom Conservancy (SFC)
The Electronic Frontier Foundation (EFF)
AGASOL
GNOME Foundation Advisory Board| Past member