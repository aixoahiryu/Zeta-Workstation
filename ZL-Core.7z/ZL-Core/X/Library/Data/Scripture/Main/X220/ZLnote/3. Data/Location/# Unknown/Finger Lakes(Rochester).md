Hunter Biden's back tattoo
![](https://i.4pcdn.org/pol/1610256715981.png)
![owasco.png](https://i.imgur.com/V1RTpuM.png)