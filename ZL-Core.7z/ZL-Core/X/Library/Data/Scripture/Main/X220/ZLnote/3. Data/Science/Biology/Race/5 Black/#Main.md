https://boards.4chan.org/pol/thread/314144464
![](https://i.imgur.com/42Wjze2.jpeg)