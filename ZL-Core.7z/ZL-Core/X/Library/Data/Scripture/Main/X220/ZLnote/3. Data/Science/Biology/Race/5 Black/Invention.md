https://www.blackinventionmyths.com/

"Invention"|Data
---|---
Suture thread|https://boards.4chan.org/pol/thread/314063455