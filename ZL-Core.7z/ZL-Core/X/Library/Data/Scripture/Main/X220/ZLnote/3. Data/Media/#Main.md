https://www.businessinsider.com/these-6-corporations-control-90-of-the-media-in-america-2012-6
![](https://i.imgur.com/aMOBhfg.png)
The article is from 2012, it's actually only 5 companies today.

>Comcast
CEO: https://en.wikipedia.org/wiki/Brian_L._Roberts

>Newscorp
Chairman: https://en.wikipedia.org/wiki/Rupert_Murdoch

>Disney
Chairman: https://en.wikipedia.org/wiki/Bob_Iger

>ViacomCBS
Chairwoman: Shari Redstone

>Time Warner
CEO: https://en.wikipedia.org/wiki/Robert_Marcus

90% of media. 5 companies. 5 jews.