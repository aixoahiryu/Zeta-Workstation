# 23 - Pentesting Telnet

## **Basic Information**

Telnet is a network protocol that gives users a UNsecure way to access a computer over a network.

**Default port:** 23

```text
23/tcp open  telnet
```

## **Enumeration**

### **Banner Grabbing**

```bash
nc -vn <IP> 23
```

All the interesting enumeration can be performed by **nmap**:

```bash
nmap -n -sV -Pn --script "*telnet* and safe" -p 23 <IP>
```

The script `telnet-ntlm-info.nse` will obtain NTLM info \(Windows versions\).

In the TELNET Protocol are various "**options**" that will be sanctioned and may be used with the "**DO, DON'T, WILL, WON'T**" structure to allow a user and server to agree to use a more elaborate \(or perhaps just different\) set of conventions for their TELNET connection. Such options could include changing the character set, the echo mode, etc. \(From the [telnet RFC](https://tools.ietf.org/html/rfc854)\)  
**I know it is possible to enumerate this options but I don't know how, so let me know if know how.**

### [Brute force](../brute-force.md#telnet)

## Config file

```bash
/etc/inetd.conf
/etc/xinetd.d/telnet
/etc/xinetd.d/stelnet
```

## HackTricks Automatic Commands

```text
Protocol_Name: Telnet    #Protocol Abbreviation if there is one.
Port_Number:  23     #Comma separated if there is more than one.
Protocol_Description: Telnet          #Protocol Abbreviation Spelled out

Name: Notes
Description: Notes for t=Telnet
Note: """
wireshark to hear creds being passed
tcp.port == 23 and ip.addr != myip

https://book.hacktricks.xyz/pentesting/pentesting-telnet
"""

Name: Banner Grab
Description: Grab Telnet Banner
Command: """nc -vn {IP} 23

Name: Nmap with scripts
Description: Run nmap scripts for telnet
Command: """nmap -n -sV -Pn --script "*telnet*" -p 23 {IP}"""
```

