They're nowhere near as invincible as they want you to believe. Both physically and mentally.

https://boards.4chan.org/pol/thread/310161355

Since I started to get redpilled on the JQ I have wondered why they actually behave the way they do, I couldn't fit the puzzle pieces together. What's the reason they destroy the societies they themselves live in? I will answer this question in three posts.

Reading The Culture of Critique makes it very clear that we have to treat judaism as a group evolutionary strategy.

First off, some premises
>Jews is a coherent group that has a very strong ingroup preference and always work to benefit the tribe. They frequently disagree on the methods but they always work to the benefit of jews as a whole. Even secular jews strongly identify as jews, and the more antisemitic a society becomes, the stronger the jewish identification with the tribe.

>Jews are raised to believe that they are gods chosen people and that goyim are jealous subhumans that are just waiting for an opportunity to shoah them. It is of course of utmost importance for jews to prevent this and in this cause every method is allowed.

>The only group, where jews dwell, that can realistically band together and have a jew barbeque is white gentiles.

With these premises it becomes clear what jews as a group need to do, namely destroy white civilization to the point where no organized resistance can be mounted. Only then, in the mind of the jew, are they safe. The strategies they use are: 

Promote mass immigration.
- First off it weakens gentile society by having more groups competing for resources and generally causes societal instability.
- Second it prevents whites to form a critical mass when whites are a minority.
- Third, in a multicultural society Jews are just one group among others and can't easily be singled out. All jews of all political stances support mass immigration. This of course does not apply to Israel.

Promote women's rights and sexual degeneracy in general. This has many benefits for jews:
- Lower birthrates of white children
- It destroys societal support that promotes high investment parental strategies (marriage, fidelity, christianity)
- White children raised by single parents result in a general lowering of quality of white society. This of course applies to blacks to an even larger degree, but this is of no concern to jews since they are no threat to begin with.

Fake a bunch of science to give an air of legitimacy to all of the above. Examples
- Freudian psychoanalytics which was/is used to promote sexual freedom and degeneracy. It's also used to classify antisemitism as a mental illness.
- Boasian anthropology which was used to "prove" that white societies are worse than indigenous ones and that "all humans are created equal". This is of course very useful in immigration debates.
- Frankfurt school sociology and postmodernism which is used to legitimize destruction of gentile societal norms.

Why do whites allow this you ask? Because we have evovled to be individualistic and jews exploit this fact to the fullest.
>The basic idea is that European groups are highly vulnerable to invasion by strongly collectivist, ethnocentric groups because individualists have less powerful defenses against such groups. The competitive advantage of cohesive, cooperating groups is obvious and is a theme that recurs throughout my trilogy on Judaism.

It's obvious then that whites have to work together as a group to combat this existential threat. Civic nationalism is not an option. Libertarianism is not an option. Socialism is not an option. The only option is white ethnic nationalism.
To quote The Culture of Critique
>What is certain is that the ancient dialectic between Judaism and the West will continue into the foreseeable future. It will be ironic that, whatever anti-Semitic rhetoric may be adopted by the leaders of these defensive movements, they will be constrained to emulate key elements of Judaism as a group evolutionary strategy. Such strategic mimicry will, once again, lead to a “Judaization” of Western societies not only in the sense that their social organization will become more group-oriented but also in the sense that they will be more aware of themselves as a positively evaluated ingroup and more aware of other human groups as competing, negatively evaluated outgroups. In this sense, whether the decline of the European peoples continues unabated or is arrested, it will constitute a profound impact of Judaism as a group evolutionary strategy on the development of Western societies.

![1573343039608.jpg](https://i.imgur.com/FvteXBJ.jpeg)
