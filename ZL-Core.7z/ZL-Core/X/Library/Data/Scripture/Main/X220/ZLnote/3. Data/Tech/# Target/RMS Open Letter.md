https://rms-open-letter.github.io/

Signed:
- Molly de Blanc (Debian Project, GNOME Foundation)
- Nathan Freitas
- Matthew Garrett (Former member of the FSF board of directors)
- Shauna Gordon-McKeon
- Elana Hashman (Debian Technical Committee Member, Open Source Initiative Director, Kubernetes SIG Instrumentation Chair)
- Faidon Liambotis (Open Source Initiative Director)
- Katherine Maher
- Tom Marble (Software Freedom Conservancy, Evaluation Committee Chair)
- Neil McGovern (GNOME Foundation Executive Director, Former Debian Project Leader)
- Deb Nicholson (OSI General Manager, SeaGL Co-Founder)
- Nadya Peek
- Julia Reda
- Eric Schultz
- Joan Touzet (Apache CouchDB PMC, Former Apache Software Foundation Director)
- Luis Villa (Former Director of the Open Source Initiative and the GNOME Foundation; contributor to the GPL v3 drafting process)
- Stefano Zacchiroli (Former Debian Project Leader and Former Director of the Open Source Initiative)

Organizations:
1.  3NSoft
2.  Aaru Data Preservation Suite
3.  Calyx Institute
4.  Ceccun
5.  CH Open
6.  CommitChange
7.  Creative Commons
8.  Cusy
9.  DataMade
10.  Dot HQ
11.  Echap
12.  Exherbo Linux
13.  Fivnex
14.  Freedom of the Press Foundation
15.  The FreeDOS Project
16.  Globenet
17.  GlobaLeaks
18.  GNOME Foundation
19.  GNU Radio
20.  Great Scott Gadgets
21.  Innatical
22.  Kludge Cyber Systems
23.  The HardenedBSD Foundation / The HardenedBSD Project
24.  Metaform
25.  MidnightBSD Project
26.  MousePaw Media
27.  Mozilla
28.  OBS Project
29.  Open Life Science
30.  Open Observatory of Network Interference (OONI)
31.  Open Source Collective
32.  Open Source Diversity
33.  Organization for Ethical Source
34.  Outreachy
35.  Public Laboratory for Open Technology and Science
36.  RACTF
37.  Radial Source
38.  Riseup Networks
39.  Sanctuary Computer
40.  SUSE
41.  SumoStack
42.  TEN7
43.  Tor Project
44.  Velvetyne – Libre and Open Source Foundry
45.  wiquaya.org
46.  X.org Foundation