>oy vey schwartz, go beat up a white goy and I'll give you dollar, nigger
>yessa massa

They really did it for free. Some caught a pair of 90 cent shoes or 77 cent chinese TV.... From a corporation who caught 80% increase in profit. A good slave always works for free.
The niggers who worked for me lost their jobs, and had to accept lower paying jobs at Walmart. Walmart, regardless of months of entire stocks being cleared, received 80% increase in profit. Niggers are TOOLS for corporations, removing competition and giving Corporations higher Job authority.