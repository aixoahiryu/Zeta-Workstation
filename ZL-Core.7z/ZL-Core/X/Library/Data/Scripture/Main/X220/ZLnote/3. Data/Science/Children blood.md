[Young Blood Infusions “Rejuvenate” Old Mice](https://www.scientificamerican.com/article/fountain-of-youth-young-blood-infusions-ldquo-rejuvenate-rdquo-old-mice/)

https://boards.4chan.org/pol/thread/315735861
![38B1F32C-12A2-4E1F-A1A5-9771ECB654F8.jpg](https://i.imgur.com/PQeu5ji.jpg)
![Capture.jpg](https://i.imgur.com/2MZpBXt.jpg)