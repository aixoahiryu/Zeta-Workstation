>airpods score lower than the free disposable earbuds they give you on airplanes in audio quality tests
>airpod max score lower than $30 koss porta pros

https://github.com/jaakkopasanen/AutoEq/blob/master/results/RANKING.md

>ALL AIRPODS AND IPHONES STILL MAX OUT AT 256KBS
>ONLY SUPPORT LOSSY AAC CODECS
>NO LOSSLESS APT-X
>NO APT-X HD (24/48)
>NO SONY LDAC (24/96)
>NO TIDAL HIFI

THE ABSOLUTE STATE OF ONE INFINITE LOO
![1598553966054.png](https://i.imgur.com/2JFPcCz.png)

---

\>\>81444777
Apple is the biggest employer of H1B Indians in Silicon Valley.

>all apple products preloaded with iOS and macOS
>blocks any lincuck distro from even booting with T2
>shifts entire industry to ARM
>ARM allows all PC OEMs to have a unique proprietary locked bootloader for each product they release
>soon ARM stinkpads will come locked to winblows
>every single ARM laptop will be a unique special snowflake like phones and need a custom bootloader exploit and distro built for it
>736 arm laptops released each year mean 736 device specific root exploits, 736 special snowflake builds of the loonix kernel, and 736 custom builds of ubuntu
>multiplied by 521 different distros that's like over a million different distros have to be specifically built to be arm compatible
>freetards will be lucky to crack 10-20 device bootloaders a year
>hobby loonix distros wiped out instantly because neckbeard neets cant just release 1 ISO for 23,768 laptops anymore
>desktops and custom built devices completely extinct without economy of scale manufacturing when corporate purchases shift entirely to ARM
>only major distros will survive on 2-3 stinkpad models that get cracked each year
>loonix market share tanks from 1% to 0.00001% like it is on android/lineage
>loonix purged from all of technology within this decade
>Stallman and FSF cancelled
>freetards all neck themselves

Say it with me now:
THANKYOUBASEDAPPLE

Apple implemented a Do Not Track feature, which in of itself is being tracked by Flurry Analytics. This is the game they do, every once in a while the implement changes that makes it harder/more expensive for their competitors to have services for iPhones and then they put a positive spin on it for the PR.