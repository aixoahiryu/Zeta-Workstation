Valid arguments against Rust:
>you will never be a woman
>seethe, cope, dilate

Meme "advantages" of Rust:
>muh tranny threading
>muh tranny abstractions
>muh tranny traits
>muh tranny errors
>muh tranny community

---

Valid arguments against Rust:
>has one of the worst communities ever that should rightfully be called a cult. They will butcher you for saying anything that isn't agreed upon by the hive mind.
>the way you write Rust is a law far more important than the language itself.
>The language is far from mature and while everyone is bragging about "it gettin included in this and that project" it's simply being tested out in said projects, because it's too early for it to be used anywhere with a new compiler version out all the time
>Rust solves "SAFETEY" the way totalitarian regimes solved street crime. It's essentially fascism but not the based kind.
>It's hard to learn and requires significant prior knowledge in programming which means it has to brainwash programmers from other languages in order to get new crowd
>nearly 40% of rust developers will attempt suicide in their lifetime. Those that decide to transition to fix their gender dysphoria have an even higher rate of attempting suicide.

Valid advantages of Rust:
>If you are too stupid to use C/C++ or any of the TENS of tools that help manage "how scary unsafe they are" and everything else (cuz all the things Rust fixes in C/C++ are a meme for quite a few years now), the language does a perfect job at putting you in a wheelchair so you can roll along with the gang. This is already happening with all the shit C/C++ devs jumping ship to Rust cuz they never heard of Valgrind or learning anything about the compiler they use.

---

The "Rust community" and the "Rust foundation" refuse to cooperate with the rest of the free software movement. Their shitty compiler takes hours to compile things that can be done in seconds/minutes in GCC. Rust doesn't even have standards, is a moving constantly changing target, and they sperg out and cancel anyone that doesn't follow their one true way. Their language doesn't run on the majority of hardware in the wild but they want to replace lots of low level C code with it. If you say
>but I'm on <uncommon arch> and your code won't run here
They tell you it's your problem. If you say
>but this Rust replacement takes days to compile on my old hardware when the old C version worked fine and compiled in 15 minutes
They tell you to use their unaudited binary.

Do you remember when tons of webshitter javascript framework based projects (npm) got pwned because someone removed a simple script that a bunch of shit relied on? The Rust ecosystem works the same way. The language is a regression compared to C/C++. The "memory safety" they jerk off to is a meme riddled with exploits just waiting to be pwned. Go look at who sits on the Rust Foundation and you'll understand why it shouldn't be trusted by anyone.

---

There is only one working compiler and there is not enough defined or standards to write one.
Rust shills want it to be considered as a well established languages like C++, C, Java, etc without putting in the work. There is risk to using a language with one implementation especially one as complex as rust.

Personally I don't loose a lot of time to memory errors when writing in C++ so there goes the main selling point of rust, not to mention I thought C++ build times where bad before I checked rust out.

Another complaint I have is less about the language it self but the community can be horrid, for a community that labels it self as "friendly" I have not seen a more vicious group of people I feel bad for the Actix web guy & others.

All in all none of the reasons I listed on there own are enough to kill rust for me. but combined I honestly lost all interest in using or dealing with rust. Not to mention modern C++ is quite nice compared to the old stuff :^)

I dont think rust is a bad language, but I also dont think its "better" then C++ or other options. I like what rust is doing, its getting other languages to think more about what there compilers can do to make our lives simpler. But I my self will not be using, hopefully rust will inspire some new languages and changes to old ones.

A hint to the rust shills, if you want to sell rust, try being less fanatical, it scares normal people away.

---

![no_rust_systemd.jpg](https://i.imgur.com/B1SPdsJ.jpeg)
![no_rust_systemd2.jpg](https://i.imgur.com/sh25LTc.jpeg)

>yes dude why don't you just rewrite your million lines of code init system and adapt it to new unknown language with unknown vulnerabilities and hickups not yet discovered as it's basically beta testing work in progress language?
>But it's memory safe (even though we have to disable the checks for it to work)

rust shills are absolute idiots with no self-awareness who instead of creating something just try to impose their religion to others, many such cases.

---

I am trying to give Rust a go just so I know something about the lang when I speak about it and not be a blind hater, but the more I try the more I find out it's not for me. Rust solves memory safety the same way fascism solves street crime. It's literally a diaper or even a wheelchair for coding. First of all Rust is used only for "rewriting" shit so far and second of all it's mainly pushed forward by a cult-like following of people who claim to solve subjective issues in other languages... that were already fixed long time ago. And the syntax makes me want to kill myself. No fuckin idea what was going through the head of the guy who invented it. So much useless bullshit it ain't real.

---

1. Rust is only supported only on major platforms. Introducing Rust will cause inability to run new Linux kernel on already supported platforms just to satisfy few developers. I guess rust devs don't care about exotic platforms like m68k but some people care and this is harmful towards minorities.
2. This causes precedent of introducing major language to kernel and will cause discussion about "why we don't introduce C++, Go, Java or JS to kernel? Rust was fine, right?". Linus cut this topic a long time ago and it was good.
3. It may cause kernel driver bloat due to Rust being less scary than C and attracting poor quality developers that will port everything into kernel space

---

![rust-for-thee-not-for-me.png](https://i.imgur.com/fzzVkyx.png)
Despite Poettering virtue signal about how great Rust is
https://twitter.com/pid_eins/status/1083700773714911232
When it is suggested that systemd replace C with rust, he is picrel

Do rustfags actually write code or only screech about other languages? 
the rust foundation:
Amazon Web Services, Huawei, Google, Microsoft, and Mozilla
it's all about shilling unusable cancer so these corporations can dictate and control the future of the language. rust shills can't code in any language. they're nothing more than sad corporate prostitutes.

ethical software movement hates open source and free software because open and free means freedom of thought, speech, privacy and expression, these are big no nos whenever they are in conflict with their ideology. Rather than admit to the hypocrisy and inconsisteny, they will just destroy these tenets of free as in freedom software
rust community shares basically everything with this fascist movement
it's very obvious where rustrannies want to take softwares that do not comply with their backward ideology

---

Projects that are "open source" now frequently require binary blobs that are not open. For example, https://github.com/rapi3/pfsense-is-closed-source
![libre#rust.png f8gCF1I.png](https://i.imgur.com/f8gCF1I.png)

\>\>80861089 (OP)
\>\>80861444
You dodged a big bullet OP. You avoided the madness that is the Rust compiler. Where they suggest by-passing your OS's repos and trusting bins from their servers instead. In addition to being a slow piece of shit you're forced to update it every other week because the language is still very unstable. If you miss two updates you have to start all over again with a new bin. Their own compiler can't even compile itself after two updates. It's nothing like GCC where as long as you have 10 year old version around you can compile the new one. With Rust nothing is stable or guaranteed.

https://lwn.net/Articles/845535

If you want a laugh go read the Gentoo mailing list. The Rust trannys show up there all of the time demanding Rust get special treatment within the Gentoo OS. They say Gentoo shouldn't provide a way to install Rust from source. They want "Rustup" to become part of Gentoo's base system. It's really pathetic. Gentoo makes them seethe. Rust trannys claim end users shouldn't be trusted with source code.

I chuckle every time I see them shilling their terminal emulator. They claim it's the best terminal but it takes like 2 hours to compile on a modern CPU. It's like compiling firefox or chrome. All for a terminal that doesn't do anything you can't do in st.

---

`for i in (0..10).step_by(2).rev().take_while(cond) {}`
![clean_rust.png](https://i.imgur.com/eBmB7N1.png)

---

>Rust’s memory safety guarantees make it difficult, but not impossible, to accidentally create memory that is never cleaned up (known as a memory leak). Preventing memory leaks entirely is not one of Rust’s guarantees in the same way that disallowing data races at compile time is.

Directly from the Rust book itself. They even admit it.
C allows you to manually fix it. It has manual management.
Rust has no options for this. If memory leaks, you either have to go back and refactor HUMONGOUS chunks of code, or just live with it. There are no manual management options.

In C, you can just free up memory leaks in a single line.
In Rust, you have to check a bunch of safe code, find the leak, and refactor the whole code block the correct the leak, because delete() just doesn't exist.

![rust032.jpg aoYuROZ.jpg](https://i.imgur.com/aoYuROZ.jpg)
>find random troon profile on literally an platform
>click through their stuff
>invariably leads back to Rust

---

## Counter

>Linux itself is starting to infegrate Rust

It's just upstream wrappers for C code so that rust drivers won't break because the tranny maintainer joined the 44% and couldn't modify the wrappers on time.

---

>older is bad because it is older
>newer good because newer

Do you retards really mistake this for an actual argument?
>Oy vey cishet goyim but I didn’t say that I only accused Germfag of being unable to learn new tricks!
If there is no point in learning something then why would anyone learn it? You have yet to explain why anyone would want to learn it besides your circular hype argument