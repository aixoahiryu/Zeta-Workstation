# SAML Basics

## Description

Security Assertion Markup Language \(SAML\) is an open standard that allows identity providers \(IdP\) to pass authorization credentials to service providers \(SP\). What that jargon means is that you can **use one set of credentials to log into many different websites**. It’s much simpler to manage one login per user than it is to manage separate logins to email, customer relationship management \(CRM\) software, Active Directory, etc.

SAML transactions use Extensible Markup Language \(XML\) for standardized communications between the identity provider and service providers. SAML is the link between the authentication of a user’s identity and the authorization to use a service. \(From [here](https://www.varonis.com/blog/what-is-saml/)\)

## SAML vs. OAuth

OAuth is a slightly newer standard that was co-developed by Google and Twitter to enable streamlined internet logins. OAuth uses a similar methodology as SAML to share login information. **SAML provides more control** to enterprises to keep their SSO logins more secure, whereas **OAuth is better on mobile and uses JSON**.

## Schema

![saml-flow](https://epi052.gitlab.io/notes-to-self/img/saml/saml-flow.jpg)

1. Step 1 - We try to access some protected resource
2. Step 2 - The server where that resource resides \(Service Provider\) doesn’t know us, so it generates a **SAML Request** to be sent to the Identity Provider. This would be like showing up to Germany without our passport and getting sent back to the US to get our passport before being able to get into the country.
3. Step 3 - After generating the SAML Request, the SP **redirects** us to the IdP. Note: The SAML Request passes through our browser on the way to the IdP.
4. Step 4 - The IdP receives the SAML Request
5. Step 4a \(not pictured\) - The IdP provides some means of authentication; a login form or something similar.
6. Step 4b \(not pictured\) - The IdP validates us as a legitimate user that should be allowed to access the resource included as part of the SAML Request
7. Step 5 - The IdP creates a **SAML Response**. The SAML Response contains the SAML Assertions necessary for the SP. The Assertion usually includes the following information at a minimum: Indication that the Assertion is from the correct IdP, a **NameID** attribute specifying who the user is, and a digital signature. The SAML Response also passes through our browser.
8. Step 6 - The IdP **redirects** us to the SP’s Assertion Consumer Service \(ACS\) URL. The ACS is simply the URL on which the SP expects to receive SAML assertions.
9. Step 7 - The ACS validates the SAML Response.
10. Step 8 - We are allowed to access the resource we originally requested.

## SAML Request Example

Let’s take a closer look at steps 2 and 3 outlined above. We’ll make a request to the example Service Provider for the resource located at [https://shibdemo-sp1.test.edu/secure/](https://shibdemo-sp1.test.edu/secure/), which as its name implies, is content that requires us to be authenticated to view.

_shibdemo-sp1.test.edu is a local virtualized instance of an IdP and SP for testing, not an actual site_

```text
GET /secure/ HTTP/1.1
Host: shibdemo-sp1.test.edu
User-Agent: Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:65.0) Gecko/20100101 Firefox/65.0
Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8
Accept-Language: en-US,en;q=0.5
Accept-Encoding: gzip, deflate
Referer: https://shibdemo-sp1.test.edu/
Connection: close
Upgrade-Insecure-Requests: 1
```

The SP generates a SAML Request because we’re not authenticated. We can see the raw SAML Request below.

```markup
<?xml version="1.0"?>
<samlp:AuthnRequest 
    xmlns:samlp="urn:oasis:names:tc:SAML:2.0:protocol" 
    AssertionConsumerServiceURL="https://shibdemo-sp1.test.edu/Shibboleth.sso/SAML2/POST" 
    Destination="https://shibdemo-idp.test.edu/idp/profile/SAML2/Redirect/SSO" 
    ID="_cdae718238ba9c207a35cc7c70b046a0" 
    IssueInstant="2019-03-12T20:54:58Z" 
    ProtocolBinding="urn:oasis:names:tc:SAML:2.0:bindings:HTTP-POST" 
    Version="2.0">
    <saml:Issuer xmlns:saml="urn:oasis:names:tc:SAML:2.0:assertion">https://shibdemo-sp1.test.edu/shibboleth</saml:Issuer>
    <samlp:NameIDPolicy AllowCreate="1"/>
</samlp:AuthnRequest>
```

* **AssertionConsumerServiceURL**: Identifies where the IdP should send the SAML Response to after authentication
* **Destination**: Indicates the address to which the request should be sent \(IdP\)
* **ProtocolBinding**: Typically accompanies the AssertionConsumerServiceURL attribute; defines the mechanism by which SAML protocol messages will be transmitted
* **saml:Issuer**: Identifies the entity that generated the request message

We’ve outlined the more pertinent elements of the request above, but details about any of the other elements can be viewed in the [core specification](https://docs.oasis-open.org/security/saml/v2.0/saml-core-2.0-os.pdf). The request above goes something like this: “Hey, please authenticate the user that sent this message to you and then have that same user hit me up when you two are done”.

With the SAML Request created, the SP now replies to our GET request for `/secure/` with a **302 redirect**. The 302 directs our browser to head over to the IdP. The SAML Request is encoded into the HTTP response’s **Location** header as part of the 302.

```markup
HTTP/1.1 302 Found
Date: Tue, 12 Mar 2019 20:54:58 GMT
Server: Apache/2.2.3 (CentOS)
Expires: Wed, 01 Jan 1997 12:00:00 GMT
Cache-Control: private,no-store,no-cache,max-age=0
Location: https://shibdemo-idp.test.edu/idp/profile/SAML2/Redirect/SSO?SAMLRequest=fZJdT4MwFIb%2FCuk9FNgmWzNIcLtwyXRkoBfemFKO0gRa7Cl%2B%2FHvZmDoTs8u2b5%2B350mXyNumY2lva7WH1x7QOh9to5AdD2LSG8U0R4lM8RaQWcHy9HbLQs9nndFWC90QJ0UEY6VWK62wb8HkYN6kgPv9Nia1tR0ySrGWZQWtdrELPDs0eVD1NB92S92ArT1ETQ%2FwkGa7vCDOeshIxQ%2Fcfyiy6n4pw4IOz3mWDZwQe6ikAWFpnu%2BIs1nH5ElUHKJgHk7mJV%2BI0I%2F4ZCZEJCK%2F9KdX3B9iiD1sFFqubExCP1i4%2FsQNwiL02WzKZvNH4mSnqa%2BlqqR6uayoHEPIbooic8exHsDgcaQhQJLlQTQ7Fpsz9Zex%2FNs3SS7bxR%2B7S3pWNLZ27G4gb9aZbqT4dNKm0e8rA9xCTAJCk%2FHK39%2BRfAE%3D&RelayState=ss%3Amem%3A39430bdac29d44586c326f12b4cb3345ffa47137a374e37cba0877e0fc79ea91
Content-Length: 897
Connection: close
Content-Type: text/html; charset=iso-8859-1

<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML 2.0//EN">
<html><head>
<title>302 Found</title>
</head><body>
<h1>Found</h1>
<p>The document has moved <a href="https://shibdemo-idp.test.edu/idp/profile/SAML2/Redirect/SSO?SAMLRequest=fZJdT4MwFIb%2FCuk9FNgmWzNIcLtwyXRkoBfemFKO0gRa7Cl%2B%2FHvZmDoTs8u2b5%2B350mXyNumY2lva7WH1x7QOh9to5AdD2LSG8U0R4lM8RaQWcHy9HbLQs9nndFWC90QJ0UEY6VWK62wb8HkYN6kgPv9Nia1tR0ySrGWZQWtdrELPDs0eVD1NB92S92ArT1ETQ%2FwkGa7vCDOeshIxQ%2Fcfyiy6n4pw4IOz3mWDZwQe6ikAWFpnu%2BIs1nH5ElUHKJgHk7mJV%2BI0I%2F4ZCZEJCK%2F9KdX3B9iiD1sFFqubExCP1i4%2FsQNwiL02WzKZvNH4mSnqa%2BlqqR6uayoHEPIbooic8exHsDgcaQhQJLlQTQ7Fpsz9Zex%2FNs3SS7bxR%2B7S3pWNLZ27G4gb9aZbqT4dNKm0e8rA9xCTAJCk%2FHK39%2BRfAE%3D&amp;RelayState=ss%3Amem%3A39430bdac29d44586c326f12b4cb3345ffa47137a374e37cba0877e0fc79ea91">here</a>.</p>
<hr>
<address>Apache/2.2.3 (CentOS) Server at shibdemo-sp1.test.edu Port 443</address>
</body></html>
```

The **RelayState** parameter sent along with the SAML Request is state information sent by the SP to the IdP so that the SP knows who initially asked for the resource when the SAML Response comes back. The SAML Response must contain the same RelayState value.

The **SAMLRequest** parameter is a **compressed** and **encoded** version of the same raw xml snippet we looked at earlier. SAML uses the [Deflate compression](https://en.wikipedia.org/wiki/DEFLATE) algorithm then base64 encodes the result.

## SAML Response Example

We’re going to eschew stepping through the part where the user authenticates to the IdP and jump straight into steps 5 and 6 from what was discussed in the [SAML Authentication Workflow](https://epi052.gitlab.io/notes-to-self/blog/2019-03-07-how-to-test-saml-a-methodology/#saml-authentication-workflow). Just keep in mind that what **we’re going to look at happens after the user authenticates to the IdP.**

Let’s start by taking a look at the raw SAML Response.

```markup
<?xml version="1.0" encoding="UTF-8"?>
<samlp:Response Destination="https://shibdemo-sp1.test.edu/Shibboleth.sso/SAML2/POST" ID="_2af3ff4a06aa82058f0eaa8ae7866541" InResponseTo="_cdae718238ba9c207a35cc7c70b046a0" IssueInstant="2019-03-12T20:54:54.061Z" Version="2.0" xmlns:samlp="urn:oasis:names:tc:SAML:2.0:protocol">
    <saml:Issuer Format="urn:oasis:names:tc:SAML:2.0:nameid-format:entity" xmlns:saml="urn:oasis:names:tc:SAML:2.0:assertion">https://shibdemo-idp.test.edu/idp/shibboleth</saml:Issuer>  
    <ds:Signature xmlns:ds="http://www.w3.org/2000/09/xmldsig#">
    <ds:SignedInfo>
      <ds:CanonicalizationMethod Algorithm="http://www.w3.org/2001/10/xml-exc-c14n#"/>
      <ds:SignatureMethod Algorithm="http://www.w3.org/2000/09/xmldsig#rsa-sha1"/>
      <ds:Reference URI="#_2af3ff4a06aa82058f0eaa8ae7866541">
        <ds:Transforms>
          <ds:Transform Algorithm="http://www.w3.org/2000/09/xmldsig#enveloped-signature"/>          <ds:Transform Algorithm="http://www.w3.org/2001/10/xml-exc-c14n#"/>
        </ds:Transforms>
        <ds:DigestMethod Algorithm="http://www.w3.org/2000/09/xmldsig#sha1"/>
        <ds:DigestValue>Se+WwXd5r44J56LauTz/wnP3jWg=</ds:DigestValue>
      </ds:Reference>
    </ds:SignedInfo>
    <ds:SignatureValue>f8X28hHMpnTi/Hqi6phuxqbYKsf99Qi8QqVI3x3zRj6njs+J9ey7qxw4GTMV657IfmmMotE0IAIrmPh3lebX65bCUCpiDtFaP04KjWNGGWa7z6rjwhRIY6chYGYzdmrXWmvY2EXW3nkynAJ2vXo5mncOz2P17/bQgqDU6BTzfRzYU6q6TcGLjRd7pGMGbBm6wH5c8aHM4FaQZNv7qHkIVvTlCRcpg/b8qS2fWW8kwgklLXd1xTCXh9XedxrFWq75nSFZ6FiakfUMybC5YIqZ7nr4GfVKqdmh3wvCF/P9jrUkBNDsw3Id63UAwbnMVvBAYt2tgfiD5hpJ3ZLkzjds+g==</ds:SignatureValue>
    <ds:KeyInfo>
      <ds:X509Data>
        <ds:X509Certificate>MIIDXTCCAkWgAwIBAgIJAO7P8i9TJMuvMA0GCSqGSIb3DQEBCwUAMEUxCzAJBgNVBAYTAkFVMRMwEQYDVQQIDApTb21lLVN0YXRlMSEwHwYDVQQKDBhJbnRlcm5ldCBXaWRnaXRzIFB0eSBMdGQwHhcNMTgwNDA1MDI1NTUyWhcNMjgwNDA0MDI1NTUyWjBFMQswCQYDVQQGEwJBVTETMBEGA1UECAwKU29tZS1TdGF0ZTEhMB8GA1UECgwYSW50ZXJuZXQgV2lkZ2l0cyBQdHkgTHRkMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAwfSJJxxWvJ2Xok+Qx1OwQa+LA6mTSomOrgcJkRhfjeA9LMBmQlZKMdHiwKCaJBm7l1G13CNN2XhBZBqLFEX/4pPO5WBakAEa8h1i1ODmge1NKntcr3jPG8pGrzQVFbTpyoPaeJM5nSJUJhdI+QlXEYRZ2WUpKrrPXaG4O/bKFQ4FP7tRiYMi7SZde0QOUSTUlO14JA5L3jNUk0eha2hVULyCEa9WjbfOfw+0TvE32MrAhsu4QJQgr18q1x4+GNuOI0LkX1/WehXDstyjX68CxHRSNfsarX7HeOvqn8HbGkIAKMG1ldmSkyvJ0DrvEU+0wTxaTXxFR+zwFOBnSKIVBwIDAQABo1AwTjAdBgNVHQ4EFgQUn3h8qx+ssGm8balncHSF9hi01NQwHwYDVR0jBBgwFoAUn3h8qx+ssGm8balncHSF9hi01NQwDAYDVR0TBAUwAwEB/zANBgkqhkiG9w0BAQsFAAOCAQEAuVmxbUhFA8cdnxgwHWYXniebXpPNMfoMBPpMao20uv9dkKHH2AzuT7TWAICiSj29ZuHEVJaK1mfwErr+R8etKnGT0tA53/509+gWG0eCQSh+AF/VPWQ4JRoPMszKdLzl4surnNOA5JegKVvTcT91+G+OWv0hB4iMD/quegLSBfrlbtyTT58Moj33wDDhaMH1Dlm23zfgB/0w3ztZnnmdxXJxGZuLiybJXTMbkjhUk41udHTQcsxKdaRoaQobDNdbqyl245RP15QXKphaz8DadCyH4v8o5NIU5lZyEG7KCpWnqWe6au6OrbGqBkqDIrEue3Wnu+TFaJRXBd12D9Xb8g==</ds:X509Certificate>
      </ds:X509Data>
    </ds:KeyInfo>
  </ds:Signature>
  <samlp:Status>
    <samlp:StatusCode Value="urn:oasis:names:tc:SAML:2.0:status:Success"/>
  </samlp:Status>
  <saml:Assertion xmlns:xs="http://www.w3.org/2001/XMLSchema" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" ID="_e0acf8ced7e2cafc7c65b2c097842486e0838d76e0" IssueInstant="2019-03-13T22:44:33Z" Version="2.0">
    <saml:Issuer>https://shibdemo-idp.test.edu/idp/shibboleth</saml:Issuer>
    <ds:Signature xmlns:ds="http://www.w3.org/2000/09/xmldsig#">
      <ds:SignedInfo>
        <ds:CanonicalizationMethod Algorithm="http://www.w3.org/2001/10/xml-exc-c14n#"/>
        <ds:SignatureMethod Algorithm="http://www.w3.org/2000/09/xmldsig#rsa-sha1"/>
        <ds:Reference URI="#_e0acf8ced7e2cafc7c65b2c097842486e0838d76e0">
          <ds:Transforms>
            <ds:Transform Algorithm="http://www.w3.org/2000/09/xmldsig#enveloped-signature"/>
            <ds:Transform Algorithm="http://www.w3.org/2001/10/xml-exc-c14n#"/>
          </ds:Transforms>
          <ds:DigestMethod Algorithm="http://www.w3.org/2000/09/xmldsig#sha1"/>
          <ds:DigestValue>kDAb3x6EFvA9VblqwbIFcCnLQvo=</ds:DigestValue>
        </ds:Reference>
      </ds:SignedInfo>
      <ds:SignatureValue>e6qavbOCH8YAAMzDXnEwT4R7VBvan2gfYU6f5M1Akp6bqZqu3H4iJ5/VKtkMb7773E4RtDpY1vy9+6hLd/BQ2V5ZN6HG12JOVAgCr9rzna2sgNDYzGfmHsOwD9QJTOYZIFU3mtOSK6Lk8bZxM7wK5X0vmRNHI5a3oQlbWy9O6NtqZdm2AwI+zXb2ePV6lILjyoGkeuRId/35lA57OW+lBsGSz1T/X+5kVBdWRAYib2FAvGLIxInLt7jEDDfh93unL+YcbXevRcQLnKzrqTmu9TFIq+w0KeEnYxxPtCCmnnv86LWDhW30RJH2cS7kTsHa271RPsCCuutJD1QSaxVP1w==
      </ds:SignatureValue>
      <ds:KeyInfo>
        <ds:X509Data>
          <ds:X509Certificate>MIIDXTCCAkWgAwIBAgIJAO7P8i9TJMuvMA0GCSqGSIb3DQEBCwUAMEUxCzAJBgNVBAYTAkFVMRMwEQYDVQQIDApTb21lLVN0YXRlMSEwHwYDVQQKDBhJbnRlcm5ldCBXaWRnaXRzIFB0eSBMdGQwHhcNMTgwNDA1MDI1NTUyWhcNMjgwNDA0MDI1NTUyWjBFMQswCQYDVQQGEwJBVTETMBEGA1UECAwKU29tZS1TdGF0ZTEhMB8GA1UECgwYSW50ZXJuZXQgV2lkZ2l0cyBQdHkgTHRkMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAwfSJJxxWvJ2Xok+Qx1OwQa+LA6mTSomOrgcJkRhfjeA9LMBmQlZKMdHiwKCaJBm7l1G13CNN2XhBZBqLFEX/4pPO5WBakAEa8h1i1ODmge1NKntcr3jPG8pGrzQVFbTpyoPaeJM5nSJUJhdI+QlXEYRZ2WUpKrrPXaG4O/bKFQ4FP7tRiYMi7SZde0QOUSTUlO14JA5L3jNUk0eha2hVULyCEa9WjbfOfw+0TvE32MrAhsu4QJQgr18q1x4+GNuOI0LkX1/WehXDstyjX68CxHRSNfsarX7HeOvqn8HbGkIAKMG1ldmSkyvJ0DrvEU+0wTxaTXxFR+zwFOBnSKIVBwIDAQABo1AwTjAdBgNVHQ4EFgQUn3h8qx+ssGm8balncHSF9hi01NQwHwYDVR0jBBgwFoAUn3h8qx+ssGm8balncHSF9hi01NQwDAYDVR0TBAUwAwEB/zANBgkqhkiG9w0BAQsFAAOCAQEAuVmxbUhFA8cdnxgwHWYXniebXpPNMfoMBPpMao20uv9dkKHH2AzuT7TWAICiSj29ZuHEVJaK1mfwErr+R8etKnGT0tA53/509+gWG0eCQSh+AF/VPWQ4JRoPMszKdLzl4surnNOA5JegKVvTcT91+G+OWv0hB4iMD/quegLSBfrlbtyTT58Moj33wDDhaMH1Dlm23zfgB/0w3ztZnnmdxXJxGZuLiybJXTMbkjhUk41udHTQcsxKdaRoaQobDNdbqyl245RP15QXKphaz8DadCyH4v8o5NIU5lZyEG7KCpWnqWe6au6OrbGqBkqDIrEue3Wnu+TFaJRXBd12D9Xb8g==</ds:X509Certificate>
        </ds:X509Data>
      </ds:KeyInfo>
    </ds:Signature>
    <saml:Subject>
      <saml:NameID Format="urn:oasis:names:tc:SAML:2.0:nameid-format:transient" SPNameQualifier="https://shibdemo-sp1.test.edu/shibboleth">_29b7a1a396d841b09fcf2b0bd8ce88fed6ad70e1a7</saml:NameID>
      <saml:SubjectConfirmation Method="urn:oasis:names:tc:SAML:2.0:cm:bearer">
        <saml:SubjectConfirmationData InResponseTo="_cdae718238ba9c207a35cc7c70b046a0" NotOnOrAfter="2019-03-13T22:49:33Z" Recipient="https://shibdemo-sp1.test.edu/Shibboleth.sso/SAML2/POST"/>
      </saml:SubjectConfirmation>
    </saml:Subject>
    <saml:Conditions NotBefore="2019-03-13T22:44:03Z" NotOnOrAfter="2019-03-13T22:49:33Z">
      <saml:AudienceRestriction>
        <saml:Audience>https://shibdemo-sp1.test.edu/shibboleth</saml:Audience>
      </saml:AudienceRestriction>
    </saml:Conditions>
    <saml:AuthnStatement AuthnInstant="2019-03-13T22:44:33Z" SessionIndex="_a52c3c1242663b44b706523f0a2ada454eb997e40a" SessionNotOnOrAfter="2019-03-14T06:44:33Z">
      <saml:AuthnContext>
        <saml:AuthnContextClassRef>urn:oasis:names:tc:SAML:2.0:ac:classes:Password</saml:AuthnContextClassRef>
      </saml:AuthnContext>
    </saml:AuthnStatement>
    <saml:AttributeStatement>
      <saml:Attribute Name="uid" NameFormat="urn:oasis:names:tc:SAML:2.0:attrname-format:basic">
        <saml:AttributeValue xsi:type="xs:string">epi</saml:AttributeValue>
      </saml:Attribute>
      <saml:Attribute Name="mail" NameFormat="urn:oasis:names:tc:SAML:2.0:attrname-format:basic">
        <saml:AttributeValue xsi:type="xs:string">epi@test.edu</saml:AttributeValue>
      </saml:Attribute>
      <saml:Attribute Name="first_name" NameFormat="urn:oasis:names:tc:SAML:2.0:attrname-format:basic">
        <saml:AttributeValue xsi:type="xs:string">epi</saml:AttributeValue>
      </saml:Attribute>
      <saml:Attribute Name="last_name" NameFormat="urn:oasis:names:tc:SAML:2.0:attrname-format:basic">
        <saml:AttributeValue xsi:type="xs:string">bar</saml:AttributeValue>
      </saml:Attribute>
    </saml:AttributeStatement>
  </saml:Assertion>
</samlp:Response>
```

* **ds:Signature**: An [XML Signature](https://www.w3.org/TR/xmldsig-core1/#sec-KeyInfo) that protects the integrity of and authenticates the issuer of the assertion; the SAML assertion MAY be signed but doesn’t have to be. The example above contains two ds:Signature elements. The reason is that one is the message’s signature; the other is the Assertion’s signature.
* **saml:Assertion**: Contains information about the user’s identity and potentially other user attributes.
* **saml:Subject**: Specifies the principal that is the subject of all of the statements in the assertion.
* **saml:StatusCode**: A code representing the status of the activity carried out in response to the corresponding request.
* **saml:Conditions**: Specifies things like the time an Assertion is valid and that the Assertion is addressed to a particular Service Provider.
* **saml:AuthnStatement**: States that the IdP authenticated the Subject of the Assertion.
* **saml:AttributeStatement**: Contains Attributes that describe the Subject of the Assertion.

Here’s a more straightforward visual representation of the same SAML Response.

![response-layout](https://epi052.gitlab.io/notes-to-self/img/saml/response-layout.png)

Now that we’ve authenticated with the IdP and it has generated the SAML Response above, it responds to our authentication with another 302 redirect.

```text
HTTP/1.1 302 Moved Temporarily
Date: Tue, 12 Mar 2019 20:54:53 GMT
Expires: 0
Cache-Control: no-cache, no-store, must-revalidate, max-age=0
Pragma: no-cache
Set-Cookie: _idp_session=MTkyLjE2OC4xLjk2%7CNmE1OWIwOTkxMjkzZjMyOTk2Yjg3NzE0NWNjYTkwYTliNGM1NDViZjRkZDhmY2M5OGQ2NmVjOGZlZTc0NzY1Ng%3D%3D%7CXWP3eN6ZeRPWk%2Bnj5AhRklHyIyU%3D; Version=1; Path=/idp; Secure
Location: https://shibdemo-idp.test.edu:443/idp/profile/SAML2/Redirect/SSO
Content-Length: 0
Connection: close
Content-Type: text/plain; charset=UTF-8
```

The 302 ultimately leads to us making a POST request to the Service Provider’s Assertion Consumer Service URL. The POST body contains the RelayState and SAMLResponse parameters. Recall that the ACS processes and validates the SAML Response.

```markup
POST /Shibboleth.sso/SAML2/POST HTTP/1.1
Host: shibdemo-sp1.test.edu
User-Agent: Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:65.0) Gecko/20100101 Firefox/65.0
Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8
Accept-Language: en-US,en;q=0.5
Accept-Encoding: gzip, deflate
Referer: https://shibdemo-idp.test.edu/idp/profile/SAML2/Redirect/SSO
Content-Type: application/x-www-form-urlencoded
Content-Length: 12314
Connection: close
Upgrade-Insecure-Requests: 1

RelayState=ss%3Amem%3A39430bdac29d44586c326f12b4cb3345ffa47137a374e37cba0877e0fc79ea91&SAMLResponse=PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz48c2FtbDJwOlJlc3BvbnNlIHhtbG5zOnNhbWwycD0idXJuOm9hc2lzOm5hbWVzOnRjOlNBTUw6Mi4wOnByb3RvY29sIiBEZXN0aW5hdGlvbj0iaHR0cHM6Ly9zaGliZGVtby1zcDEudGVzdC5lZHUvU2hpYmJvbGV0aC5zc28vU0FNTDIvUE9TVCIgSUQ9Il8yYWYzZmY0YTA2YWE4MjA1OGYwZWFhOGFlNzg2NjU0MSIgSW5SZXNwb25zZVRvPSJfY2RhZTcxODIzOGJhOWMyMDdhMzVjYzdjNzBiMDQ2YTAiIElzc3VlSW5zdGFudD0iMjAxOS0wMy0xMlQyMDo1NDo1NC4wNjFaIiBWZXJzaW9uPSIyLjAiPjxzYW1sMjpJc3N1ZXIgeG1sbnM6c2FtbDI9InVybjpvYXNpczpuYW1lczp0YzpTQU1MOjIuMDphc3NlcnRpb24iIEZvcm1hdD0idXJuOm9hc2lzOm5hbWVzOnRjOlNBTUw6Mi4wOm5hbWVpZC1mb3JtYXQ6ZW50aXR5Ij5odHRwczovL3NoaWJkZW1vLWlkcC50ZXN0LmVkdS9pZHAvc2hpYmJvbGV0aDwvc2FtbDI6SXNzdWVyPjxzYW1sMnA6U3RhdHVzPjxzYW1sMnA6U3RhdHVzQ29kZSBWYWx1ZT0idXJuOm9hc2lzOm5hbWVzOnRjOlNBTUw6Mi4wOnN0YXR1czpTdWNjZXNzIi8%2BPC9zYW1sMnA6U3RhdHVzPjxzYW1sMjpFbmNyeXB0ZWRBc3NlcnRpb24geG1sbnM6c2FtbDI9InVybjpvYXNpczpuYW1lczp0YzpTQU1MOjIuMDphc3NlcnRpb24iPjx4ZW5jOkVuY3J5cHRlZERhdGEgeG1sbnM6eGVuYz0iaHR0cDovL3d3dy53My5vcmcvMjAwMS8wNC94bWxlbmMjIiBJZD0iXzNmZWYzNGViYTU1OWFmYmZhOWMxMGM4OTg4ZDcyMjA5IiBUeXBlPSJodHRwOi8vd3d3LnczLm9yZy8yMDAxLzA0L3htbGVuYyNFbGVtZW50Ij48eGVuYzpFbmNyeXB0aW9uTWV0aG9kIEFsZ29yaXRobT0iaHR0cDovL3d3dy53My5vcmcvMjAwMS8wNC94bWxlbmMjYWVzMTI4LWNiYyIgeG1sbnM6eGVuYz0iaHR0cDovL3d3dy53My5vcmcvMjAwMS8wNC94bWxlbmMjIi8%2BPGRzOktleUluZm8geG1sbnM6ZHM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvMDkveG1sZHNpZyMiPjx4ZW5jOkVuY3J5cHRlZEtleSBJZD0iXzYxNzgyYWUxZjEwYmZmODdlYjI1NDIxNGJiNGI4MzMyIiB4bWxuczp4ZW5jPSJodHRwOi8vd3d3LnczLm9yZy8yMDAxLzA0L3htbGVuYyMiPjx4ZW5jOkVuY3J5cHRpb25NZXRob2QgQWxnb3JpdGhtPSJodHRwOi8vd3d3LnczLm9yZy8yMDAxLzA0L3htbGVuYyNyc2Etb2FlcC1tZ2YxcCIgeG1sbnM6eGVuYz0iaHR0cDovL3d3dy53My5vcmcvMjAwMS8wNC94bWxlbmMjIj48ZHM6RGlnZXN0TWV0aG9kIEFsZ29yaXRobT0iaHR0cDovL3d3dy53My5vcmcvMjAwMC8wOS94bWxkc2lnI3NoYTEiIHhtbG5zOmRzPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwLzA5L3htbGRzaWcjIi8%2BPC94ZW5jOkVuY3J5cHRpb25NZXRob2Q%2BPGRzOktleUluZm8%2BPGRzOlg1MDlEYXRhPjxkczpYNTA5Q2VydGlmaWNhdGU%2BTUlJQy9UQ0NBZVdnQXdJQkFnSUpBT2Q3UEUxdWFhVWhNQTBHQ1NxR1NJYjNEUUVCQlFVQU1CMHhHekFaQmdOVkJBTVRFbE5vYVdKawpaVzF2TFhOd01TNXNiMk5oYkRBZUZ3MHhNVEV3TWpFd016VXhNalZhRncweU1URXdNVGd3TXpVeE1qVmFNQjB4R3pBWkJnTlZCQU1UCkVsTm9hV0prWlcxdkxYTndNUzVzYjJOaGJEQ0NBU0l3RFFZSktvWklodmNOQVFFQkJRQURnZ0VQQURDQ0FRb0NnZ0VCQUxldnFJWjEKOG1MQzZhU1gwSnNXdS81SnBlR0VMbGVLbFRabmtJaUt3Ny9FVnN6N0VmZEZhVEd6cU1pTjFlTS83NjY1bTFBcHhJVUpibnN1cE15Ywo5Mm9WaFpJcDNxVU5mMTExMldJNlovL1dOWThFTVU4WXdheUxGSmdjQUkxVHpyVS9NNHpjaitTRFVqeUNOaDBnYVlUWENFT0NpeWFXCkl6cGxWMU9IRzNXdmVWenFTVGZHa2p4UWpBc21mZmZVVzY4eEVyVlVYck5SWVlWUStBMmlMbUwzQ29jcmc4QUwvNTRSbnRPdm1vRngKMk1xaVVseVA4dWdML2FiT05EeTlLd0VqYXNNZmR3YzI1L0p5TEFQMTE4VThPNUk3UXRvUG90bS9rRWpZOEY2SmJnSXlmSSswUElPUwp1dTlnU0NSMFhkRm9WTnI3ZkppM2JwT09PclduUjRzQ0F3RUFBYU5BTUQ0d0hRWURWUjBSQkJZd0ZJSVNVMmhwWW1SbGJXOHRjM0F4CkxteHZZMkZzTUIwR0ExVWREZ1FXQkJSUGNxSGk1VUhNNis3ZEs0VnRwTCtPL082ZldUQU5CZ2txaGtpRzl3MEJBUVVGQUFPQ0FRRUEKVFM1SUp0UlBWaEk2ZndMQUZzS0Q5K09PbjFZRlY2NUVWVFRGaFJQeDRoTFdxQjRPRVBpR05kN2pEdFQzTVhzdmNpeTc3cS9sckV1QQp4bWw4dWloekpqSzQwbndFcThFUnRyWWZhbmhNeDJrT2JzWU4vMW02RGs4eHJkYU9oeHE1UDdrVG9JbnNTK3VEOXhCK1g0cUN4Rm52CmJ1Qm1wSC90UlR5amROcU5vVEVRa1ZBMVBmUHdHMG1wTEhXUDlPMVJqTjFsV3Y4ZUVQb0JBdzQ4ZHFvVnlCQUxoN2pJektvN2RWUW0KSitNVlhnMnRvR0l5NnhjekJOYk5ZVU5BTnc1b2M5MlY3VE1LaE00cE4zSUR1aFk2VTNkMmlYZGNsYkVRLzZiTHhlaXRYUllUWUxIQworTUs0VmFXNUFPN0hXZEhBSEVRV2NDaXpOU0xFekZXMWhBbHcvQT09PC9kczpYNTA5Q2VydGlmaWNhdGU%2BPC9kczpYNTA5RGF0YT48L2RzOktleUluZm8%2BPHhlbmM6Q2lwaGVyRGF0YSB4bWxuczp4ZW5jPSJodHRwOi8vd3d3LnczLm9yZy8yMDAxLzA0L3htbGVuYyMiPjx4ZW5jOkNpcGhlclZhbHVlPlhEbkNOUk1VK3o3bnIyeGltRVZZR2JCMjdXenJlSUVBeFVrRWVmYWlrNHpjWFNqUWd5amdiYktFMkVFN0UzZXUvai81WW15RW9kS2c0M3VUbnlJcjZHSWE4dDlvV1NPTDNmNHhaNlpRSmJMbmZHeEpZM0pyRGVNTXhBRU5vZ1lsSy9RZFZQbDNGdFhsZXlibHE2YXlBd0oxYkhMc3dGRHVmWDJma2NrQjV2MURTclN5S3JtNjhZSTB2WWthcmFvVkRKU2c0RmxIRTl1dXFSdVdXYjN1a2dYNGF3VytHb2VWb0VFZjJLQlhJdnlneXI3VG00d3dhV2NETy9WV3JITkREV2o1M1c0SzVWVW9ibEVKVkptRVNSaUx1L0IvMUxielovZkd1V0FxRU5SRmtDbUZEVm12OWo2eHNwNk5GVCs1MWZDSi9LMUhsbUtmOVVQWC83dzhOQT09PC94ZW5jOkNpcGhlclZhbHVlPjwveGVuYzpDaXBoZXJEYXRhPjwveGVuYzpFbmNyeXB0ZWRLZXk%2BPC9kczpLZXlJbmZvPjx4ZW5jOkNpcGhlckRhdGEgeG1sbnM6eGVuYz0iaHR0cDovL3d3dy53My5vcmcvMjAwMS8wNC94bWxlbmMjIj48eGVuYzpDaXBoZXJWYWx1ZT5OV3MxampNRG5yYnFRQTl0VnJKbnN6dUt4d0Rva25PeEVmQmNpZEZSc0lFR0Z0eVUyd2cyWmdMVXhYZmhML1NUWEdMYVlKNFhTR1JTQ1pUUzFjbkhFUWdjNzlVWUUzcjB0ZCtjM0ViaU1JWUFXdFJMZWc2TEgxd0ZGY2RqMEhBS0pwNG9OZnpQTUovZ3BkeXZWZ3FhcEZPdDFOT0tNalNOS3EwUlhWMm5DK1BrZWxIOVVqU1lDdTg2TE12dTREcHBMc1JVQWFvRTJJM24rUkNOYUIzRHRJZTVISFZkR0JmNk5reXR6Z05oNFVDZ0ZWbFA2TjN3SjdwbDBEQ0YrTHErVzVPdGNMVDl5UkxhbXJsY241eVlxV2k2V3NxaUVUMHpPbGI3bC81RnlqUDFYZVBGWFJNeWpXblFTcWN1eFRuS2ZISlNLc0NRZG0zb0xWeEt2ajZFS3NmbmFiQlgrVnBydjhlSWN3QXBxTWRhOUlWMmh0eFljOFhGWTZtcnJMUGpoeVJHMHI4cGxoOFpEazZTcTFmNVpGRnRCdXZLZ3F6NS9TUXJmVk1FMjJKQUhXOHphQ0ZzR3NLRXBicDdTZ0E3Yi85NlRnM25mZDh5eVJrb2d5ZW9CYmcvRHRhN0VRRnh6bW9RVXpNV3Q3WkJ1ZDhGNXQxQUJIRDlsVnNkUXd4djA4b2FGMi8vNXE2M1RCOEcwcGZYNXYyU3pYV01wUFE3amtHZzJ1clpYU2loYWQveGJpODBLaFVFcXBvZFd6UlVUckluNUE0b055YU5uelkydzdDSGpjUmppQ0kzM2hQL251Zm5qQzZyK3VaV0V3T3ZkRFJMWU0xMXRoK056a3VGcnJTS1RVeE9MY0tBNWxVVUFEdTdpVFVUWTYweXl1RkZXRlo4TDZuSW93NTFiN1cyWVVESlBRZmZkaWJEczg3TUxma0V4VWZ0QTBsc3ZKV0dvZDh3SkVNaUk4M1pEdjJ4WFhlYWJURFdhK1FRS3A1anNiUS9mcWJ1Y3VOeDI0UlhQVDN4VysweWVQQ3V3dlp5SnJTOFlwYmVMV2FBQTMxbXNYSlFTTXNacEpXSFpjVS9EWnhsVHYyQzVpNVhJck5oQUNDMnd1elAzTTB3dWtXVkV6MjAyVkloN3NDSTh1anNNNlJPQU1oNjhSRndTc2FJaEMzbVpZbGJzV1lqTzZyTXJhSzljK1BXdEhoZGZPbDZqTjJNZkZsT3NKdDc5RWsxNHNsbmpPNWIwazVCcktOTkxPYlQ1aTBiSng3UXdlNE0rbDJlVlpGOURkbEI0R0FGVjdMeVVGUWpHYTkxd2JBdS9jTlZWRldYMFM3L3FkcjNXQXVnQjFsL1hRN0lsRTBMbjRpSnJJK2hlWjZ6d0VBUVNibHFyYXRaSXY4U1UwT0J1b2tYWks2UXU3MnB1TUFpdDNZZklHbk8vaUJrR3VCelhiTzR2S3NpZjNYczE2aS9ad0d2eGFDOExkYXNHQ25veVdmRE1IZG1ucWlpL1JjNWhpZUZxazJLNk9zUHpFQjVUeXBWbVZFWTBDMlBSY1hKOTlMelZ0U3NQS25tNnpzanR2MnRaUm9iV2dKekZhK1pDZlBzbEVDNndWTUJPL0hPbHMxZGY1bTBVcXVGUGZPK0dyd1E1NEE1VzJ3S2pwMTdnT2lhRzNKWXlHZG5NaUxvTEV3dStaV0NDMnZLeExEOUxPRDVYUk0rRERmU1FCazZVQjJmaWFxTjA0eC8wcTRRT3RMN2dCeHo5MnY5REp1UHFYcjhuWnFXOVFXbnNtODFpcHVWdEJVeG9paWNtZlMzOVovRTd2bzFYenlNdmN4TjNndFNTSHljTlNPYm11SklLcEVHSDM2ckQxbmppbHZ3RWhJT1hKQ2QyenRNZDVOZ0wybEl0SjNtUmpnVzg5WnNkR0YxcVdRZ2g2ZmlVOVFwL2IzNW10c25TZVpiS1ZTc21IY2k0VmlCSXpXLytwa2lucWk2Y3NCdCtxeFIvRGNvMlkzdVdpaFR0UC9zaDRLNGthYlNQd2NySGZ2YVJlZWNUTUxLMVFIem5SdjhNRzE4M0h4RW9tM2FFd2UvdjlqQitIOG1IZDVucDNKM0tKS0wzQ20xeHZETERhUFVRYkRHb2pUNE1kNUtVMTBOSmV2c3hFMFRiSVdBUWJLeDUyL21jVlNicEpxT210NDlNeElxTXRESVJST3RUcEcvTldaQTZ6Q0VRbTRTQ055WW9oVFdUTWVxU0VuMU1odlQ5dGw3S3cxd2twb25yRE0rbzNGNmsrTXFGTGMwcHNUR2d1T1Zrd0pXdkxudG1XUllMTXIvdEdKTWVsV25Mam8wQmlqVlZYQjlPWkhzbTVScmdJWVdIYm83SkFMbTBHMGxHVlRmbThtaXlsbExRK3RSbGFpTVI1c2ladktVdk0rNlkzK3VMMWtSOWxnUHQ5U1ZCWURzVTZBMXRyTzNIck5uZ1g5UWRVSUExQUtraDBiUVIzVHhlZ3phK2pwL3JNSm1ob25IR21STlFYZzVmZFRiem5qQ3lCMWdDZ0N6dkE2RHJFQ1JwQVdMeks5OFdpZ25Jc3JKakIwMTJzaGV6UDc2ak1meExGcFh5b1VXYkNhVFVoYjNJMkUydXRyU1dDUnZOeGJPTGlYdUtUUkQ2UEkzdlNjVURHQU9VL2QxTDdYQ1VnOXJEM0VqSnFPYTQ4aEFNMFRYdjB5MWlkRXFZWnJCK1hmSVl5c1NqTmVHOWh1WTRHenRuQW9oaWVtZ0hsdlJGdkVJckJpT3paVHNnQjllaElrOGFpK3JXUDk1OEM0dEVwRnhhNS8zVDNHOC9INHd4VjByaGNjbHg4VS9JY0FOVVJxQlNrSHZMUmg1dlBjcFJDMjNoTngvRXM1VVlXMXZlR2pMYlpRalMvSXQ4TDVsYjhsL2pZMGxlN2dIVEZ5RnBBcWx3TDlmY1QwZUFaYm1MbW1ZZElEbnJxdGVYWGQwL1dXcWVaV0cwQ3g0akorN0hCVHJodUNzcDJ3QlRzb3FTbGdreUhGNU1SNEVlNitiY2pxb0tXSUpzdXEyaEkrbWQvUDE3RlJ2YTQwdXMxNFY2Z0RrVHZEcVZ3OTk1MmZOTE13TmR4bzlRa0NWTmwxRy9FNGVETXl3MUMzMXFiNnJtUlRhclN3Vmx1RlV5RnZpVUE3WkxJOWxuZjNTRUNPV0NRYy9tdkZCVGNRUXExYnN3S2tPZTAvM3lPSlB4VENNU2ZIeDc5MlJSbHNXSkxDdVNkRjBDWEhKSzltL0F3L2U5ZmRmUVduVyt4RUFWdlRBTEFKbjd5QWkwRUtQeU56anMybndReEZhUWtydWhUeGxrMm9TT3p4ODhET2JDakNNWDJSbEpEUzY0M000U1ZpbUcyUjFlSlNPbS9YUkhoeU5MY2RWeTg1b0VJOG1FSG0yN2paVDRUVlhCeEpQcnpKNUVkbTFQWHZtZ01RZXFzSWVFSWZ4TFpvNG5YL2JwZmtnRGF3SkxkSUdHczh4TE9rclBFbDQ5NGJtc2FsdFpTRHh3eCs1MmtjSm9MRHRnNk5YdnVEWHc2eDNhTm1qK0VTK0toQzZ6Wmc3b3I5YVZmWEUwUjUrY3FsSjIvd2NDWmZBcWlVUkF0QUdCWDBOYnA4WUVpRVpwVzJYNXFmQ1RpbUVobjVVdUhTeHY1cVNrQXdYdlNBVGljbFRTY0kzWTJQOURURVozblRNR0cyRXJVT2hjU0FobC8yUGFRemlDeGNTYSsvWUhaUzZCRk9KRi9tWTZ5WHVMd3NzRVJSZ0o4S09wMUVSU2FZVWVXRDJtcERZUy9KRVJobEFVUmFkOFVjYVVLSEJZSTg5eXIzdk56N2FqbUt3U3dRanlnRm1nZGJrSFFwQ25EcTE2TzMwdDY5eXhwcC94OEZFNUo0TU9ab1hwVXJPZ1RkSFlFa3IwN3dPZzR2U1BlZTZSUWRhOUo5eTNvQUNvZFlrQ0V3VGlpU1d6RlRwRGpjM2dEZU1WOUdkUUJOYUVsa25obFNBN3JRRFR2RDhjSmQ1WDVnK2kyTUdnV3A2UmcwdDR6OEg3dCtkYXNsZkd0Sll5dzc1a3hadHpPT3JCV2ZmU3kxSVVLMDB3VURzUUY1TytEMzVydXcwa245ZnUzbEZCU1RqNGVKQ2ZuWHVvTUY0VG41YUE5WWtkYWZUTHlCRVB0WVN4dFNzeVRKQWJLZXNaeXl2bE5YOGFEbzB0Z1NrTUZLbDNhUy9Db09vRG9BNE11ZG9iNGFMOW83MEdlNStnb1JwMkJsa2NzZ3A1Z2ZlSlZlQ2ttdWNYYjVTWGs3ZVRSU1BPU3BBQjROTXZJL0xLRVJ4Z2lhMHkzR2hWYWJLMHEweVBUQWFya0xEM0d5SHB5bTFjd3NmUTMzQ29PWmZERU5zc1VoK1pKWlo3TDVmbHkydldBcGVPZ3B2UU9pc0g2VGRXbXFOSThlNE1qcUJuL1V4anM2UU4xeXlrbEV5WFk3aDRPNTNMUHlEUDI0am5XVFQ1NVRlenE2U1BpVFJRNmlaYVhsTnFFMWQ5WDIzV2tUUFQyVklUMElNa3BJUFhuTkllem4ycVRIMEJEWHJIcUtNUG81RC9qZW0vL2ltR0VQU1JabUhtTGJuM2ZsazF3VU9FZGZiL0JkT3dFVkRIRHlnU3ZHYS9DM0JkNVVKekVPaFlzSFN0YXFiWUFYSlVmb1p1ck5RQ09od3hCVVJySzdadmVMc1lsc01pK1hvZm11c2NFQ2oyVzUwRE1peFF5Vi9JZ2Q2dEpWb1p1Zk1Rb01pb2xEMSs4VmNLOTNVS0djUmVUTnhZV05vZjVEZ0NJNUVTdEVoMnlOQVhFMFNMNTlGT1V4am13bzNMbEJIOUN5VUc2QXp5STErc1lxQk5MdVBteEJTQUl6UFYzT2NzZmpoWEpJeXIxMnQ1Yi85THVpT0hRU3hWUmQyWVAzekM1Nmg3Q00rSUZNam1aRUdIakIvek1ESTJCc3hvMmhQeVh4N2Y1eVpwS0poVFZ5dXpiSjZIMzlHU3M2ajF6RytrVWgvVmd2bU1yWlhseHgvUVlTMU5QSVJ6dElQRmU0dHNGY0IyV1JNZXhvZEc3VVE0NjBZQk5hWGFLU3cwMHdmaGdhVHVxWVhMRy81Y3RjUy9DMkg5VWdra2RtOG1yNzRpVjBYdklaQmxSVXo2cVNLZjFtZExQcGppbDBJNUFRR2UwUmhHMTZ6RElsNEdsem41cVh2dS9BdVZvZzJwT0hLaTBqcVJqa0p4VkdPQjVNK1lpeXBXSWpzTkxRNDYxR2hNeVN3aDMzVlI4aWhueWVmM1oycjlXbVgrSkJkTGNZOWhiRFZKNFAxT2hFb1Vxd0pnV25saUoxL0NIelYwSG5CaGcrc1lZZnVnT0ZSaWY5ZDZCVUZ5cmIwVnF0OTlWQTZyLy9GN3AzMG0zVzBnMjlNQ2VoZG14SzhHVFZ6d3JpTGpnaDArUXpHeHJoMk5hRG02NWs3Y1BKMVREWmlZa3I2OEh4MnBVTmRMRmtpZHJsTDd3QWZrV3V2Tmd5ZlRlclFsSzdxVHUxNzJZdzg5dThxZmkrenoxdktrakx6d2x4ZHE0K0oxOVpHMnJ3ZlBXaFRJbG1hL1VQTndFNkhycVY2ajhGYWtVdGZNSVJWWHRtK1JyNFVJOEdackpJbUVueTJlV05DM0lQZUQyRVQwN0kwRU92RDFtVkdQVHRFK1pqZ1ZLaFFEYVdINkR3LzRtcVJ1b2tLU252YjJ4a28vd0dRV0RUTHdjSWM5c3pXRHRIbEJRdjZaaU5KTkxGamFWWksvaWFaNVRmWUFLTk9IT25sU25xc1ZOVnk5eEV5anhtYzVVYUhYNHdSeS8wQ29PWlNqODJpU2tWa2NOc0hsVXh5d2ROVEl5NGYzWmVncDk1dmg2TE0vUnd3T1VjYjdSODVBYTFGVXA1WkszQ1NkZi8xdlQrSjZUYUdoOWtnOHkyZzJwZjhXU2NDYXYxMVgxV1pOOFhkb3J0WDZ5ZzhUaFVzaWxvK09DeVlMelNOWm94MHkzQU1DNW56UFBNZGRBUC9sRUd0OHpVS1FvU0JkbmZYTEZQaWk3aDU3QWNqc3JNSm5HTmhoOHQxVU1TOGNDWWNBaVZSU3c5Qk5GdG1aQkFHNjR1ZXl4dytQZWpYN3ppWDZrOXlGVWNFdk8wQ0JkZGRWVVRZdS9NZkZpT2V6K3dpRFdzY3hJNm9OcWJndUR3MDdvTytQcDljTjFaWmNqYmJNd1JsSEdMTUsrZlVzZ2orbWt3Z1MyR2VWTGovV3lUSGo5VG1GbFhMWEtlZmxkWVFKUG1lb0kwQmdVZ3E3cHgzUSsrWXpNU1hrZFNIUmllOTRyU3dlOU9jZU9yM2FTcEQ2Yzl0cGtYZFJyQWoxWVdIbGhDaEkvakJXM3lMbEw0WDlGN3JrUVpsL3BuMERtQmJxYTdta1k4em9oTFdPMDhkTTNMS3FGU2VkdElmYm83emNLWnBIY2tjdVhQSWF4dHlYTVdWanBieUZEQXpYSlo0V2JCR0hCRzJ1ZlREeEU0VjdFaHFMeCtWZlNyMUFzeGhYRW0xQnRwRkRaSFlOUXNFUXBOS2R6M2JybStjZnowYU1raDZGaGF1YklicUFQNWlaQ2crN3dZUHNmUm42bDE2ZTIrZFVSNE1mNWxyZE1UaUljVTNEdGFuRVF2YXdSQXkySCtMNGdLNTROVVh4ZE5KY3NKWkFuOXdzSzlWdzJxS0M4UHhDaGR0dHV2Qm83KzkzVEdGenMxS2FBSFdNTk1kMnVKVVlJTkdLUEIyKzVSU0JuVHpDbU55bUFpOGJ3ZWxnTnpSbkNtWVNZaVJHbmlQc1dmUmJlTTNSWURaVDkzbEo5c25oamNuYnFCMDYrUlloaVBHeFdSVVJIZE1QaHI5TTNOejFpdmRFckd5VmNmdzhNT1FvbFZLTmIxdUJQME42SEd2NVVyQzBxYmpRczJ5OWJDaWw0dEZNbzlGY0tqNWNYUGpMU041RDl4OG14MkNORmNPbm1sYjI5WFprS0NtN3d2STFVREZGTlFlYnpDWTlSMWtPUG9PWlV1N1Y2RDVWcWlwcmZiOVVlK3lLenkyOExTMEQyUjlmSVNpZnhNRExBUGZMODZzYjRlR1R4U2J3Wk9MTWI0QzlUcjNiMVdUenA0WnFwWExmSVpoSEtvZGxoZkgyTTFaQ1FGamRxTS9XWGprL092Q3ZHczNocDdBckVtQTBJOGtnMDFVUmpMdXJVMkc4T1hyWkxhdFNUaEJOZm5JTDFYenI2U3M1dzJ1cEpnOCtwM0NSb2YxVHRma25BcWp5dXYwcVNDdUVBVTF0Y290OTVuQVBacndMdUZTS2QwK1FTSDJMQVEzNlZZMEpLbVRqMXFSQndNUzJ6UFNGVzJsYXU2cG9wUUdxQTR1K01USnVpOXY4M3RWMG9xRDV1NkVSTXZ4WnFGcGgvWVZZUVFPZEJiSHJwZWFyTlVrVG5DM0s1TmNzSTArVWtJdGN3L1BYZ2FhMStIdXhJRmNzOStxeitTMDBtVEs2c3pnUWZ5Q3ZsUExKVXhOT3VBUVFpTzBRVzBhQjBtMEIvQWNyS1RjNlJaRE42cGM5WVIybUcxOW1yR09veUxmVjFaL0lVd1VHUFB1ZkZGZUsxdzBxUzNnMHZxdmQ0VWhFTVgxMTgrMzVka2w2N3JWb2NkRUJnQlZVWVRTNkpabHlqRVNYSVJaQVBCQnlBRkF1ZzRRdHRqT0FKcFp1TmtFd1dFV2V4TC9SWkJ1MHcvQjIyYVV4d3p6SVZUOGFTOVpCV3FBS3NicXRuYno1YXU1MzNXS2VaSm0wdHJKQTUzZE1sK1lFemNPMjIvenlWV1c2MURiTnRCbUpJWWhCUkRDOUx3KzdCWjJBemc9PC94ZW5jOkNpcGhlclZhbHVlPjwveGVuYzpDaXBoZXJEYXRhPjwveGVuYzpFbmNyeXB0ZWREYXRhPjwvc2FtbDI6RW5jcnlwdGVkQXNzZXJ0aW9uPjwvc2FtbDJwOlJlc3BvbnNlPg%3D%3D
```

Once the POST request is received, and the SAML Response is validated, we can access the protected resource we initially requested.

```text
GET /secure/ HTTP/1.1
Host: shibdemo-sp1.test.edu
User-Agent: Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:65.0) Gecko/20100101 Firefox/65.0
Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8
Accept-Language: en-US,en;q=0.5
Accept-Encoding: gzip, deflate
Referer: https://shibdemo-idp.test.edu/idp/profile/SAML2/Redirect/SSO
Connection: close
Cookie: _shibsession_64656661756c7468747470733a2f2f7368696264656d6f2d7370312e746573742e6564752f73686962626f6c657468=_ac05716a62d3ee9450c863b093f32bbb
Upgrade-Insecure-Requests: 1
```

```markup
HTTP/1.1 200 OK
Date: Tue, 12 Mar 2019 20:55:04 GMT
Server: Apache/2.2.3 (CentOS)
X-Powered-By: PHP/5.1.6
Content-Length: 1047
Connection: close
Content-Type: text/html; charset=UTF-8


<?xml version="1.0" encoding="iso-8859-1"?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>IDM Integration</title>
-------------8<-------------
```

## XML Signatures

We’re almost done covering all the basics we need to cover in order to move on to the actual testing! The last item we need to cover is XML Signatures. Interestingly, XML Signatures can be used to **sign either a whole XML tree or specific elements** within the tree. We already saw earlier that two separate XML Signatures were used in our example SAML Response. Each signature was responsible for a different part of the Response. In this section, we’ll look at the different ways an XML Signature can be incorporated into an XML document. Something to note is that while our examples use the Response element as the resource to be signed, XML Signatures can be applied to any Object, including Assertion elements.

### ENVELOPED SIGNATURE

A basic XML Signature is comprised of the following elements.

```markup
<Signature>
  <SignedInfo>
    <CanonicalizationMethod />
    <SignatureMethod />
    <Reference>
       <Transforms />
       <DigestMethod />
       <DigestValue />
    </Reference>
    <Reference /> 
  </SignedInfo>
  <SignatureValue />
  <KeyInfo />
  <Object />
</Signature>
```

Of particular note for us is that each resource to be signed has its own Reference element. The Reference element’s URI attribute denotes which resource is signed by that particular Signature. By examining our example from earlier, we can see this in practice.

```markup
<samlp:Response ... ID="_2af3ff4a06aa82058f0eaa8ae7866541" ... >
    ...
    <ds:Signature>
        <ds:SignedInfo>
            ...
            <ds:Reference URI="#_2af3ff4a06aa82058f0eaa8ae7866541">
                ...
            </ds:Reference>
        </ds:SignedInfo>
    </ds:Signature>
    ...
</samlp:Response>
```

What we saw in our example earlier is known as an **enveloped signature**. An enveloped signature is a signature that is a descendant of the resource it’s signing. We can see that spelled out for us in the ds:Transform element of our example.

```markup
<ds:Reference URI="#_2af3ff4a06aa82058f0eaa8ae7866541">
    <ds:Transforms>
        <ds:Transform Algorithm="http://www.w3.org/2000/09/xmldsig#enveloped-signature"/>
        ...
    </ds:Transforms>
    ...
</ds:Reference>
```

### ENVELOPING SIGNATURE

In addition to enveloped signatures, there are **enveloping signatures** where the signature wraps the resource, instead of the other way around.

```markup
<ds:Signature>
    <ds:SignedInfo>
        ...
        <ds:Reference URI="#_2af3ff4a06aa82058f0eaa8ae7866541">
            ...
        </ds:Reference>
    </ds:SignedInfo>
    <samlp:Response ... ID="_2af3ff4a06aa82058f0eaa8ae7866541" ... >
        ...
    </samlp:Response>
</ds:Signature>
```

### DETACHED SIGNATURE

Finally, there are **detached signatures**. A detached signature is neither wrapping nor is it wrapped by the resource to be signed. Instead, it is wholly separate from the signed resource.

```markup
<samlp:Response ... ID="_2af3ff4a06aa82058f0eaa8ae7866541" ... >
    ...
</samlp:Response>
<ds:Signature>
    <ds:SignedInfo>
        ...
        <ds:Reference URI="#_2af3ff4a06aa82058f0eaa8ae7866541">
            ...
        </ds:Reference>
    </ds:SignedInfo>
</ds:Signature>
```

## References

Most of the content was copied from [https://epi052.gitlab.io/notes-to-self/blog/2019-03-07-how-to-test-saml-a-methodology/](https://epi052.gitlab.io/notes-to-self/blog/2019-03-07-how-to-test-saml-a-methodology/)

