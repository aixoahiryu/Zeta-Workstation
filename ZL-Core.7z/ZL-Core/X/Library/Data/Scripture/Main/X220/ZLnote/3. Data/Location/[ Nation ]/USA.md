Alliance:
- AIPAC

Timeline:
- 2000 - Bush elected, 2nd truly horrendous president
- 2001 - WTC center destroyed, governments take advantage of this to massively increase surveillance and war monger for Israel.
- 2002 - More of 9/11 SARS dry run starts
- 2003 - Iraq
- 2004 - Faceberg
- 2005 - Katrina, Youtube
- 2006 - ??
- 2007 - Iphone, Tumblr, SJW internet gaining mainstream traction
- 2008 - Financial crisis, Obama
- 2009 - YouTube grows, Jackson dies
- 2010 - ??
- 2011 - Arab spring with social media spreading it and in general growing, Japan, Occupy etc
- 2012 - Arab Spring goes bad, SJW and tumblr normalizing, Trayvon Martin blacks chimping out
- 2013 - Degeneracy grow's
- 2014 - SJW peak, Gamergate, nudes leaked
- 2015 - ISIS, terrorism and massmurder increasing, massive increase in migration, Trump v Hillary, escalation in polarization.
- 2016 - Trump gets in, Polarization and autistic political confrontation normalized.
- 2017 - Massive censorship campaign beings in earnest, mass murder and terrorism normalized, Charlottesville, porn truly normalized
- 2018 - Memes die
- 2019 - Christchurch, 'far right' terrorisms spike, media bias towards happenings e.g. Chch vs SriLanka getting insane at this point.
- 2020 - Corona shutdowns, biggest black chimp out since the 60s, election stolen
- 2021 - Capitol hill, censorship and crackdowns step up several gears, Media goes somehow even more bezerk, unironically blaming white supremacy for a black guy killing an asian etc...
