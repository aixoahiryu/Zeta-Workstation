Reward:
Punishment:
Dogma:
Leader:
Medium:
Worshipper:

>14 Brothers and sisters, you became like the members of God’s churches in Judea. They are believers in Christ Jesus, just as you are. Your own people made you suffer. You went through the same things the church members in Judea suffered from the Jews.

>15 The Jews who killed the Lord Jesus and the prophets also forced us to leave. They do not please God. They are enemies of everyone.

>16 They try to keep us from speaking to the Gentiles. These Jews don’t want the Gentiles to be saved. In this way, these Jews always increase their sins to the limit. God’s anger has come on them at last.