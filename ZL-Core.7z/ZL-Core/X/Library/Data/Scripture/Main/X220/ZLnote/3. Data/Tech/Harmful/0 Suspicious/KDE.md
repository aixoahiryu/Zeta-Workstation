>When disabled (from System Settings -> User Feedback) it seems that (limited?) telemetry data is still collected in files located at "~/.config/kde.org/" with names of the form "UserFeedback.org.kde.'module name'.conf.
>For example "ApplicationStartCount", "ApplicationTime", and the rather intriguingly named "LastEncouragement" date/time stamp

https://forums.opensuse.org/showthread.php/539352-KDE-Plasma-5-18-Going-down-the-telemetry-road

The "still collected" telemetry data is actually used for stuff such as when an application was last used and stuff. Mainly for the klauncher or krunner to show recent apps and all that jazz. Just whitelist it in hosts file if you are still paranoid, I don't exactly like it either, but they seemed very open about it and it looks mostly harmless. To clarify further, if you disable it, nothing gets sent to KDE servers, setup wireshark if you don't believe me.
