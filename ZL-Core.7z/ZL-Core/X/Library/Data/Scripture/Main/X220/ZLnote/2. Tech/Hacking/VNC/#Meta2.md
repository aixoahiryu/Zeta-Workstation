# 5800,5801,5900,5901 - Pentesting VNC

## Basic Information

In computing, **Virtual Network Computing** \(**VNC**\) is a graphical desktop-sharing system that uses the Remote Frame Buffer protocol \(RFB\) to remotely control another computer. It transmits the keyboard and mouse events from one computer to another, relaying the graphical-screen updates back in the other direction, over a network.   
From [wikipedia](https://en.wikipedia.org/wiki/Virtual_Network_Computing).

VNC usually uses ports **5800 or 5801 or 5900 or 5901.**

```text
PORT    STATE SERVICE
5900/tcp open  vnc
```

## Enumeration

```bash
nmap -sV --script vnc-info,realvnc-auth-bypass,vnc-title -p <PORT> <IP>
msf> use auxiliary/scanner/vnc/vnc_none_auth
```

### \*\*\*\*[**Brute force**](../brute-force.md#vnc)

## Connect to vnc using Kali

```bash
vncviewer [-passwd passwd.txt] <IP>::5901
```

## Decrypting VNC password

Default **password is stored** in: ~/.vnc/passwd

If you have the VNC password and it looks encrypted \(a few bytes, like if it could be and encrypted password\). It is probably ciphered with 3des. You can get the clear text password using [https://github.com/jeroennijhof/vncpwd](https://github.com/jeroennijhof/vncpwd)

```bash
make
vncpwd <vnc password file>
```

You can do this because the password used inside 3des to encrypt the plain-text VNC passwords was reversed years ago.  
For **Windows** you can also use this tool: [https://www.raymond.cc/blog/download/did/232/](https://www.raymond.cc/blog/download/did/232/)  
I save the tool here also for ease of access:

{% file src="../.gitbook/assets/vncpwd.zip" %}

## Shodan

* `port:5900 RFB`

