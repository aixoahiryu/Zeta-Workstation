![1616778776433.jpg](https://i.imgur.com/Z2CRNbd.jpg)

try to remember, though, that many of these people do not really give a shit. for example, if someone REALLY cared about george floyds death, they would watch the bodycam footage. It's an hour and a half, but it would show them how uncooperative he was being, and how he was foaming at the mouth.
it's a shame that social media (and media in general) have impacted us this much. full tedpill, i guess.