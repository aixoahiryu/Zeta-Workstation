# 2FA/OTP Bypass

## **Bypassing two-factor authentication**

### **Direct bypass**

Fuck the 2FA, just **try to access the next endpoint directly** \(you need to know the path of the next endpoint\). If this doesn't work, try to change the **Referrer header** as if you came from the 2FA page.

### **Reusing token**

Maybe you can reuse an already used token inside the account to authenticate.

### Sharing unused tokens

Check if you can get for your account a token and try to use it to bypass the 2FA in a different account.

### Leaked Token

Is the token leaked on a response from the web application?

### Session permission

Using the same session start the flow using your account and the victims account. When reaching the 2FA point with both account, complete the 2FA with your account but do not access the next part. Instead of that, try to access to the next step with the victims account floe. If the back-end only set a boolean inside your sessions saying that you have successfully passed the 2FA you will be able to bypass the 2FA of the victim.

### **Password reset function**

In almost all web applications the **password reset function automatically logs the user into the application** after the reset procedure is completed.  
Check if a **mail** is sent with a **link** to **reset the password** and if you can **reuse** that **link** to reset the password as **many times as you want** \(even if the victim changes his email address\).

### OAuth

If you can compromise the account of the user in a trusted **OAuth** platform\(Google, Facebook...\)

### Brute force

#### Lack of Rate limit

There is any limit in the amount of codes that you can try, so you can just brute force it. Be careful with a possible "silent" rate-limit, always try several codes and then the real one to confirm the vulnerability.

#### Flow rate limit but no rate limit

In this case there is a flow rate limit \(you have to brute force it very slowly: 1 thread and some sleep before 2 tries\) but no rate limit. So with enough time you can be able to find the valid code.

#### Re-send code reset the limit

There is a rate limit but when you "resend the code" the same code is sent and the rate limit is reset. Then, you can brute force the code while you resend it so the rate limit is never reached.

#### Client side rate limit bypass

{% page-ref page="rate-limit-bypass.md" %}

#### Lack of rate limit in user's account

Sometimes you can configure the 2FA for some actions inside your account \(change mail, password...\). However, even in cases where there was a rate limit when you tried to log in, there isn't any rate limit protecting this actions.

#### Lack of rate limit re-sending the code via SMS

You want be able to bypass the 2FA but you will be able to waste money of the company.

#### Infinite OTP regeneration

If you can **generate a new OTP infinite times**, the **OTP is simple enough** \(4 numbers\), and you can try up to 4 or 5 tokens per generated OTP, you can just try the same 4 or 5 tokens every time and generate OTPs until it matches the ones you are using.

### CSRF/Clickjacking

Check if there is a CSRF or a Clickjacking vulnerability to disable the 2FA. 

### Remember me functionality

#### Guessable cookie

If the remember me functionality uses a new cookie with a guessable code, try to guess it.

#### IP address

If the "remember me" functionality is attached to your IP address, you can try to figure out the IP address of the victim and impersonate it using the **X-Forwarded-For** header.

### Older versions

#### Subdomains

If you can find some "testing" subdomains with the login functionality, they could be using old versions that don't support 2FA \(so it is directly bypassed\) or those endpoints could support a vulnerable version of the 2FA.

#### Apis

If you find that the 2FA is using an API located under a /v\*/ directory \(like "/v3/"\), this probably means that there are older API endpoints that could be vulnerable to some kind of 2FA bypass.

### Previous sessions

When the 2FA is enabled, previous sessions created should be ended.This is because when a client has his account compromised he could want to protect it activating the 2FA, but if the previous sessions aren't ended, this won't protect him.

### Improper access control to backup codes

Backup codes are being generated immediately after 2FA is enabled and are available on a single request. After each subsequent call to the request, the codes can be regenerated or remain unchanged \(static codes\). If there are CORS misconfigurations/XSS vulnerabilities and other bugs that allow you to “pull” backup codes from the response’ request of the backup code endpoint, then the attacker could steal the codes and bypass 2FA if the username and password are known.

### Information Disclosure

If in the 2FA page appears some confidential information that you didn't know previously \(like the phone number\) this can be considered an information disclosure vulnerability.

### Referrer Check Bypass

Try to navigate to the page which comes after 2FA or any other authenticated page of the application. If there is no success, change the refer header to the 2FA page URL. This may fool application to pretend as if the request came after satisfying 2FA Condition.



## References

{% embed url="https://medium.com/@iSecMax/two-factor-authentication-security-testing-and-possible-bypasses-f65650412b35" %}

{% embed url="https://azwi.medium.com/2-factor-authentication-bypass-3b2bbd907718" %}

