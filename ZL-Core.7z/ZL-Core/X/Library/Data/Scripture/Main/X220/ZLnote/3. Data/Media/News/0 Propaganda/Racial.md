![](https://i.4cdn.org/pol/1614471937780.jpg)
![](https://i.imgur.com/QZzgumW.jpeg)