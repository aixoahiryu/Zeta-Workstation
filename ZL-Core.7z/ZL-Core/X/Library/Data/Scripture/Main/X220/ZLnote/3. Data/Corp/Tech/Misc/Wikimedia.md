Critical running expenses:
- Hosting 2.4m
- Donation processing 5m
- Operating 10m

You can run wikipedia for a year on less than 20 million dollars
They are taking in 130 million dollars
that's 110 million spent on non-critical horseshit, more than 80% of their spending is on horseshit they don't need

One of the execs is literally double-paying herself with two "jobs"

![wikipedia.png](https://i.imgur.com/hTpRPnz.png)