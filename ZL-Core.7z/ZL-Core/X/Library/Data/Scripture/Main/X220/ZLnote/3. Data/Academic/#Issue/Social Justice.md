Basic observations are now racist. White people have less freedom of speech than the Russians had in the late Soviet Union.

![science...png](https://i.imgur.com/JrZOMEc.png)