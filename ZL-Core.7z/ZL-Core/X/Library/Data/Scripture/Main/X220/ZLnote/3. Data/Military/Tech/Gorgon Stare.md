Type|Data
---|---
Manufacturer|	Sierra Nevada Corporation
Designer|	DARPA
Introduction|	2011
Primary user|	United States Air Force
Role|	~~Reconnaissance aircraft sensor~~ Wide-area Surveillance

A spherical array of nine cameras attached to an aerial drone.
The system is capable of capturing motion imagery of an entire city, which can then be analyzed by people or an artificial intelligence, such as the Mind's Eye project being developed by the Defense Advanced Research Projects Agency