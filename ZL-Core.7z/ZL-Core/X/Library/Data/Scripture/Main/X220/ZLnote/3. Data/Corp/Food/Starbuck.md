Training:
- Closed down for a company-wide racial bias training