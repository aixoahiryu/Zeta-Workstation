# IDOR

**Post taken from** [**https://medium.com/@vickieli/how-to-find-more-idors-ae2db67c9489**](https://medium.com/@vickieli/how-to-find-more-idors-ae2db67c9489)\*\*\*\*

## Unsuspected places to look for IDORs <a id="8d15"></a>

### Don’t ignore encoded and hashed IDs <a id="d6ce"></a>

When faced with an encoded ID, it might be possible to decode the encoded ID using common encoding schemes.

And if the application is using a hashed/ randomized ID, see if the ID is predictable. Sometimes applications use algorithms that produce insufficient entropy, and as such, the IDs can actually be predicted after careful analysis. In this case, try creating a few accounts to analyze how these IDs are created. You might be able to find a pattern that will allow you to predict IDs belonging to other users.

Additionally, it might be possible to leak random or hashed IDs via another API endpoint, on other public pages in the application \(profile page of other users, etc\), or in a URL via referer.

For example, once I found an API endpoint that allows users to retrieve detailed direct messages through a hashed conversation ID. The request kinda looks like this:

```text
GET /api_v1/messages?conversation_id=SOME_RANDOM_ID
```

This seems okay at first glance since the _conversation\_id_ is a long, random, alphanumeric sequence. But I later found that you can actually find a list of conversations for each user just by using their user ID!

```text
GET /api_v1/messages?user_id=ANOTHER_USERS_ID
```

This would return a list of _conversation\_ids_ belonging to that user. And the _user\_id_ is publicly available on each user’s profile page. Therefore, you can read any user’s messages by first obtaining their user\_id on their profile page, then retrieving a list of conversation\_ids belonging to that user, and finally loading the messages via the API endpoint /api\_v1/messages!

### If you can’t guess it, try creating it <a id="b54f"></a>

If the object reference IDs seem unpredictable, see if there is something you can do to manipulate the creation or linking process of these object IDs.

### Offer the application an ID, even if it doesn’t ask for it <a id="9292"></a>

If no IDs are used in the application generated request, try adding it to the request. Try appending _id, user\_id, message\_id_ or other object reference params and see if it makes a difference to the application’s behavior.

For example, if this request displays all your direct messages:

```text
GET /api_v1/messages
```

What about this one? Would it display another user’s messages instead?

```text
GET /api_v1/messages?user_id=ANOTHER_USERS_ID
```

### HPP \(HTTP parameter pollution\) <a id="cb9a"></a>

HPP vulnerabilities \(supplying multiple values for the same parameter\) can also lead to IDOR. Applications might not anticipate the user submitting multiple values for the same parameter and by doing so, you might be able to bypass the access control set forth on the endpoint.

Although this seems to be rare and I’ve never seen it happen before, theoretically, it would look like this. If this request fails:

```text
GET /api_v1/messages?user_id=ANOTHER_USERS_ID
```

Try this:

```text
GET /api_v1/messages?user_id=YOUR_USER_ID&user_id=ANOTHER_USERS_ID
```

Or this:

```text
GET /api_v1/messages?user_id=ANOTHER_USERS_ID&user_id=YOUR_USER_ID
```

Or provide the parameters as a list:

```text
GET /api_v1/messages?user_ids[]=YOUR_USER_ID&user_ids[]=ANOTHER_USERS_ID
```

### Blind IDORs <a id="7639"></a>

Sometimes endpoints susceptible to IDOR don’t respond with the leaked information directly. They might lead the application to leak information elsewhere instead: in export files, emails and maybe even text alerts.

### Change the request method <a id="6597"></a>

If one request method doesn’t work, there are plenty of others that you can try instead: GET, POST, PUT, DELETE, PATCH…

A common trick that works is substituting POST for PUT or vice versa: the same access controls might not have been implemented!

### Change the requested file type <a id="8f78"></a>

Sometimes, switching around the file type of the requested file may lead to the server processing authorization differently. For example, try adding .json to the end of the request URL and see what happens.

## How to increase the impact of IDORs <a id="45b0"></a>

### Critical IDORs first <a id="71f7"></a>

Always look for IDORs in critical functionalities first. Both write and read based IDORs can be of high impact.

In terms of state-changing \(write\) IDORs, password reset, password change, account recovery IDORs often have the highest business impact. \(Say, as compared to a “change email subscription settings” IDOR.\)

As for non-state-changing \(read\) IDORs, look for functionalities that handle the sensitive information in the application. For example, look for functionalities that handle direct messages, sensitive user information, and private content. Consider which functionalities on the application makes use of this information and look for IDORs accordingly.

