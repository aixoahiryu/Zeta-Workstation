https://boards.4channel.org/g/thread/81205064

![file.png](https://i.imgur.com/yORsDmL.png)
![](https://i.imgur.com/nSuL5TI.png)
![](https://i.imgur.com/hlunMbU.png)

>Mozilla's dependence on search deals, in particular the deal with Google, is still very high. Google was the source of 73% of the search engine deal revenue in 2019, a drop by 2% when compared to 2018. Search engine deals make up 88% of Mozilla's revenue, a drop of 3% when compared to 2018.
They are literally owned by google.
![](https://i.imgur.com/Cmek0mn.png)