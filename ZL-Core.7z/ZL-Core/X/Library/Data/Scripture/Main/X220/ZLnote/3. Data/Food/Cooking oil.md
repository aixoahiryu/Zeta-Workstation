>During World War II, the U.S. built a lot of ships, and so needed lots of rapeseed oil, but couldn’t get it from traditional suppliers in Europe and Asia. The Canadian rapeseed industry, which had been relatively small, exploded to fill the gap, and played an important role in the allied naval effort, becoming rich and powerful in the process

>But rapeseed oil demand plummeted when the war was over, and so began an intensive program to breed a rapeseed edible to humans

>In collusion with the American Heart Association, numerous government agencies and departments of nutrition at major universities, the food oil industry had been promoting polyunsaturated oils as a heart-healthy alternative to “artery-clogging” saturated fats.

>But by the late 1970s, the cooking oil industry in North America realized it had a problem: It had become increasingly clear that consumption of industrial, polyunsaturated oils—particularly corn oil and basedbean oil—was strongly associated with numerous inflammatory health problems, including heart disease and cancer.

Drink the canola oil goyim!