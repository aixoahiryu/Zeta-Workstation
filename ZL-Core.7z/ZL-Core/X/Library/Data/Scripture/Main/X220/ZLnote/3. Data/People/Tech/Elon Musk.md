https://www.bloomberg.com/news/features/2019-03-13/when-elon-musk-tried-to-destroy-tesla-whistleblower-martin-tripp

![](https://i.imgur.com/fc2K7nU.jpeg)