Type|Data
---|---
Formed|	February 7, 1958; as ARPA
Preceding agency|	Advanced Research Projects Agency
Headquarters|	Arlington, Virginia, U.S.
Agency executive|Peter Highnam, Acting Director