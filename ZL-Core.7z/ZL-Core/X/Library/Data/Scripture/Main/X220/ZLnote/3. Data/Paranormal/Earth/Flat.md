## Lake Ontario
![IMG_20180924_133005.jpg](https://i.imgur.com/f6SZpX4.jpg)
Rogers Center https://i.4pcdn.org/pol/1527798421423.webm