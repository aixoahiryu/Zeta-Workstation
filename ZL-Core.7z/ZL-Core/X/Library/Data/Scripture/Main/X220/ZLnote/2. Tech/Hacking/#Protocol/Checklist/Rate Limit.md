# Rate Limit Bypass

### Using similar endpoints

If you are attacking the `/api/v3/sign-up` endpoint try to perform bruteforce to `/Sing-up`, `/SignUp`, `/singup`...

Also try appending to the original endpoint bytes like `%00, %0d%0a, %0d, %0a, %09, %0C, %20`

### Blank chars in code/params

Try adding some blank byte like `%00, %0d%0a, %0d, %0a, %09, %0C, %20`  to the code and/or params. For example `code=1234%0a` or if you are requesting a code for an email and you only have 5 tries, use the 5 tries for `example@email.com`, then for `example@email.com%0a`, then for `example@email.com%0a%0a`, and continue...

### Changing IP origin using headers

```bash
X-Originating-IP: 127.0.0.1
X-Forwarded-For: 127.0.0.1
X-Remote-IP: 127.0.0.1
X-Remote-Addr: 127.0.0.1
X-Client-IP: 127.0.0.1
X-Host: 127.0.0.1
X-Forwared-Host: 127.0.0.1


#or use double X-Forwared-For header
X-Forwarded-For:
X-Forwarded-For: 127.0.0.1
```

If they are limiting to 10 tries per IP, every 10 tries change the IP inside the header.

### Change other headers

Try changing the user-agent, the cookies... anything that could be able to identify you.

### Adding extra params to the path

If the limit in in the path `/resetpwd`, try BFing that path, and once the rate limit is reached try `/resetpwd?someparam=1`

