https://www.engadget.com/tinder-match-group-garbo-background-check-data-142745236.html
Tinder, OkCupid to show men's criminal records to their matches in the future
>drug related offenses are exempt to fight discrimination because People of Color (PoC) are disproportionally represented in those