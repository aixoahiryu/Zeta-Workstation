Type|Data
---|---
Founded|	1963
Headquarters|	Sparks, Nevada, U.S.
Key people|	Fatih Ozmen, CEO; Eren Ozmen, President
Website|	sncorp.com