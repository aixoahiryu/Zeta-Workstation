Reward:
Punishment:
Dogma:
Leader:
Medium:
Worshipper:

SJWism is founded in the belief of original sin, and since everyone is racist, everyone is a sinner until they recant.

The trouble is unlike other religions that believe in original sin, there is no absolution. There is nothing that can save you - not even being a minority quad-gendered otherkin. If you don't toe the SJW line at all times, you just have your original sin pointed out.

Tl;dr - It's an extremely oppressive and totalitarian version of Christianity, except with no moral compass, no clear doctrine, and no way to ever truly be saved.