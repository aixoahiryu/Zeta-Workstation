Training:
- "Be less white"

Acquisition:
"Fairlife" milk, produced by the biggest dairy farm in the US "Fair Oaks Farms", owned by Coca-Cola. Beating the shit out of their cows and running secret veal farms.
https://www.indystar.com/videos/news/2019/06/05/undercover-video-shows-animal-abuse-fair-oaks-farms/1357395001/