video compression does not explain the lack of casing sounds. what the fuck are you talking about idiot. the shoes change color this shit is fake. the shooter picks up a random mag that is lieing down in the hallway before he even enters the building and all the bodies are piled up before he even enters the building. this shit is fake as fuck

The people killed in Norway and Christchurch happened to be enemies of Israel by pure coincidence.
Multinational terror training drill ongoing during Christchurch. Another coincidence.

![kikes i hate them aaaaaaaa.png](https://i.imgur.com/hJayuT0.png)
![tarrant with friends.png](https://i.imgur.com/MYtbrqe.png)
![NZ drill coincidence.png](https://i.imgur.com/fXl9xux.png)

https://seegore.com/full-video-christchurch-mosques-shooting/

Thread:
- https://boards.4chan.org/pol/thread/312200473