http://chuckmaultsby.net/id154.html
COMPLETE LIST OF ATTEMPTED JEWISH EXPULSIONS (1,030) (with explanations and
sources):
 
~1,200 B.C. – Egypt – Jews Expelled for having leprosy and causing various seditions/rebellions throughout Egypt, including helping the Hyksos gain and maintain power; Jews venomously deny this basically because it refutes the mythology in their Old Testament; Egyptian historian Apion (1st Century B.C.), who the Jewish Josephus wrote an entire book (‘Against Apion’) attempting to debunk because he said bad things about Jews and their perfectness (Tacitus via Apion via Manetho, ‘Judaism In Action’) (this first entry may in fact need to be omitted due to the fact that it is largely mythistorical and also that it is referring to the Hebrew people who are not exactly the same people as the Jewish people)
 
733 B.C. – Samaria – Jews Expelled by King Tiglath-Pileser III (Samuele Artom, ‘The Books of
Kings and Chronicles’, 1981)
 
722 B.C. ñ Samaria ñ Jews Expelled by Sargon II (Samuele Artom, 1981)
586 OR 597 B.C. – Babylon/Judah ñ Jews Expelled by Nebuchadnezzar II of Babylon for
refusing to pay tribute (Michael Coogan, ‘A Brief Introduction to the Old Testament’, 2009)
 
356 B.C. – Persia – Jews Expulsion/Killing plot by Haman (apocryphal ‘Book of Esther’;
mythistorical)
 
139 B.C. – Rome – Jews Expelled by Gnaeus Cornelius Hispanus for attempting to corrupt
Romans into religious cults, cheating people out of money. (E. Mary Smallwood, ‘The Jews
Under Roman Rule: From Pompey To Diocletian’, p. 128;
http://semiticcontroversies.blogspot.co.uk/2013/03/valerius-maximus-on-expulsion-ofjews.html)
 
115 B.C. – Cyrenaica, Cyprus – Jews Expelled/Killed
(http://www.jewishencyclopedia.com/articles/4825-cyprus)

87-86 B.C. – Cyrene, Greece – Jews Expelled/Killed after Jewish uprising (E. Mary Smallwood,
‘The Jews Under Roman Rule: From Pompey To Diocletian’, p. 141)
 
66-63 B.c – Jerusalem – Jews Expelled after Pompey The Great annexes Judea/takes Jews as
slaves to Rome (E. Mary Smallwood, ‘The Jews Under Roman Rule: From Pompey To
Diocletian’, p. 21)
 
63 B.C. – Samaritan toparchies (E. Mary Smallwood, ‘The Jews Under Roman Rule: From
Pompey To Diocletian’, p. 40)
 
61 B.C. – Ramathaim, Syria – Jews Expelled (E. Mary Smallwood, ‘The Jews Under Roman
Rule: From Pompey To Diocletian’, p. 28)
 
61 B.C. – Ephraim, Syria – Jews Expelled (E. Mary Smallwood, ‘The Jews Under Roman Rule:
From Pompey To Diocletian’, p. 28)
 
61 B.C. – Lydda, Syria – Jews Expelled (E. Mary Smallwood, ‘The Jews Under Roman Rule:
From Pompey To Diocletian’, p. 28)
 
53 B.C. – Palestine – Jews Expelled/sold into slavery by C. Cassius Longinus (E. Mary
Smallwood, ‘The Jews Under Roman Rule: From Pompey to Diocletian’, p. 36)
 
37 B.C. – Palestine – Jews massacred after Romans capture Jerusalem (E. Mary Smallwood,
‘The Jews Under Roman Rule: From Pompey to Diocletian’, p. 113)
 
30 B.C. – Alexandria, Egypt – Jews massacred (50,000+) in a riot started by Physcon
specifically against Jews (E. Mary Smallwood, ‘The Jews Under Roman Rule: From Pompey to
Diocletian’, p. 224-225)
 
12 B.C. – Gaul – Jews massacred after revolt/resistance against introduction of Roman
census/taxes (E. Mary Smallwood, ‘The Jews Under Roman Rule: From Pompey To
Diocletian’, p. 152)
 
5 B.C. – Palestine – Jews massacred/expelled partially by the Jew Archelaus, a Roman
puppet-ruler and successor to Herod The Great (E. Mary Smallwood, ‘The Jews Under
Roman Rule: From Pompey to Diocletian’, p. 106)
 
4 B.C. – Palestine – Jews massacred (2,000 crucified)/exhiled/sold into slavery by Syrian
legate Publius Quinctilius Varus and Syrian procurator Sabinus (who looted the Temple’s
treasury) after failed Jewish revolt against Rome in what Jewish tradition calls the “War of
Varus” (E. Mary Smallwood, ‘The Jews Under Roman Rule: From Pompey to Diocletian’, p.
110-115; Sidney E. Dean, ‘War of Varus: Judea Rises Against Rome in 4 BC’, p. 1; Josephus,
‘Antiguitates Judaicae’, XVII, 273-277)

3 B.C. ñ Egypt ñ Jews Expelled
 
19 A.D. – Rome, Italy – Jews Expelled by Emperor Tiberius for corruption and aggressive
missionary tactics (E. Mary Smallwood, ‘The Jews Under Roman Rule: From Pompey to
Diocletian’, p. 130, 387)
 
30 A.D. – Babylonia – Jews Expelled for revolting against Rome (E. Mary Smallwood, ‘The
Jews Under Roman Rule: From Pompey To Diocletian’, p. 415)
 
30 A.D. – Adiabene – Jews Expelled; Jews backed ruler Artabanus III financially and militarily,
and after his death, the mob genocides Jewry (E. Mary Smallwood, ‘The Jews Under Roman
Rule: From Pompey To Diocletian’, p. 415)
 
30 A.D. – Armenia – Jews Expelled; Jews backed ruler Artabanus III financially and militarily,
and after his death, the mob genocides Jewry (E. Mary Smallwood, ‘The Jews Under Roman
Rule: From Pompey To Diocletian’, p. 415)
 
30 A.D. – Batanaea – Jews Expelled; Jews backed ruler Artabanus III financially and militarily,
and after his death, the mob genocides Jewry (E. Mary Smallwood, ‘The Jews Under Roman
Rule: From Pompey To Diocletian’, p. 415)
 
30 A.D. – Ctesiphon – Jews Expelled; Jews backed ruler Artabanus III financially and militarily,
and after his death, the mob genocides Jewry (E. Mary Smallwood, ‘The Jews Under Roman
Rule: From Pompey To Diocletian’, p. 415)
 
36 A.D. – Nisibis – Jews Expelled; (E. Mary Smallwood, ‘The Jews Under Roman Rule: From
Pompey To Diocletian’, p. 415)
 
36 A.D. – Cilicia, Italy – Jews massacred after revolt/resistance against introduction of Roman
census/taxes (E. Mary Smallwood, ‘The Jews Under Roman Rule: From Pompey To
Diocletian’, p. 152)
 
39 A.D. – Jamnia – Jews massacred/expelled after “Jewish provocation” (E. Mary Smallwood,
‘The Jews Under Roman Rule: From Pompey To Diocletian’, p. 195)
 
39-40 A.D. – Antioch, Syria – Jews Expelled/Killed after a riot that started between circusfactions
and ended with total attack upon the Jewish community (E. Mary Smallwood, ‘The
Jews Under Roman Rule: From Pompey To Diocletian’, p. 176)
 
38-40 A.D. – Alexandria, Egypt – Jews massacred/expelled under Caligula after multiple
popular mob attacks on Jewry; this is the first known ‘ghetto’ in the world (E. Mary
Smallwood, ‘The Jews Under Roman Rule: From Pompey To Diocletian’, p. 195, 237-242,
360, 364)
 
40 A.D. – Nehardea – Jews Expelled; Jews backed ruler Artabanus III financially and militarily,
and after his death, the mob genocides Jewry (E. Mary Smallwood, ‘The Jews Under Roman
Rule: From Pompey To Diocletian’, p. 415, 420)
 
41 A.D. – Rome, Italy – Jews denied right of public assembly by Emperor Claudius (E. Mary
Smallwood, ‘The Jews Under Roman Rule: From Pompey To Diocletian’, p. 210)
 
44 A.D. – Dora (Greco-Syrian city) – Jews Expelled/Jewish revolt after Greeks put up statue of
Emperor Claudius in one of the synagogues (E. Mary Smallwood, ‘The Jews Under Roman
Rule: From Pompey To Diocletian’, p. 196, 247)
 
 
45 A.D. – Judea – Jews massacred by Roman procurator Fadus after a Jew ‘messiah’ named
Theudas tries to repeat Moses’ parting of the Red Sea (E. Mary Smallwood, ‘The Jews Under
Roman Rule: From Pompey To Diocletian’, p. 259-260)
 
49 A.D. – Rome, Italy – Jews Expelled by Emperor Claudius for “always rioting” (E. Mary
Smallwood, ‘The Jews Under Roman Rule: From Pompey To Diocletian’, p. 210)
 
50 A.D. – Jerusalem – Roman soldier “exposes himself”, Jews start riot, Jews begin to stone
Roman troops, 20,000-30,000 Jews killed (E. Mary Smallwood, ‘The Jews Under Roman Rule:
From Pompey To Diocletian’, p. 263-264)
 
51 A.D. – Samaritis, Judea – Jews (Samaritans) start uprising against Rome, Roman
procurator Cumanus kills thousands of Jews and burns down multiple Jew villages, expulsion
order issued, then withdrawn as Jews enlist the Empress Agrippina and Agrippa (Emperor
Claudius’ best friend) to “intrigue” at court in Rome in order to get Claudius to reverse
expulsion for Jew revolt (E. Mary Smallwood, ‘The Jews Under Roman Rule: From Pompey
To Diocletian’, p. 265-267)
 
56-57 A.D. – Jerusalem – Jews Expelled (200) folliwng revolt where Roman procurator Felix
kills 400 Jews who are “Sicari” terrorists and followers of a Jew messiah from Egypt (E. Mary
Smallwood, ‘The Jews Under Roman Rule: From Pompey To Diocletian’, p. 275-276)
 
62 A.D. – Armenia – Jews Expelled after Jewish vassal prince dies and locals rebel and kill
hundreds of Jews (E. Mary Smallwood, ‘The Jews Under Roman Rule: From Pompey To
Diocletian’, p. 417)
 
63 A.D. – Pompeii (Greek island) – Jews Expelled
 
66 A.D. – Alexandria, Egypt – Jews Expelled/massacred (50,000) after Jews try to set fire to
the Greek amphitheatre (E. Mary Smallwood, ‘The Jews Under Roman Rule: From Pompey
To Diocletian’, p. 365-366)
 
66 A.D. – Ceasarea – Jews Expelled/20,000 Jews killed by Roman procurator Felix after Jews
attempt to physically take over the city screaming “Jews take precedence over Greeks” and
“the city is ours” (E. Mary Smallwood, ‘The Jews Under Roman Rule: From Pompey To
Diocletian’, p. 285-286, 295, 357)
 
66 A.D. – Scythopolis, Greece – Jews Expelled/massacred after Jews revolt; local Jews side
with Greeks against Palestinian Jews; local Jews get caught “double-dealing” (E. Mary
Smallwood, ‘The Jews Under Roman Rule: From Pompey To Diocletian’, p. 309)
 
67 A.D. – Ascalon, Syria – Jews Expelled/massacred for revolting against Rome, killing Greeks
(E. Mary Smallwood, ‘The Jews Under Roman Rule: From Pompey To Diocletian’, p. 358)
 
67 A.D. – Damascus, Syria – Jews Expelled/massacred for revolting against Rome, killing
Greeks (E. Mary Smallwood, ‘The Jews Under Roman Rule: From Pompey To Diocletian’, p.
358)
 
67 A.D. – Bethhoron, Syria – Jews Expelled/massacred for revolting against Rome, killing
Greeks (E. Mary Smallwood, ‘The Jews Under Roman Rule: From Pompey To Diocletian’, p.
358)
 
67 A.D. – Antioch, Egypt – Jews Expelled/massacred by Emperor Vespasian for revolting
against Rome, killing Greeks; plotting to set fire to the city (E. Mary Smallwood, ‘The Jews
Under Roman Rule: From Pompey To Diocletian’, p. 358-364)
 
70 A.D. – Jerusalem – Jews Expelled/massacred by Emperor Titus for rising in revolt;
Josephus gives the figure of 1,100,000 deaths and 97,000 prisoners taken to Rome for Titus’
triumph (E. Mary Smallwood, ‘The Jews Under Roman Rule: From Pompey To Diocletian’, p.
293-330)
 
71 A.D. – Antioch, Egypt – Jews Expelled/cancelled by Emperor Titus (no reason) for setting
fire to city (again) (E. Mary Smallwood, ‘The Jews Under Roman Rule: From Pompey To
Diocletian’, p. 363)
 
72 A.D. – Alexandria, Egypt – Jews Expelled/massacred (600) for allying with Sicari from
Palestine in revolt against Alexandrian prefect Tiberius Julius Lupus (E. Mary Smallwood,
‘The Jews Under Roman Rule: From Pompey To Diocletian’, p. 366)
 
73 A.D. – Cyrenaica – Jews Expelled/Killed (3,000) after Sicari from Palestine enlist wealthy
Jews in Cyrene to rebel against Rome (E. Mary Smallwood, ‘The Jews Under Roman Rule:
From Pompey To Diocletian’, p. 369-370)
 
85 A.D. – Jerusalem – Jews Expelled/Killed under Emperor Domitian during Jewish uprising
against Rome (E. Mary Smallwood, ‘The Jews Under Roman Rule: From Pompey To
Diocletian’, p. 353)
 
95-96 A.D. – Rome, Italy – Jews Expelled/cancelled after Jews managed “to deflect his
(Emperor Domitian) attack on to the Church”; Domitian conveniently murdered, too, which
forstalls impending persecution/prosecution upon Jewry (E. Mary Smallwood, ‘The Jews
Under Roman Rule: From Pompey To Diocletian’, p. 383-384)
 
109 A.D. – Aricia, Italy – Jews Expelled (E. Mary Smallwood, ‘The Jews Under Roman Rule:
From Pompey To Diocletian’, p. 216)
 
115 A.D. – Cyrenaica – Jews Expelled by Emperor Trajan after the great Jewish rebellion (War
of Quietus) which began in Cyrenaica; 40,000 to 50,000 Jews killed in the entire Jewish
Revolt of 115-117; 220,000 Gentiles killed in total (E. Mary Smallwood, ‘The Jews Under
Roman Rule: From Pompey To Diocletian’, p. 371, 393)
 
115 A.D. – Palestine – Jews Expelled partially for revolting against Rome under Emperor
Trajan (E. Mary Smallwood, ‘The Jews Under Roman Rule: From Pompey To Diocletian’, p.
393)
 
115 A.D. – Egypt – Jews Expelled after failed revolt against Rome (Eusebius; (E. Mary
Smallwood, ‘The Jews Under Roman Rule: From Pompey To Diocletian’, p. 399)
 
115 A.D. – Alexandria, Egypt – Jews Expelled/Killed under Emperor Trajan for revolting
against Rome; known in Jewish tradition as the “War of Quietus” (E. Mary Smallwood, ‘The
Jews Under Roman Rule: From Pompey To Diocletian’, p. 389-427)
 
115 A.D. – North Africa – Jews Expelled for revolting against Rome under Emperor Trajan (E.
Mary Smallwood, ‘The Jews Under Roman Rule: From Pompey To Diocletian’, p. 389, 393)
 
116 A.D. – Oxyrhynchus, Egypt – Jews Expelled by prefect Apollonios and Roman general Q.
Marcius Turbo after rising in revolt/killing Gentile farmers; even over a century later, this
city still celebrated the anniversary of their victory over the Jews as a holiday (E. Mary
Smallwood, ‘The Jews Under Roman Rule: From Pompey To Diocletian’, p. 402)
 
116 A.D. – Cyprus (Greek island) – Jews Expelled for revolting against Rome under Emperor
Trajan; tens of thousands of Jews massacred; Jews still expelled over a century and a half
later (E. Mary Smallwood, ‘The Jews Under Roman Rule: From Pompey To Diocletian’, p.
389, 393, 404, 412-415)
 
116 A.D. – Mesopotamia – Jews Expelled for revolting against Rome (E. Mary Smallwood,
‘The Jews Under Roman Rule: From Pompey To Diocletian’, p. 393)
 
116 A.D. – Seleuceia – Jews Expelled causing a revolt (Orosius, Eusebius, E. Mary Smallwood,
‘The Jews Under Roman Rule: From Pompey To Diocletian’, p. 418)
 
116 A.D. – Media – Jews Expelled after causing a revolt (Orosius, Eusebius, E. Mary
Smallwood, ‘The Jews Under Roman Rule: From Pompey To Diocletian’, p. 418)
 
132 A.D. – Syria – Jews Expelled by Emperor Hadrian (“The Bar-Kokhba Revolt”, Jewish
Virtual Library)
 
132-135 A.D. – Palestine – Jews Expelled/massacred (hundreds of thousands) under Emperor
Hadrian after Bar Cochba Revolt (E. Mary Smallwood, ‘The Jews Under Roman Rule: From
Pompey To Diocletian’, p. 439-466)
 
139 A.D. – Rome, Italy – Jews Expelled by Emperor Antoninus Pius for corrupting morals and
money fraud (E. Mary Smallwood, ‘The Jews Under Roman Rule: From Pompey To
Diocletian’, p. 205)
 
155-156 A.D. – Judea (re-named ‘Aelia Capitolina’ under Emperor Hadrian) – Jews Expelled
(eventually cancelled) by Emperor Antoninus Pius after failed revolt over the issue of
circumcision (Jews are eventually exempted from the empire-wide ban) (E. Mary
Smallwood, ‘The Jews Under Roman Rule: From Pompey To Diocletian’, p. 467-469)
 
175 A.D. – Syria – Jews Expelled/massacred by Emperor Marcus Aurelius for supporting
revolt of a Roman usurper named Avidius Cassius, who was legate of Syria (E. Mary
Smallwood, ‘The Jews Under Roman Rule: From Pompey To Diocletian’, p. 482-483)
 
194 A.D. – Judea – Jews Expelled/imprisoned by Emperor Septimius Severus for supporting
losing side (Pescennius Niger) in Roman civil war (E. Mary Smallwood, ‘The Jews Under
Roman Rule: From Pompey To Diocletian’, p. 487-490)

250 A.D. – Carthage, North Africa – Jews Expelled (P.E. Grosser/E.G. Halperin, ‘Anti-Semitism:
Causes and Effects’, 1978)

251-252 A.D. – Gaul – Jews self-deport after being given choice of Baptism or Death
by Merovingian kings (Solomon Katz, ‘ The Jews In The Visigothic And Frankish Kingdoms Of
Spain And Gaul’, p. 22)

255 A.D. – Cappadocia – Jews Expelled/12,000 Jews massacred by Persian King Shapur for
conspiring with Rome against Persia (E. Mary Smallwood, ‘The Jews Under Roman Rule:
From Pompey To Diocletian’, p. 509)

325 A.D. ñ Jerusalem ñ Jews Expelled (P.E. Grosser/E.G. Halperin, 1978)

400-410 A.D. – Tella, Byzantine Empire – Jews slaughtered after a Jewish attempt to
betray a city to the Persians is discovered during Roman-Perisan War; Jews actually dug a
tunnel starting in their synagogue under the city walls which the Persians used to breach the
city of Tella, near Edessa (James Parkes, ‘The Conflict Of The Church and The Synagogue’, p.
257-258)

415 A.D. – Alexandria, Egypt – Jews Expelled by Saint Cyril of Alexandria (Socrates
Scholasticus; John of Nikiu)

418 A.D. – Menorca, Spain – Jews Expelled or asked to convert (Scott Bradbury, ‘Severus of
Minorca: Letter on the Conversion of the Jews’, 1996, p. 154)

468 A.D. ñ Babylon/Judea ñ Jews Expelled

470 A.D. ñ Babylon/Judea ñ Jews Expelled (again)

527-565 A.D. – Byzantine Empire – Jews Expelled/massacred by the thousands after
Samaritan Jews revolt and attempt to set up their own state and king; all synagogues and
Jewish houses are burned to the ground by Byzantine Emporer Justinian I (James Parkes,
‘The Conflict of The Church and The Synagogue’, p. 258-259)

567-578 A.D. – Ceasarea, Byzantine Empire – Jews massacre Christians and destroy
churches; Byzantine Emporer Justin II puts down revolt and expels the Jewish leaders of the
uprising (James Parkes, ‘The Conflict of The Church and The Synagogue’, p. 259)

554 A.D. – Clement, France – Jews Expelled (Bruce R. Booker, ‘The Lie: Exposing the Satanic
Plot Behind Anti-Semitism’, Ch. 4)

558 (or 561) A.D. – Uzzes, Gaul – Jews Expelled by Saint Ferreol (Ferreolus) after refusing
Baptism; the choice of Baptism or Expulsion was given only after Jews had plotted with
Saracens to overthrow the King Childebert (Solomon Katz, ‘ The Jews In The Visigothic And
Frankish Kingdoms Of Spain And Gaul’, p. 24)

576 (or 582) A.D. – Clermont, Gaul – Jews Expelled or forced into Baptism by King Chilperic
(Solomon Katz, ‘ The Jews In The Visigothic And Frankish Kingdoms Of Spain And Gaul’, p.
24, 84)

590 A.D. – Antioch, Syria – Jews Expelled by Byzantines for insulting image of Mary (Salo
Baron, ‘Social and Religious History of the Jews, Volume 2: Ancient Times to the Beginning
of the Christian Era: The First Five Centuries’, 1952)

602-610 A.D. – Mesopotamia – Jews partially expelled for plotting a great massacre of
Christians and destruction of churches; the plot was betrayed; Christians fell upon the Jews
instead and killed many (James Parkes, ‘The Conflict of The Church and The Synagogue’, p.
259)

610 A.D. – Cyprus (Greek island) – Jews Expelled

614 A.D. – Palestine – Jews Expelled by Persians/massacred by Romans as Persians invade
and capture Galilee; Jews joined army of invading Persians against Rome; Jews purchase
90,000 Christian prisoners from the Persians for the pleasure of cruelly putting them to
death; Jews were expelled, however, afterwards, because they insisted on setting up their
own independent state under the protection of Persia and the Persians weren’t going to
allow that (James Parkes, ‘The Conflict of The Church and The Synagogue’, p. 260; originally
via Michael the Syrian)

616 A.D. – Visigothic Spain – Jews Expelled/mass converted by King Sisebut at the instigation
of Byzantine Emperor Heraclius; Jews refer to this as the “First Evil”; some Jews self deported
in 613 to Gaul also (Bernard S. Bachrach, ‘Early Medieval Jewish Policy in Western
Europe’, p. 7-8; C. Roth, ‘A History of the Marranos’, p. 7; (Solomon Katz, ‘ The Jews In The
Visigothic And Frankish Kingdoms Of Spain And Gaul’, p. 25))

622 A.D. – Medina – Jews Expelled/Killed; overseen by Mohammed (http://www.jewish
virtuallibrary.org/the-treatment-of-jews-in-arab-islamic-countries)

627 A.D. – Medina – Jews Expelled/Killed (again); overseen by Mohammed
(http://www.jewish virtuallibrary.org/the-treatment-of-jews-in-arab-islamic-countries)

629 A.D. – Jerusalem – Jews Expelled partially by Byzantine Emperor Heraclius I after retaking
of Jerusalem; upon approach, Jews bribed him to guarantee their safety, but upon entering
the city and seeing the number of Christians that the Jews had killed, he withdrew his
promise, executed many of them, and expelled the remaining Jews (James Parkes, ‘The
Conflict of The Church and The Synagogue’, p. 261)

629 A.D. – Austrasia/Francia – Jews Expelled/mass converted by King Dagobert I on orders of
the church; baptism or expulsion was the choice (Bernard S. Bachrach, ‘Early Medieval
Jewish Policy in Western Europe’, p. 60-64; (Solomon Katz, ‘ The Jews In The Visigothic And
Frankish Kingdoms Of Spain And Gaul’, p. 25, 84)

629 A.D. – Lombardy, Italy – Jews Expelled/mass converted by King Dagobert I (C. Roth, ‘A
History of the Marranos’, p. 3)

640 A.D. – Arabia – Jews Expelled

642 A.D. – Visigoth Empire -Jews Expelled for aiding influential Goths who had revolted
(Bernard S. Bachrach, ‘Early Medieval Jewish Policy in Western Europe’, p. 14)

650 A.D. – Rome, Italy – Emperor Domitian murders all alleged “descendents of David”
(Bernard S. Bachrach, ‘Early Medieval Jewish Policy in Western Europe’, p. 63)

653 A.D. ñ Toledo, Spain ñ Jews Expelled by King Reccesuinth for “polluting the soil of Spain”
after Eighth Council of Toledo (Bernard S. Bachrach, ‘Early Medieval Jewish Policy in
Western Europe’, p. 15)

672 A.D. – Spain – Jews Expelled by King Wamba after Jews initiate revolt in Septimania
(Bernard S. Bachrach, ‘Early Medieval Jewish Policy in Western Europe’, p. 18)

673 A.D. – Narbonne, France – Jews Expelled for siding with Jews of Septimania in revolt
(Bernard S. Bachrach, ‘Early Medieval Jewish Policy in Western Europe’, p. 18)

682 A.D. – Visigothic Empire – Jews Expelled after Twelfth Council of Toledo by King/Count
Erwig (Bernard S. Bachrach, ‘Early Medieval Jewish Policy in Western Europe’, p. 19)

692 A.D. – Lombardy, Italy – Jews Expelled/Forced to convert to Christianity by Lombards
(Solomon Katz, ‘ The Jews In The Visigothic And Frankish Kingdoms Of Spain And Gaul’, p.
26)

693 A.D. – Visigothic Empire – Jews Expelled/reduced to slavery after Sixteenth Council of
Toledo by King Egica after plotting to “deliver Spain to the more tolerant Moors” (Solomon
Katz, ‘ The Jews In The Visigothic And Frankish Kingdoms Of Spain And Gaul’, p. 21)

723 A.D. – Byzantine Empire – Jews Expelled/mass converted under Leo The Isaurian (C.
Roth, ‘A History of the Marranos’, p. 3)

820 A.D. – Lyon, France – Jews Expelled/Killed by Saint Agobard for owning/selling Christian
slaves (Bernard S. Bachrach, ‘Early Medieval Jewish Policy in Western Europe’, p. 98-102)

855 A.D. – Italy – Jews Expelled by Holy Roman Emperor Ludwig II
(http://www.jewishencyclopedia.com/articles/12816-rome)

875 OR 845 A.D. – Canton, China – Jews Expelled/Killed

876 A.D. – Sens – Jews Expelled (P.E. Grosser/E.G. Halperin, 1978)

931 A.D. – Bari, Italy – Jews Expelled/Killed (Bruce R. Booker, ‘The Lie: Exposing the Satanic
Plot Behind Anti-Semitism’, Ch. 4)

985 A.D. – Sparta, Greece – Jews Expelled
(http://www.jewishhistory.org.il/history.php?search=expelled&dosearch.x=12&dosearch.y=
6&dosearch=Search)

976 A.D. – Imola, Italy – Jews Expelled after an attack by Ravenna (C. Roth, ‘The History of
the Jews of Italy’, p. 72)

1012 A.D. ñ Mainz, Germany – Jews Expelled by Emperor Henry II (Rebecca Rist, ‘Popes and
Jews, 1095-1291)

1013 A.D. – CÛrdoba, Spain – Jews Expelled

1016 A.D. – Kairouan, Tunisia – Jews Expelled/Forced to convert (George F. Nafziger/Mark W.
Walton, ‘Islam at War: A History’, p. 230)

1026 A.D. – Limoges and other French towns – Jews Expelled by the Bishop of Limoges
(‘Popes and Jews’)

1062 A.D. – Atero, Italy – Jews Expelled after choice of Expulsion/Conversion (C. Roth, ‘The
History of the Jews of Italy’, p. 72)

1066 A.D. – Granada, Spain – Jews Expelled/Killed by Muslims
(http://www.jewishvirtuallibrary.org/the-treatment-of-jews-in-arab-islamic-countries)

1066 A.D. – Mentz, Germany – Jews Expelled/Killed/Forced to Convert (E. Gibbon, ‘The
Decline and Fall of the Roman Empire’, Vol. II, p.1008)

1066 A.D. – Worms, Germany – Jews Expelled/Killed/Forced to Convert (E. Gibbon, ‘The
Decline and Fall of the Roman Empire’, Vol. II, p.1008)

1066 A.D. – Spires, Germany – Jews Expelled/Killed/Forced to Convert (E. Gibbon, ‘The
Decline and Fall of the Roman Empire’, Vol. II, p.1008)

1066 A.D. – Treves, Germany – Jews Expelled/Killed/Forced to Convert (E. Gibbon, ‘The
Decline and Fall of the Roman Empire’, Vol. II, p.1008)

1066 A.D. – Verdon, Germany – Jews Expelled/Killed/Forced to Convert (E. Gibbon, ‘The
Decline and Fall of the Roman Empire’, Vol. II, p.1008)

1066 A.D. – Toledo, Spain – Jews Expelled/Killed by Crusaders (C. Roth, ‘A History of the
Marranos’, p. 13)

1107 A.D. – Morocco – Jews Expelled/Forced to convert (C. Roth, ‘The History of the Jews of
Italy’, p. 82)

1113 A.D. – Russia – Jews Expelled by Prince Vladimir Monomakh (www.rusjournal.org/wpcontent/uploads/2016/02/Monomax_Jews.pdf)

1113 A.D. – Syracuse, Italy – Jews Expelled after crucifying a ram in mockery of Christ (C.
Roth, ‘The History of the Jews of Italy’, p. 83)

1125 A.D. – Ghent, Belgium – Jews Expelled (B. Booker, ‘The Lie’, Ch. 4)

1125 A.D. – Flanders, Belgium – Jews Expelled (B. Booker, ‘The Lie’, Ch. 4)

1130-1135 A.D. – Genoa, Italy – Jews Expelled due to Jewish merchant activity (C. Roth, ‘The
History of the Jews of Italy’, p. 74)

1144 A.D. – Spain – Jews Expelled after Almoravide persecutions (C. Roth, ‘The History of the
Jews of Italy’, p. 80)

1147 A.D. – Toledo, Spain – Jews Expelled by Muslims
(http://www.jewishencyclopedia.com/articles/14435-toledo)

1147 A.D. – Thebes, Byzantium – Jews Expelled by Roger II after his expedition (C. Roth, ‘The
History of the Jews of Italy’, p. 82)

1147 A.D. – Bavaria, Germany – Jews Expelled after Pogroms (James F. Harris, ‘The People
Speak: Anti-Semitism and Emancipation in 19th Century Bavaria’, p. 13)

1156 A.D. – Bari, Italy – Jews Expelled after its total sack by William the Bad of Sicily (C. Roth,
‘The History of the Jews of Italy’, p. 80)

1156 A.D. – Lanciano, the Abruzzo, Italy – Jews Expelled by the leader of a successful revolt
(C. Roth, ‘The History of the Jews of Italy’, p. 81)

1171 A.D. – Bologna, Italy (C. Roth, ‘The History of the Jews of Italy’, p. 126)

1180 A.D. – France – Jews Expelled by King Philip II (Bell and Burnett, ‘ Jews, Judaism, and
The Reformation in Sixteenth Century Germany’, p. 33)

1182 A.D. – Small cities in France – Jews Expelled (Bell and Burnett, ‘ Jews, Judaism, and The
Reformation in Sixteenth Century Germany’, p. 33)

1182 A.D. – Germany – Jew Expelled

1189-1190 A.D. – Burry St. Edmunds, England – Jews Expelled by William the Scaristan for
Ritual Murder (C. Roth, ‘A History of the Marranos’, p. 16)

1205 A.D. – Villages/Towns in Spain – Jews Expelled by Muslims (R. Rist, ‘Popes and Jews’)

1206 A.D. – Halle, Germany – Jews Expelled/Killed (B. Booker, ‘The Lie’, Ch. 4)

1212 A.D. – Toledo, Spain – Jews Expelled/Killed (P.E. Grosser/E.G. Halperin, “Jewish
Persecution”)

1223 A.D. – Normandy, France – Jews Expelled by King Louis VIII (R. Rist, ‘Popes and Jews’)

1225 A.D. – Milan, Italy – Jews Expelled (C. Roth, ‘The History of the Jews of Italy’, p. 77)

1225 A.D. – Cremona, Italy (B. Booker, ‘The Lie’, Ch. 4)

1225 A.D. – Pavia, Italy (B. Booker, ‘The Lie’, Ch. 4)

1225 A.D. – High Wycombe, England – Jews Expelled (R. Mundill, ‘England’s Jewish Solution’)

1231 A.D. – Leicester, England – Jews Expelled by Simon de Montfort (Robin R. Mundill,
‘England’s Jewish Solution: Experiment and Expulsion, 1262-1290, p. 13)

1234 A.D. – Warwick, England – Jews Expelled (R. Mundill, ‘England’s Jewish Solution’)

1236 A.D. – Southhampton, England – Jews Expelled (R. Rist, ‘Popes and Jews, 1095-1291’)

1237 A.D. – Northamptonshire, England – Jews Expelled
(http://www.jewishvirtuallibrary.org/northampton)

1240 A.D. – Brittany, France – Jews Expelled by Duke Jean le Roux (R. Rist, ‘Popes and Jews,
1095-1291’)

1240 A.D. – Austria – Jews Expelled (P.E. Grosser/E.G. Halperin, ‘Anti-Semitism: Causes and
Effects)

1242 A.D. – Berkhamstead, England – Jews Expelled (R. Rist, ‘Popes and Jews, 1095-1291’)

1244 A.D. – Newbury, England – Jews Expelled (R. Mundill, ‘England’s Jewish Solution’)

1244 A.D. – Speenhamland, England – Jews Expelled (R. Mundill, ‘England’s Jewish Solution’)

1247 A.D. – Trani, Italy – Jews Expelled/Forced to Convert (C. Roth, ‘The History of the Jews
of Italy’, p. 101)

1247 A.D. – S. Anna, Italy – Jews Expelled/Forced to Convert (C. Roth, ‘The History of the
Jews of Italy’, p. 101)

1247 A.D. – Naples, Italy – Jews Expelled/Forced to Convert (C. Roth, ‘The History of the Jews
of Italy’, p. 101)

1253 A.D. – Vienne, France – Jews Expelled by the Archbishop (R. Rist, ‘Popes and Jews,
1095-1291’)

1254 A.D. – France – Jews Expelled by Louis IX (R. Rist, ‘Popes and Jews, 1095-1291’)

1261 A.D. – Derby, England – Jews Expelled (R. Mundill, ‘England’s Jewish Solution’)

1261 A.D. – Brabant, Netherlands – Jews Expelled by Duke Henry II in his will
(http://www.jewishvirtuallibrary.org/belgium-virtual-jewish-history-tour)

1263 A.D. – Derby, England – Jews Expelled (R. Rist, ‘Popes and Jews, 1095-1291’)

1266 A.D. – Romsey, England – Jews Expelled (R. Mundill, ‘England’s Jewish Solution’)

1267 A.D. – Wroclaw, Poland – Jews Expelled to segregated quarter

1274 A.D. – Winchelsea, England – Jews Expelled (R. Mundill, ‘England’s Jewish Solution’)

1275 A.D. – Cambridge, England – Jews Expelled by the Queen Mother, Eleanor of Provence
(J. Hillaby, ‘The Palgrave Dictionary of Medieval Anglo-Jewish History’)

1275 A.D. – Gloucester, England – Jews Expelled by the Queen Mother, Eleanor of Provence
(J. Hillaby, ‘The Palgrave Dictionary of Medieval Anglo-Jewish History’)

1275 A.D. – Marlborough, England – Jews Expelled by the Queen Mother, Eleanor of
Provence (J. Hillaby, ‘The Palgrave Dictionary of Medieval Anglo-Jewish History’)

1275 A.D. – Worcester, England – Jews Expelled by the Queen Mother, Eleanor of Provence
(J. Hillaby, ‘The Palgrave Dictionary of Medieval Anglo-Jewish History’)

1275 A.D. – Andover, England – Jews Expelled (R. Mundill, ‘England’s Jewish Solution’)

1276 A.D. – Upper Bavaria, Germany – Jews Expelled
(http://www.jewishvirtuallibrary.org/bavaria-germany)

1279? A.D. – Sicily, Italy – Jews Expelled after Abraham Abulafia declares himself the
“Messiah” (C. Roth, ‘The History of the Jews of Italy’, p. 151)

1278 A.D. – Cremona, Italy – Jews Expelled after Bianca Sforza is petitioned by citizens (C.
Roth, ‘The History of the Jews of Italy’, p. 126)

1278 A.D. – Small Towns in England – Jews Expelled for Coin-Clipping (Zefira Entin Rokeah,
‘Medieval English Jews and Royal Officials: Entries of Jewish Interest in the English
Memoranda Rolls, 1266-1293’)

1279 A.D. – Perugia, Italy – Jews Expelled by the Podesta (C. Roth, ‘The History of the Jews of
Italy’, p. 120)

1283 A.D. – Windsor, England – Jews Expelled (R. Mundill, ‘England’s Jewish Solution’)

1287 A.D. – Bacharach, Germany – Jews Expelled after major pogroms for ritual murder (Bell
and Burnett, ‘Jews, Judaism, and The Reformation In Sixteenth Century Germany’, p. 34)

1287-1288 A.D. – Gascony, England – Jews Expelled by King Edward I (R. Rist, ‘Popes and
Jews, 1095-1291)

1288 A.D. – Naples, Italy – Jews Expelled (http://www.jewishvirtuallibrary.org/timeline-ofjewish-history-in-italy)

1288-1289 A.D. – Bavaria, Germany – Jews Expelled after Pogroms (James F. Harris, ‘The
People Speak: Anti-Semitism and Emancipation in 19th Century Bavaria’, p. 13)

1289 A.D. – Anjou, France – Jews Expelled by King Charles of Anjou (R. Rist, ‘Popes and Jews,
1095-1291’)

1289 A.D. – Maine, France – Jews Expelled by King Charles of Anjou (R. Rist, ‘Popes and Jews,
1095-1291’)

1290 A.D. – England – Jews Expelled by King Edward I (Robin R. Mundill, ‘England’s Jewish
Problem: Experiment and Expulsion, 1262-1290’, p. 1)

1290 A.D. – Naples, Italy – Jews Expelled/Forced Conversion (C. Roth, ‘The History of the
Jews of Italy’, p. 118)

1290-1292 A.D. ñ Apulia, Italy (and other towns) ñ Jews Expelled/Conversion; ritual murder
of Christian child (C. Roth, ‘The History of the Jews of Italy’, p. 100)

1291 A.D. – Niort, France – Jews Expelled (R. Rist, ‘Popes and Jews, 1095-1291’)

1291 A.D. – Paris, France – Jews Expelled to protect them from Christians wanting to kill Jews
for already killing Christians (P.E. Grosser/E.G. Halperin, ‘Anti-Semitism: Causes and Effects’)

1292 A.D. – Italy – Jews Expelled/Forced to Convert (P.E. Grosser/E.G. Halperin, ‘AntiSemitism:
Causes and Effects’)

1293-1294 A.D. – Berne, Switzerland – Jews Expelled for Ritual Murder
(http://www.jewishvirtuallibrary.org/berne)

1294 A.D. – Nevers, France – Jews Expelled (R. Rist, ‘Popes and Jews, 1095-1291)

1298 A.D. – Rindfleisch, Germany – Jews Expelled after rebellion occurs after ritual murder
charges (Bell and Burnett, ‘Jews, Judaism, and The Reformation In Sixteenth Century
Germany’, p. 34)

1306 A.D. – France – Jews Expelled by King Philip IV (William C. Jordan, ‘The French
Monarchy and the Jews: From Philip Augustus to the Last Capetians’, p. 31; Bell and Burnett,
‘ Jews, Judaism, and The Reformation in Sixteenth Century Germany’, p. 33)

1310 A.D. – Provence, France – Jew’s Expulsion requests from ecclesiastics denied by King
Robert due to Jewish bribe (http://www.jewishvirtuallibrary.org/provence

1310 A.D. – Gerace, Italy – Jews Expelled after pogrom (C. Roth, ‘The History of the Jews of
Italy’, p. 271)

1319 A.D. – Breslau, Germany – Jews Expelled (www.jewishvirtuallibrary.org/breslau)

1320 A.D. – Milan, Italy – Jews Expelled by The Podesta (C. Roth, ‘The History of the Jews of
Italy’, p. 127, 142)

1320 A.D. – The Papal States, Italy – Jews Expelled by Queen Sancia but soon readmitted due
to bribe (C. Roth, ‘The History of the Jews of Italy’, p. 142)

1321 A.D. – France – Jews Expelled by King Charles IV (R. Rist, ‘Popes and Jews, 1095-1291)

1321 A.D. – Small Town in France – Jews Expelled by King Phillip V for Ritual Murder of
Christian child (Joshua Johnson, ‘The Evil Bible’)

1322 A.D. – Small Towns in France – Jews Expelled (again) (William C. Jordan, ‘The French
Monarchy and the Jews: From Philip Augustus to the Last Capetians’, p. 32; Bell and Burnett,
‘ Jews, Judaism, and The Reformation in Sixteenth Century Germany’, p. 33)

1325 A.D. – Brindisi, Italy – Jews Expelled/forced into baptism (C. Roth, ‘The History of the
Jews of Italy’, p. 271)

1326 A.D. – Pressburg, Germany – Jews Expelled at city council’s request
(http.//www.jewishhistory.org.il/history/php)

1327 A.D. – Iglasias, Italy – Jews Expelled due to medical/financial malpractice (C. Roth, ‘The
History of the Jews of Italy’, p. 263)

1328 A.D. – Savoy, Germany – Jews Expelled/”exterminated” C. Roth, ‘A History of the
Marranos’, p. 13)

1328 A.D. – Navarre, Spain – Jews Expelled/”exterminated” (C. Roth, ‘A History of the
Marranos’, p. 13)

1329 A.D. – Naples, Italy – Jews Expelled (no reason given) (C. Roth, ‘The History of the Jews
of Italy’, p. 100)

1336 A.D. – Cividale, Italy – Jews Expelled for ritual abuses against Christian objects/religion
(C. Roth, ‘The History of the Jews of Italy’, p. 142)

1336-1338 A.D. – Armleder, Germany – Jews Expelled after a revolt which started after ritual
murder charges (Bell and Burnett, ‘Jews, Judaism, and The Reformation In Sixteenth Century
Germany’, p. 34)

1337 A.D. – Deggendorf, Germany – Jews Expelled after pogroms for ritual murder (Bell and
Burnett, ‘Jews, Judaism, and The Reformation In Sixteenth Century Germany’, p. 34)

1338 A.D. – Pulkau, Germany – Jews Expelled after pogroms for ritual murder (Bell and
Burnett, ‘Jews, Judaism, and The Reformation In Sixteenth Century Germany’, p. 34)

1347 A.D. – Messina, Italy – Jews Expelled/Put to death for Ritual Murder (C. Roth, ‘The
History of the Jews of Italy’, p. 247)

1348 A.D. – Switzerland – Jews Expelled

1348 A.D. – Small Towns in Spain – Jews Expelled (the Black Death) (Irwin W. Sherman, ‘The
Power of Plagues, 2006)

1348 A.D. – Small Towns in France – Jews Expelled (the Black Death) (Irwin W. Sherman, ‘The
Power of Plagues, 2006)

1348 A.D. – Small Towns in Germany – Jews Expelled (the Black Death) (C. Roth, ‘The History
of the Jews of Italy’, p. 118)

1348 A.D. – Small Towns in Austria – Jews Expelled (the Black Death) (Irwin W. Sherman, ‘The
Power of Plagues, 2006)

1348 A.D. – Tuscany, Italy – Jews Expelled (the Black Death) (C. Roth, ‘The History of the Jews
of Italy’, p. 132)

1348 A.D. – Mantua, Italy – Jews Expelled (the Black Death) (C. Roth, ‘The History of the Jews
of Italy’, p. 130)

1348 A.D. – Parma, Italy – Jews Expelled (the Black Death) (C. Roth, ‘The History of the Jews
of Italy’, p. 131)

1349 A.D. – Strasbourg, Germany – Jews Massacred (2,000)/Expelled for a century by
townspeople on Valentine’s Day because the Jews manipulated the price of corn, and that
the Jews were protected from any prosecution of their crime by the city council (Cecil Roth,
‘The Jewish Book of Days’)

1349 A.D. – Hielbronn, Germany – Jews Expelled (P.E. Grosser/E.G. Halperin, ‘Anti-Semitism:
Causes and Effects, 1978)

1349 A.D. – Breslau, Germany – Jews Expelled (www.jewishviturallibrary.org/breslau)

1349 A.D. – Saxony, Germany – Jews Expelled (Bell and Burnett, ‘Jews, Judaism, and The
Reformation In Sixteenth Century Germany’, p. 33)

1349 A.D. – Bavaria, Germany – Jews Expelled after Pogroms (James F. Harris, ‘The People
Speak: Anti-Semitism and Emancipation in 19th Century Bavaria’, p. 13)

1349 A.D. – Mainz, Germany – Jews Expelled/Killed (Barbara W. Tuchman, ‘A Distant Mirror’,
p. 113)

1349 A.D. – Wurzburg, Lower Franconia, Germany – Jews Expelled after Pogroms (James F.
Harris, ‘The People Speak’, p. 13)

1349 A.D. – Hungary – Jews Expelled (P.E. Grosser/E.G. Halperin, ‘Anti-Semitism: Causes and
Effects, 1978)

1349 A.D. – Basel, Switzerland – Jews Expelled (http://www.jewishhistory.org.il/history.php)

1352 A.D. – Bulgaria – Jews Expelled for heretical activity
(http://en.wikipedia.org/wiki/History_of_the_Jews_in_Bulgaria#Bulgarian_Empire)

1360 A.D. – Hungary – Jews Expelled again

1360 A.D. – Bologna, Italy – Jews Expelled by Cardinal Albornoz (C. Roth, ‘The History of the
Jews of Italy’, p. 126)

1360 A.D. – Breslau, Germany – Jews Expelled again (www.jewishvirtuallibrary.org/breslau)

1370 A.D. – Brussels, Belgium- Jews Expelled for Host Desecration

1375 A.D. – Palermo, Italy – Jews Expelled/Forced outside city walls (C. Roth. ‘The History of
the Jews of Italy’, p. 246)

1380 A.D. – Slovakia – Jews Expelled

1386-1388 A.D. – Strasbourg, Germany – Jews Expelled by Wenceslaus
(http://www.jewishhistory.org.il/history.php)

1390-1391 A.D. – The Palatinate, Germany – Jews Expelled (Bell and Burnett, ‘Jews, Judaism,
and The Reformation in Sixteenth Century Germany’, p. 35)

1391 A.D. – Baden, Germany – Jews Expelled (http://www.jewishvirtuallibrary.org/baden)

1391 A.D. – Seville, Spain – Jews Expelled after pogroms killing 4,000; the local authorities
had wanted them expelled for a long time but the Pope and the King had always prevented
it; once King Jaun I of Castile dies, the Queen Mother, Leonora, expels them and destroys
their 23 synagogues (C. Roth, ‘The History of the Jews of Italy’, p. 137, 247; C. Roth, ‘A
History of the Marranos’, p. 14-15))

1391 A.D. – Aragon, Spain – Jews Expelled after pogroms (C. Roth, ‘The History of the Jews of
Italy’, p. 248)

1391 A.D. – Ecija, Spain – Jews Expelled/Exterminated (C. Roth, ‘A History of the Marranos’,
p. 15)

1391 A.D. – Carmona, Spain – Jews Expelled/Exterminated (C. Roth, ‘A History of the
Marranos’, p. 15)

1391 A.D. – Castile, Spain – Jews Expelled/Exterminated (C. Roth, ‘A History of the Marranos’,
p. 15)

1391 A.D. – Aragon, Spain – Jews Expelled/Exterminated (C. Roth, ‘A History of the
Marranos’, p. 15)

1391 A.D. – Valencia, Spain – Jews Expelled/Exterminated (C. Roth, ‘A History of the
Marranos’, p. 15)

1391 A.D. – Barcelona, Spain – Jews Expelled/Exterminated (C. Roth, ‘A History of the
Marranos’, p. 15)

1391 A.D. – Catalonia, Spain – Jews Expelled/Exterminated (C. Roth, ‘A History of the
Marranos’, p. 15)

1391 A.D. – Balearic Islands, Spain – Jews Expelled/Exterminated (C. Roth, ‘A History of the
Marranos’, p. 15)

1391 A.D. – Palma, Spain – Jews Expelled/Exterminated (C. Roth, ‘A History of the Marranos’,
p. 15)

1391 A.D. – Toledo, Spain – Jews pogromed/mass converted (R. Maryks, ‘The Jesuit Order as
a Synagogue of Jews’, p. 2; C. Roth, ‘A History of the Marranos’, p. 15)

1391 A.D. – Palermo, Italy – Jews Expelled for spreading Heresy (C. Roth, ‘The History of the
Jews of Italy’, p. 248)

1392 A.D. – Monte S. Giuliano, Italy – Jews Expelled/Forced Baptism (C. Roth, ‘The History of
the Jews of Italy’, p. 248)

1392 A.D. – Catania, Italy – Jews Expelled for “backsliding” Marannos (C. Roth, ‘The History of
the Jews of Italy, p. 248)

1392 A.D. – Trapani, Italy – Jews Expelled for “backsliding” Marannos (C. Roth, ‘The History of
the Jews of Italy, p. 248)

1392 A.D. – Syracuse, Italy – Jews Expelled for “backsliding” Marannos (C. Roth, ‘The History
of the Jews of Italy, p. 248)

1392 A.D. – Palermo, Italy – Jews Expelled again (C. Roth, ‘The History of the Jews of Italy’, p.
248)

1392 A.D. – Berne, Switzerland – Jews Expelled (http://www.jewishvirtuallibrary.org/berne)

1393 A.D. – Pisa, Italy – Jews Expelled; houses sacked for Usury (C. Roth, ‘The History of the
Jews of Italy’, p. 132)

1394 A.D. – Germany – Jews Expelled (P.E. Grosser/E.G. Halperin, ‘Anti-Semitism: Causes and
Effects, 1978)

1394 A.D. – Venice, Italy – Jews Expelled (http://www.jewishvirtuallibrary.org/venice-italyjewish-history-tour)

1394 A.D. – Mestre, Italy – Jews Expelled due to banking complaints (C. Roth, ‘The History of
the Jews of Italy’, p. 185)

1394 A.D. – France – Jews Expelled by King Charles VI (William C. Jordan, ‘The French
Monarchy and the Jews: From Philip Augustus to the Last Capetians’, p. 180; Bell and
Burnett, ‘ Jews, Judaism, and The Reformation in Sixteenth Century Germany’, p. 33)

1396 A.D. – Fermo, Italy – Jews Expelled when the Ghibellines sacked the town (C. Roth, ‘The
History of Jews of Italy’, p. 142)

1397 A.D. – Basel, Switzerland – Jews Expelled (B. Booker, ‘The Lie: Exposing the Satanic Plot
Behind Anti-Semitism, Ch. 4)

1403 A.D. – Marsala, Italy – Jews Expelled (C. Roth, ‘The History of the Jews of Italy, p. 248)

1411 A.D. – Taranto, Italy – Jews Expelled after pogrom (C. Roth, ‘The History of the Jews of
Italy’, p. 271)

1413 A.D. – Polizzi, Italy – Jews Expelled (C. Roth, ‘The History of the Jews of Italy, p. 248)

1414 A.D. – Goslar, Lower Saxony, Germany – Jews Expelled (Bell and Burnett, ‘ Jews,
Judaism, and The Reformation in Sixteenth Century Germany’, p. 433)

1415 A.D. – Vizini, Italy – Jews Expelled (C. Roth, ‘The History of the Jews of Italy, p. 248)

1416 A.D. – Mineo, Italy – Jews Expelled/Put into prison for “conspiracy against royal
business” (C. Roth, ‘The History of the Jews of Italy, p. 248)

1418-1419 A.D. – Trier, Germany – Jews Expelled (Bell and Burnett, ‘Jews, Judaism, and The
Reformation in Sixteenth Century Germany’, p. 35)

1419 A.D. – Padua, Italy – Jews Expelled for being “social pariahs” and “prostitutes” (C. Roth,
‘The History of the Jews of Italy’, p. 161)

1420 A.D. – Lyons, France – Jews Expelled

1420 A.D. – Vienna, Austria – Jews Expelled (https://en.wikipedia.org/wiki/vienna)

1420 A.D. – Austria – Jews Expelled by Albrecht V (Bell and Burnett, ‘Jews, Judaism, and The
Reformation in Sixteenth Century Germany’, p. 35)

1421 A.D. – Regensberg, Germany – Jews Expelled (Bell and Burnett, ‘Jews, Judaism, and The
Reformation in Sixteenth Century Germany’, p. 36)

1422 A.D. – Wurzgurg, Germany – Jews Expelled (Bell and Burnett, ‘Jews, Judaism, and The
Reformation in Sixteenth Century Germany’, p. 35)

1422 A.D. – Bamberg, Germany – Jews Expelled (Bell and Burnett, ‘Jews, Judaism, and The
Reformation in Sixteenth Century Germany’, p. 35)

1422 A.D. – Brandenburg, Germany – Jews Expelled (Bell and Burnett, ‘Jews, Judaism, and
The Reformation in Sixteenth Century Germany’, p. 35)

1422 A.D. – Ansbach, Germany – Jews Expelled (Bell and Burnett, ‘Jews, Judaism, and The
Reformation in Sixteenth Century Germany’, p. 35)

1422 A.D. – Kulmbach, Germany – Jews Expelled (Bell and Burnett, ‘Jews, Judaism, and The
Reformation in Sixteenth Century Germany’, p. 35)

1422 A.D. ñ Austria ñ Jews Expelled again (P.E. Grosser/E.G. Halperin, ‘Anti-Semitism:
Causes and Effects)

1424 A.D. – Fribourg, Germany – Jews Expelled (P.E. Grosser/E.G. Halperin, ‘Anti-Semitism:
Causes and Effects)

1424 A.D. ñ Zurich, Switzerland – Jews Expelled (P.E. Grosser/E.G. Halperin, ‘Anti-Semitism:
Causes and Effects)

1424 A.D. – Cologne, Germany – Jews Expelled (B. Booker, ‘The Lie: Exposing the Satanic Plot
Behind Anti-Semitism’, Ch. 4)

1426 A.D. – Girgenti, Italy – Jews Expelled/unsuccessful b/c of “Crown intervention” (C. Roth,
‘The History of the Jews of Italy, p. 248)

1426 A.D. – Bohemia – Jews Expelled by Margrave Albrecht V
(http://www.yivoencyclopedia.org/article.aspx)

1426 A.D. – Morovia – Jews Expelled by Margrave Albrecht V
(http://www.yivoencyclopedia.org/article.aspx)

1426 A.D. – Iglau, Bohemia – Jews Expelled (B. Booker, ‘The Lie: Exposing the Satanic Plot
Behind Anti-Semitism, Ch. 4)

1427 A.D. – Berne, Switzerland – Jews Expelled (B. Booker, ‘The Lie: Exposing the Satanic Plot
Behind Anti-Semitism, Ch. 4)

1427 A.D. – Lanciano, Italy – Jews Expelled by Fra Giovanni da Capistrano (C. Roth, ‘The
History of the Jews of Italy’, p. 274)

1428 A.D. – Fribourg, Switzerland – Jews Expelled (B. Booker, ‘The Lie: Exposing the Satanic
Plot Behind Anti-Semitism, Ch. 4)

1429 A.D. – Mainz, Germany – Jews Expelled (Bell and Burnett, ‘Jews, Judaism, and The
Reformation in Sixteenth Century Germany’, p. 35)

1429 A.D. – Jerusalem, Palestine – Jews Expelled partially for desecration/arson of a church
(C. Roth, ‘The History of the Jews of Italy’, p. 275)

1430 A.D. – Saxony, Germany – Jews Expelled (Bell and Burnett, ‘Jews, Judaism, and The
Reformation in Sixteenth Century Germany’, p. 35)

1430 A.D. – Lindau, Germany – Jews Expelled/Exterminated (Bell and Burnett, ‘Jews, Judaism,
and The Reformation In Sixteenth Century Germany’, p. 478)

1430 A.D. – Palermo, Italy – Jews Expelled for Jewish doctor’s plotting the deaths of Christian
patients (C. Roth, ‘The History of the Jews of Italy’, p. 239)

1430 A.D. – Piedmont, Savoy, Italy – Jews Expelled to outside of city in Ghetto (C. Roth, ‘The
History of the Jews of Italy’, p. 312)

1431 A.D. – Pesaro, Italy – Jews Expelled after pogroms (C. Roth, ‘The History of the Jews of
Italy’, p. 162)

1432 A.D. – Savoy, Germany – Jews Expelled (P.E. Grosser/E.G. Halperin, ‘Anti-Semitism:
Causes and Effects)

1435 A.D. – Speyer, Germany – Jews Expelled “Forever”
(http://www.jewishhistory.org.il/history.php)

1436 A.D. – Zurich, Switzerland – Jews Expelled (B. Booker, ‘The Lie: Exposing the Satanic Plot
Behind Anti-Semitism, Ch. 4)

1438 A.D. – Bavaria, Germany – Jews Expelled (Bell and Burnett, ‘Jews, Judaism, and The
Reformation in Sixteenth Century Germany’, p. 35)

1438 A.D. – Mainz, Germany – Jews Expelled (P.E. Grosser/E.G. Halperin, ‘Anti-Semitism:
Causes and Effects)

1438-1439 A.D. – Augsburg, Germany – Jews Expelled
(https://en.wikipedia.org/wiki/Frankfurter_Judengasse)

1442 A.D. – Bamberg, Upper Baveria, Germany – Jews Expelled (B. Booker, ‘The Lie: Exposing
the Satanic Plot Behind Anti-Semitism, Ch. 4)

1442 A.D. – The Netherlands – Jews Expelled

1442 A.D. – The Papal States, Italy – Jews Expelled after multiple pogroms (C. Roth, ‘The
History of the Jews of Italy’, p. 165)

1442 A.D. – San Marino, Italy – Jews Expelled by the Podesta for organizing a conspiracy
against the republic (C. Roth, ‘The History of the Jews of Italy’, p. 122)

1442 A.D. – Bavaria, Germany – Jews Expelled (Bell and Burnett, ‘Jews, Judaism, and The
Reformation in Sixteenth Century Germany’, p. 35)

1444 A.D. – Atrecht, The Netherlands – Jews Expelled
(http://www.jewishencyclopedia.com/articles/11450-netherlands)

1444 A.D. – Inner Austria – Jews Expelled partially for Moneylending by Frederick III (Gerhard
Benecke, ‘Maximilian I: 1459-1519: An Analytical Biography’, p. 71)

1444 A.D. – Giessen, Germany – Jews Expelled (Bell and Burnett, ‘ Jews, Judaism, and The
Reformation in Sixteenth Century Germany’, p. 442)

1446 A.D. – Bavaria, Germany – Jews Expelled

1446 A.D. – Brandenburg, Germany – Jews Expelled
(http://www.jewishvirtuallibrary.org/brandenburg)

1446 A.D. – Berlin, Germany – Jews Expelled (B. Booker, ‘The Lie: Exposing the Satanic Plot
Behind Anti-Semitism, Ch. 4)

1449 A.D. – Toledo, Spain – Jews and Marranos massacred by Old Christians after causing
rebellion against King Juan II of Trastamara; this was after Marrano Jews had already
enlsaved Toledo’s Old Christians financially for decades (R. Maryks, ‘The Jesuit Order as a
Synagogue of Jews’, p. 2-3; C. Roth, ‘A History of The Marranos’, p. 32-33)

1449 A.D. – Ciudad Real – Converso Jews expelled and their quarters sacked by the Order of
Calatrava after taking over financial adminstration (C. Roth, ‘A History of The Marranos’, p.
32-33)

1449 A.D. – Lisbon, Portugal – Jews Massacred/Self-deported (C. Roth, ‘A History of The
Marranos’, p. 54)

1450 A.D. – Lower Bavaria, Germany – Jews Expelled (Bell and Burnett, ‘Jews, Judaism, and
The Reformation in Sixteenth Century Germany’, p. 35)

1451 A.D. – Messina, Italy – Jews Expelled for excesses in banking, trade, brokerage,
moneylending (C. Roth, ‘The History of the Jews of Italy, p. 250)

1452 A.D. – Cuneo, Italy – Jews Expelled by the Franciscans (C. Roth, ‘The History of the Jews
of Italy’, p. 165)

1452 A.D. – Lombarty, Italy – Jews Expelled for moneylending (C. Roth, ‘The History of the
Jews of Italy’, p. 166)

1453 A.D. – Silesia, Germany –

1453 A.D. – Vicenza, Italy – Jews Expelled unsuccessfully
(http://www.jewishvirtuallibrary.org/vicenza)

1453 A.D. – Padua, Italy – Jews Expelled for moneylending (C. Roth, ‘The History of Jews of
Italy’, p. 166)

1453 A.D. – Marsala, Italy – Jews Expelled after pogrom (C. Roth, ‘The History of the Jews of
Italy, p. 250)

1453 A.D. – France – Jews Expelled

1453 A.D. – Breslau, Germany – Jews Expelled by John of Capistrano for Host Desecration
(Bell and Burnett, ‘Jews, Judaism, and The Reformation in Sixteenth Century Germany’, p.
35)

1453 A.D. – Schweidnitz-Jauer, Germany – Jews Expelled (Bell and Burnett, ‘Jews, Judaism,
and The Reformation in Sixteenth Century Germany’, p. 35)

1453 A.D. – Franconia, Germany – Jews Expelled (P.E. Grosser/E.G. Halperin, ‘Anti-Semitism:
Causes and Effects)

1453 A.D. – Constantinople, Byzantine Empire – Jews partially expelled and massacred by
Greeks for allowing the invading Ottoman Turks to enter the city directly through the Jewish
quarter with the assistance of the Jews (S.J. Shaw, ‘The Jews of the Ottoman Empire and the
Turkish Republic’, p. 26)

1453 A.D. – Liegnitz-Brieg – Jews Expelled (Bell and Burnett, ‘Jews, Judaism, and The
Reformation in Sixteenth Century Germany’, p. 35)

1454 A.D. – Wurzburg, Germany – Jews Expelled (P.E. Grosser/E.G. Halperin, ‘Anti-Semitism:
Causes and Effects)

1454 A.D. – Piedmont, Italy – Jews Expelled (and shorty recalled) (C. Roth, ‘The History of
Jews of Italy’, p. 165)

1454 A.D. – Genoa, Italy – Jews Expelled for Extortion (C. Roth, ‘The History of the Jews of
Italy’, p. 136)

1455 A.D. – Rome, Italy – Jews Expelled after riot because Jews tried to bribe the Pope (C.
Roth, ‘The History of the Jews of Italy’, p. 166)

1456 A.D. – Polizzi, Italy – Jews Expelled after Easter riot (C. Roth, ‘The History of the Jews of
Italy, p. 250)

1456 A.D. – Taormina, Italy – Jews Expelled by Dominicans after annual fair (C. Roth, ‘The
History of the Jews of Italy, p. 250)

1456 A.D. – Marsala, Italy – Jews Expelled on St. Stephen’s day after riots (C. Roth, ‘The
History of the Jews of Italy, p. 250)

1456 A.D. – Bavaria, Germany – Jews Expelled (P.E. Grosser/E.G. Halperin, ‘Anti-Semitism:
Causes and Effects)

1457 A.D. – Hildesheim, Germany – Jews Expelled (Bell and Burnett, ‘ Jews, Judaism, and The
Reformation in Sixteenth Century Germany’, p. 35, 433)

1458 A.D. – Erfurt, Germany – Jews Expelled (B. Booker, ‘The Lie: Exposing the Satanic Plot
Behind Anti-Semitism, Ch. 4)

1458 A.D. – Calabria, Italy – Jews Expelled after rising of the baronage and peasants (C. Roth,
‘The History of the Jews of Italy’, p. 277)

1460 A.D. – Gottingen, Germany – Jews Expelled (Bell and Burnett, ‘ Jews, Judaism, and The
Reformation in Sixteenth Century Germany’, p. 433)

1460 A.D. – Mainz, Germany – Jews Expelled (B. Booker, ‘The Lie: Exposing the Satanic Plot
Behind Anti-Semitism, Ch. 4)

1460 A.D. – Bohemia – Jews Expelled after John Capistrano preaches against them (C. Roth,
‘The History of the Jews of Italy’, p. 166)

1460 A.D. – Faenza, Italy – Jews partially Expelled by Fra Bernardino da Feltre (C. Roth, ‘The
History of the Jews of Italy’, p. 202)

1461 A.D. – Julich, Germany – Jews Expelled (Bell and Burnett, ‘Jews, Judaism, and The
Reformation in Sixteenth Century Germany’, p. 35)

1461 A.D. – Berg, Germany – Jews Expelled (Bell and Burnett, ‘Jews, Judaism, and The
Reformation in Sixteenth Century Germany’, p. 35)

1462 A.D. – Italy – Jews Expelled (http://www.jewishvirtuallibrary.org/timeline-of-jewishhistory-in-italy)

1462 A.D. – Mainz, Germany – Jews Expelled again (Barbara W. Tuchman, ‘A Distant Mirror’,
p. 113)

1463 A.D. – Calabria, Italy – Jews Expelled again (C. Roth, ‘The History of the Jews of Italy’, p.
277)

1463 A.D. – Bari, Italy – Jews Expelled/re-admitted by Alfonso I (C. Roth, ‘The History of the
Jews of Italy’, p. 277)

1463 A.D. – Acri, Italy – Jews Expelled (C. Roth, ‘The History of the Jews of Italy’, p. 277)

1463 A.D. – Lecce, Italy – Jews Expelled (C. Roth, ‘The History of the Jews of Italy’, p. 277)

1465 A.D. – Fes, Morocco – Jews Expelled (http://www.jewishvirtuallibrary.org/thetreatment-of-jews-in-arab-islamic-countries)

1466 A.D. – Arnstadt, Germany – Jews Expelled/Killed (B. Booker, ‘The Lie: Exposing the
Satanic Plot Behind Anti-Semitism, Ch. 4)

1466 A.D. – Sicily, Italy – Jews Expelled by Queen Isabella I
(http://www.jewishhistory.org.il/history.php)

1468 A.D. – Gaeta, Naples – Jews Expelled by townsfolk but denied by King Ferrante I
(http://www.jewishvirtuallibrary.org/gaeta)

1468 A.D. – Egypt – Jews Expelled by Sultan Qa’it Bay
(http://www.jewishhistory.org.il/history.php)

1469 A.D. – Sicily, Italy – Jews Expelled again after jealosy of 400 richly-dressed Jews march
in parade (C. Roth, ‘The History of the Jews of Italy’, p. 253)

1470 A.D. – Baden, Germany – Jews Expelled/Killed for Ritual Murder (B. Booker, ‘The Lie:
Exposing the Satanic Plot Behind Anti-Semitism, Ch. 4)

1470 A.D. – Florence, Italy – Jews Expelled (E. Michael Jones, ‘Barren Metal: A History of
Capitalism as the Conflict Between Labor and Usury’, p. 196)

1472 A.D. – Schaffhausen, Switzerland – Jews Expelled (B. Booker, ‘The Lie: Exposing the
Satanic Plot Behind Anti-Semitism, Ch. 4)

1473 A.D. – Cordoba, Spain – Jews and Marranos Expelled by The Christian Brotherhood
acting under King Henry The Impotent after being accused of bribing one of the most
powerful generals, Alonso Fernandez de Aguilar (C. Roth, ‘A History of The Marranos’, p. 35-
36)

1473 A.D. – Jaen, Spain – Jews Expelled after being accused of murdering the Constable of
Castile (C. Roth, ‘A History of The Marranos’, p. 36)

1473 A.D. – Trapani, Italy – Jews Expelled after pogrom (C. Roth, ‘The History of the Jews of
Italy, p. 250)

1474 A.D. – Palermo, Italy – Jews Expelled for heresy/blasphemy (C. Roth, ‘The History of the
Jews of Italy, p. 250)

1474 A.D. – Termini, Italy – Jews Expelled for “lese majeste” and blasphemy (C. Roth, ‘The
History of the Jews of Italy, p. 250)

1474 A.D. – Sciacca, Italy – Jews Expelled for “lese majeste” and blasphemy (C. Roth, ‘The
History of the Jews of Italy, p. 250)

1474 A.D. – Modica, Italy – Jews Expelled after a mob attack on Jewish quarter (C. Roth, ‘The
History of the Jews of Italy, p. 250)

1474 A.D. – Mainz, Germany – Jews Expelled (Barbara W. Tuchman, ‘A Distant Mirror’, p.
113)

1474 A.D. – Serovia, Spain – Jews Expelled/Massacred (C. Roth, ‘A History of The Marranos’,
p. 36)

1475 A.D. – Tirol, Germany – Jews Expelled (Bell and Burnett, ‘Jews, Judaism, and The
Reformation in Sixteenth Century Germany’, p. 35)

1475 A.D. – Noto, Italy – Jews Expelled after riots (C. Roth, ‘The History of the Jews of Italy, p.
252)

1475 A.D. – Monte S. Giuliano, Italy – Jews Expelled after riots (C. Roth, ‘The History of the
Jews of Italy, p. 252)

1475 A.D. – Sciassa, Italy – Jews Expelled after riots (C. Roth, ‘The History of the Jews of Italy,
p. 252)

1475 A.D. – Palermo, Italy – Jews Expelled after riots (C. Roth, ‘The History of the Jews of
Italy, p. 252)

1475 A.D. – Naro, Italy – Jews Expelled after riots (C. Roth, ‘The History of the Jews of Italy, p.
252)

1475 A.D. – Castrogiovanni, Italy – Jews Expelled after riots (C. Roth, ‘The History of the Jews
of Italy, p. 252)

1475 A.D. – Messina, Italy – Jews Expelled after riots (C. Roth, ‘The History of the Jews of
Italy, p. 252)

1475 A.D. – Trent, Italy – Jews Expelled for Ritual Murder of Christian child “For 300 Years”
(R. Po-Chia Hsia, ‘Trent 1475: Stories of a Ritual Murder Trial’)

1475 A.D. – Bamberg, Austria – Jews Expelled for Ritual Murder of Christian child
(http://www.jewishvirtuallibrary.org/carinthia)

1476 A.D. – Berg, Germany – Jews Expelled (Bell and Burnett, ‘Jews, Judaism, and The
Reformation in Sixteenth Century Germany’, p. 35)

1476 A.D. – Caltagirone, Italy – Jews Expelled after riots (C. Roth, ‘The History of the Jews of
Italy, p. 252)

1476 A.D. – Agosta, Italy – Jews Expelled after riots (C. Roth, ‘The History of the Jews of Italy,
p. 252)

1477 A.D. – Tubingen, Germany – Jews Expelled (B. Booker, ‘The Lie: Exposing the Satanic
Plot Behind Anti-Semitism, Ch. 4)

1477 A.D. – Lorraine, France – Jews Expelled (Bell and Burnett, ‘Jews, Judaism, and The
Reformation in Sixteenth Century Germany’, p. 35)

1478 A.D. – Venice, Italy – Jews Expelled by populace/denied by Medici (C. Roth, ‘The History
of the Jews of Italy’, p. 173)

1478 A.D. – Brescia, Italy – Jews Expelled because Christians were attending Jewish Weddings
(C. Roth, ‘The History of the Jews of Italy’, p. 173)

1478 A.D. – Mantua – Italy – Jews Expelled for Ritual Murder (C. Roth, ‘The History of the
Jews of Italy’, p. 173)

1478 A.D. – Reggio, Italy – Jews Expelled for Ritual Murder (C. Roth, ‘The History of the Jews
of Italy’, p. 173)

1478 A.D. – Passau, Bavaria – Jews Expelled/Killed for Host Desecration (B. Booker, ‘The Lie:
Exposing the Satanic Plot Behind Anti-Semitism, Ch. 4)

1478 A.D. – Bamberg, Upper Bavaria, Germany – Jews Expelled
(http://www.jewishencyclopedia.com/articles/2422-bamberg)

1478 A.D. – Styria, Germany – Jews Expelled partially by Frederick III after multiple pogroms
for Jewish Moneylending (Gerhard Benecke, ‘Maximilian I: 1459-1519: An Analytical
Biography’, p. 71)

1479 A.D. – Strasbourg, Germany – Jews Expelled (Bell and Burnett, ‘ Jews, Judaism, and The
Reformation in Sixteenth Century Germany’, p. 436)

1479 A.D. – Milan, Italy – Jews Expelled for Ritual Murder (C. Roth, ‘The History of the Jews of
Italy’, p. 173)

1479 A.D. – Arena, Italy – Jews Expelled for Ritual Murder (C. Roth, ‘The History of the Jews
of Italy’, p. 173)

1479 A.D. – Pavia, Italy – Jews Expelled after Jewish quarter of city sacked (C. Roth, ‘The
History of the Jews of Italy’, p. 173)

1479 A.D. – Portobuffole, Treviso, Italy – Jews Expelled for Ritual Murder (C. Roth, ‘The
History of the Jews of Italy’, p. 173)

1479 A.D. – Helmstadt, Germany – Jews Expelled (Bell and Burnett, ‘ Jews, Judaism, and The
Reformation in Sixteenth Century Germany’, p. 433)

1480 A.D. – Cologne, Germany – Jews Expelled (Bell and Burnett, ‘Jews, Judaism, and The
Reformation in Sixteenth Century Germany’, p. 35)

1480 A.D. – Brescia, Italy – Jews Expelled again by Church authorities (C. Roth, ‘The History of
the Jews of Italy’, p. 173)

1483 A.D. – Andalusia, Spain – Jews Expelled by King Ferdinand II of Aragon
(http://www.jewishhistory.org.il/history.php)

1483 A.D. – Seville, Spain – Jews Expelled by King Ferdinand II of Aragon
(http://www.jewishhistory.org.il/history.php)

1483 A.D. – Cordova, Spain – Jews Expelled by King Ferdinand II of Aragon
(http://www.jewishhistory.org.il/history.php)

1483 A.D. – Mainz, Germany – Jews Expelled (Bell and Burnett, ‘Jews, Judaism, and The
Reformation in Sixteenth Century Germany’, p. 35)

1484 A.D. – Katzeneln-bogen, Germany – Jews Expelled (Bell and Burnett, ‘Jews, Judaism,
and The Reformation in Sixteenth Century Germany’, p. 35)

1484 A.D. – Hesse, Germany – Jews Expelled (Bell and Burnett, ‘Jews, Judaism, and The
Reformation in Sixteenth Century Germany’, p. 35)

1484 A.D. – Warsaw, Poland – Jews Expelled (Bell and Burnett, ‘Jews, Judaism, and The
Reformation in Sixteenth Century Germany’, p. 35)

1485 A.D. – Bamberg, Germany – Jews Expelled (Bell and Burnett, ‘Jews, Judaism, and The
Reformation in Sixteenth Century Germany’, p. 35)

1485 A.D. – Perugia, Italy – Jews Expelled (C. Roth, ‘The History of the Jews of Italy’, p. 175)

1485 A.D. – Verona, Italy – Jews Expelled for Ritual Murder (C. Roth, ‘The History of the Jews
of Italy’, p. 173)

1485 A.D. – Viadana, Italy – Jews Expelled for Ritual Murder (C. Roth, ‘The History of the Jews
of Italy’, p. 173)

1485 A.D. – Helmstadt, Germany – Jews Expelled (Bell and Burnett, ‘ Jews, Judaism, and The
Reformation in Sixteenth Century Germany’, p. 433)

1485-1486 A.D. – Vincenza, Italy – Jews Expelled (C. Roth, ‘The History of the Jews of Italy’, p.
175)

1486 A.D. – Gubbio, Italy – Jews Expelled (C. Roth, ‘The History of the Jews of Italy’, p. 175)

1486 A.D. – Saragossa, Spain – Jews Expelled after the Arbues Affair, in which Jews had
“influenced” the Marannos to act against Spain’s interests; the King orders the sudden
expulsion of Jews from the entire archbishopric, as a “foreshadowing” of the “final solution”
in 1492 (Norman Roth, ‘Medieval Jewish Civilization: An Encyclopedia’, p. 35)

1486 A.D. – Albarracin, Spain – Jews Expelled after the Arbues Affair (Norman Roth,
‘Medieval Jewish Civilization: An Encyclopedia’, p. 35)

1486-1487 A.D. – Syracuse, Italy – Jews Expelled after riots (C. Roth, ‘The History of the Jews
of Italy’, p. 252)

1486-1487 A.D. – Caltagirone, Italy – Jews Expelled after riots (C. Roth, ‘The History of the
Jews of Italy’, p. 252)

1486-1487 A.D. – Sciatta, Italy – Jews Expelled after riots (C. Roth, ‘The History of the Jews of
Italy’, p. 252)

1486-1487 A.D. – Malta, Italy – Jews Expelled after riots (C. Roth, ‘The History of the Jews of
Italy’, p. 252)

1487 A.D. – Taormina, Italy – Jews Expelled after stoning of Jewish quarter (C. Roth, ‘The
History of the Jews of Italy’, p. 252)

1487 A.D. – Corleone, Italy – Jews Expelled after a riot (C. Roth, ‘The History of the Jews of
Italy’, p. 252)

1488 A.D. – Oettingem, Germany – Jews Expelled (Bell and Burnett, ‘Jews, Judaism, and The
Reformation in Sixteenth Century Germany’, p. 35)

1488 A.D. – Florence, Italy – Jews Expelled; immediately recalled b/c of a Jewish bribe to
Lorenzo de’Medici – (C. Roth, ‘The History of the Jews of Italy’, p. 175)

1489 A.D. – Brandenburg, Germany – Jews Expelled (Bell and Burnett, ‘Jews, Judaism, and
The Reformation in Sixteenth Century Germany’, p. 35)

1489 A.D. – Forli, Italy – Jews Expelled for moneylending (C. Roth, ‘The History of the Jews of
Italy’, p. 175)

1489 A.D. – Provence, France – Jews Expelled (B. Booker, ‘The Lie: Exposing the Satanic Plot
Behind Anti-Semitism, Ch. 4)

1490 A.D. – Castroreale, Italy – Jews Expelled after pogroms (C. Roth, ‘The History of the Jews
of Italy’, p. 252)

1490 A.D. – Santa Lucia, Italy – Jews Expelled after pogroms (C. Roth, ‘The History of the Jews
of Italy’, p. 252)

1491 A.D. – Castiglione, Italy – Jews Expelled on Christmas after pogrom (C. Roth, ‘The
History of the Jews of Italy’, p. 254)

1491 A.D. – Ravenna, Italy – Jews Expelled (http://www.jewishvirtuallibrary.org/timeline-ofjwish-history-in-italy)

1491 A.D. – Thurgau, Switzerland – Jews Expelled (B. Booker, ‘The Lie: Exposing the Satanic
Plot Behind Anti-Semitism, Ch. 4)

1491 A.D. – Provence, France – Jews Expelled (C. Roth, ‘The History of the Jews of Italy’, p.
259)

1492 A.D. – Wurttenberg, Germany – Jews Expelled (Bell and Burnett, ‘Jews, Judaism, and
The Reformation in Sixteenth Century Germany’, p. 35)

1492 A.D. – Spain – Jews Expelled by King Ferdinand II of Aragon and Queen Isabella I of
Castile (Philip Broadhead/Chris Cook, ‘The Routledge Companion to Early Modern Europe,
1493-1763)

1492 A.D. – Colonies of Spain – Jews Expelled by King Ferdinand II of Aragon and Queen
Isabella I of Castile (Philip Broadhead/Chris Cook, ‘The Routledge Companion to Early
Modern Europe, 1493-1763)

1492 A.D. – Aragon, Spain – Jews Expelled again for Ritual Murder (B. Booker, ‘The Lie:
Exposing the Satanic Plot Behind Anti-Semitism, Ch. 4)

1492 A.D. – Sardinia, Italy – Jews Expelled (C. Roth, ‘The History of the Jews of Italy’, p. 254,
268)

1492 A.D. – Ciminna, Italy – Jews Expelled/thrown into prison by lord (C. Roth, ‘The History of
the Jews of Italy’, p. 259)

1492 A.D. – Cammarata, Italy – Jews Expelled (C. Roth, ‘The History of the Jews of Italy’, p.
259)

1492 A.D. – Girgenti, Italy – Jews Expelled/arrested/imprisoned (C. Roth, ‘The History of the
Jews of Italy’, p. 259)

1492 A.D. – Genoa, Italy – Jews Expelled (C. Roth, ‘The History of the Jews of Italy’, p. 189)

1492 A.D. – Venice, Italy – Jews Expelled due to preaching of Fra Bernardino (C. Roth, ‘The
History of the Jews of Italy’, p. 175)

1492 A.D. – Castelfranco, Italy – Jews Expelled due to preaching of Fra Bernardino (C. Roth,
‘The History of the Jews of Italy’, p. 175)

1492 A.D. – Bassano, Italy – Jews Expelled due to preaching of Fra Bernardino (C. Roth, ‘The
History of the Jews of Italy’, p. 175)

1492 A.D. – Crema, Italy – Jews Expelled due to preaching of Fra Bernardino (C. Roth, ‘The
History of the Jews of Italy’, p. 175)

1492 A.D. – Alghero, Italy – Jews Expelled (http://www.jewishvirtuallibrary.org/alghero)

1492 A.D. – Fano, Italy – Jews Expelled by municipal council/unsuccessful (C. Roth, ‘The
History of the Jews of Italy’, p. 173)

1492 A.D. – Castronuovo, Italy – Jews Expelled (C. Roth, ‘The History of the Jews of Italy’, p.
260)

1492 A.D. – Piazza, Italy – Jews Expelled (C. Roth, ‘The History of the Jews of Italy’, p. 260)

1492 A.D. – S. Marco, Italy – Jews Expelled (C. Roth, ‘The History of the Jews of Italy’, p. 260)

1492 A.D. – Castroreale, Italy – Jews Expelled (C. Roth, ‘The History of the Jews of Italy’, p.
260)

1492 A.D. – Caltagirone, Italy – Jews Expelled (C. Roth, ‘The History of the Jews of Italy’, p.
260)

1492 A.D. – Ragusa, Italy – Jews Expelled (C. Roth, ‘The History of the Jews of Italy’, p. 260)

1492 A.D. – Lentini, Italy – Jews Expelled (C. Roth, ‘The History of the Jews of Italy’, p. 260)

1492 A.D. – Camarata, Italy – Jews Expelled (C. Roth, ‘The History of the Jews of Italy’, p. 260)

1492 A.D. – Sciatta, Italy – Jews Expelled (C. Roth, ‘The History of the Jews of Italy’, p. 260)

1492 A.D. – Syracuse, Italy – Jews Expelled (C. Roth, ‘The History of the Jews of Italy’, p. 260)

1492 A.D. – Taranto, Italy – Jews Expelled (C. Roth, ‘The History of the Jews of Italy’, p. 260)

1492 A.D. – Cagliari, Italy – Jews Expelled (C. Roth, ‘The History of the Jews of Italy’, p. 268)

1492 A.D. – Duchy of Mecklenburg, Germany – Jews Expelled (Bell and Burnett, ‘ Jews,
Judaism, and The Reformation in Sixteenth Century Germany’, p. 428)

1492 A.D. – Campo St. Pietro, Italy – Jews Expelled (C. Roth, ‘The History of the Jews of Italy’,
p. 175)

1492 A.D. – Pietro, Italy – Jews Expelled (C. Roth, ‘The History of the Jews of Italy, p. 176)

1492 A.D. – Rome, Italy – Jews to be expelled; bribed the Borgia Pope, Alexander VI to stay
(C. Roth, ‘The History of the Jews of Italy’, p. 179)

1492-1493 A.D. – Sicily, Italy – Jews Expelled for Ritual Murder (C. Roth, ‘The History of the
Jews of Italy’, p. 178, 261)

1493 A.D. – Magdeburg, Germany – Jews Expelled (Bell and Burnett, ‘ Jews, Judaism, and The
Reformation in Sixteenth Century Germany’, p. 433)

1493 A.D. – Archbishopric of Mecklenburg, Germany – Jews Expelled for Host Desecration
Bell and Burnett, ‘ Jews, Judaism, and The Reformation in Sixteenth Century Germany’, p.
33; Jews Expelled (Bell and Burnett, ‘Jews, Judaism, and The Reformation in Sixteenth
Century Germany’, p. 35)

1493 A.D. – Pomerania, Germany – Jews Expelled (Bell and Burnett, ‘ Jews, Judaism, and The
Reformation in Sixteenth Century Germany’, p. 35, 433)

1493 A.D. – Halberstadt, Germany – Jews Expelled (Bell and Burnett, ‘Jews, Judaism, and The
Reformation in Sixteenth Century Germany’, p. 35)

1494 A.D. – Naumberg, Germany – Jews Expelled (Bell and Burnett, ‘Jews, Judaism, and The
Reformation in Sixteenth Century Germany’, p. 35)

1494 A.D. – Brescia, Italy – Jews Expelled b/c of propaganda by Fra Bernardino (C. Roth, ‘The
History of the Jews of Italy’, p. 176)

1494 A.D. – Naples, Italy – Jews Expelled after French invasion (C. Roth, ‘The History of the
Jews of Italy’, p. 280)

1494 A.D. – Lecce, Italy – Jews Expelled after French invasion (C. Roth, ‘The History of the
Jews of Italy’, p. 280)

1494 A.D. – Acquaviva, Italy – Jews Expelled after French invasion (C. Roth, ‘The History of
the Jews of Italy’, p. 280)

1494 A.D. – Catanzaro, Italy – Jews Expelled after French invasion (C. Roth, ‘The History of
the Jews of Italy’, p. 280)

1494 A.D. – Bitonto, Italy – Jews Expelled after French invasion (C. Roth, ‘The History of the
Jews of Italy’, p. 280)

1494 A.D. – Cozenza, Italy – Jews Expelled after French invasion (C. Roth, ‘The History of the
Jews of Italy’, p. 280)

1495 A.D. – Naples, Italy – Maranno Jews Expelled (C. Roth, ‘The History of the Jews of Italy’,
p. 281)

1495 A.D. – Forence, Italy – Jews Expelled by Girolamo Savonarola (E. Michael Jones, ‘Barren
Metal’, p. 197)

1495 A.D. – Lithuania – Jews Expelled by Grand Duke Alexander (Bernard D. Weinryb, ‘A
Social and Economic History of the Jewish Community in Poland from 1100 to 1800)

1495 A.D. – Cracow, Poland – Jews Expelled by King Alexander I of Poland (Bernard D.
Weinryb, ‘A Social and Economic History of the Jewish Community in Poland from 1100 to
1800)

1495 A.D. – Kazimierz, Poland – Jews Expelled by King Alexander I of Poland (Bernard D.
Weinryb, ‘A Social and Economic History of the Jewish Community in Poland from 1100 to
1800)

1496 A.D. – Carinthia, Germany – Jews Expelled (Bell and Burnett, ‘Jews, Judaism, and The
Reformation in Sixteenth Century Germany’, p. 35)

1496 A.D. – Napels, Italy – Jews Expelled again (C. Roth, ‘The History of the Jews of Italy’, p.
281)

1496 A.D. – Florence, Italy – Jews Expelled along with the Medici by Savonarola (C. Roth, ‘The
History of the Jews of Italy’, p. 190)

1496 A.D. – Portugal – Jews partially Expelled by King Manuel I
(http://www.jewishhistory.org.il/history/php)

1496 A.D. – Carinthia, Slovenia – Jews Expelled by Emperor Maximilian I
(http://www.jewishvirtuallibrary.org/ljubljana)

1496 A.D. – Styria, Austria – Jews Expelled by Emperor Maximilian I (Bell and Burnett, ‘ Jews,
Judaism, and The Reformation in Sixteenth Century Germany’, p. 433)

1497 A.D. – Graz, Austria – Jews Expelled for a third time by Emperor Maximilian I
(http://www.jewishhistory.org.il/history/php)

1497 A.D. – Isenberg-Budingen, Germany – Jews Expelled (Bell and Burnett, ‘Jews, Judaism,
and The Reformation in Sixteenth Century Germany’, p. 35)

1497 A.D. – Portugal – Jews Expelled officially (C. Roth, ‘The History of the Jews of Italy’, p.
180; C. Roth, ‘A History of The Marranos’, p. 54-73)

1497 A.D. – Venice, Italy – Marranno Jews Expelled (C. Roth, ‘The History of the Jews of Italy’,
p. 187)

1498 A.D. – Salzburg, Germany – Jews Expelled (Bell and Burnett, ‘Jews, Judaism, and The
Reformation in Sixteenth Century Germany’, p. 35)

1498 A.D. – Venice, Italy – Jews Expelled for Usury (C. Roth, ‘The History of the Jews of Italy’,
p. 130)

1498 A.D. – Navarre, Spain – Jews Expelled
(http://www.encyclopedia.com/history/encyclopedias-almanacs-transcipts-and-maps/jewsexpulsion-spain-portugal)

1498 A.D. – Provence, France – Jews Expelled by King Louis XII (C. Roth, ‘The History of the
Jews of Italy’, p. 180)

1498-1499 A.D. – Nuremberg, Germany – Jews Expelled (Bell and Burnett, ‘ Jews, Judaism,
and The Reformation in Sixteenth Century Germany’, p. 433)

1498-1499 A.D. – Verona, Italy – Jews Expelled for Usury (C. Roth, ‘The History of the Jews of
Italy’, p. 130)

1499 A.D. – Rhodes, Italy – Jews Expelled (admitted to Nice) (C. Roth, ‘The History of the Jews
of Italy’, p. 180)

1499 A.D. – Nuremberg, Germany – Jews Expelled (Bell and Burnett, ‘ Jews, Judaism, and The
Reformation in Sixteenth Century Germany’, p. 441)

1501 A.D. – Provence, France – Jews Expelled (B. Booker, ‘The Lie: Exposing the Satanic Plot
Behind Anti-Semitism’, Ch. 4)

1502 A.D. – Florence, Italy – Jews to be Expelled/Saved by Catherine Sforza (C. Roth, ‘The
History of the Jews of Italy’, p. 201)

1504 A.D. – Pilsen, Bohemia – Jews Expelled for Host Desecration (B. Booker, ‘The Lie:
Exposing the Satanic Plot Behind Anti-Semitism’, Ch. 4)

1504 A.D. – Moscow, Russia – Jews Expelled (http://www.jewishhistory.org.il/history.php)

1504 A.D. – Evora, Portugal – Jewish Marranos Expelled/Exterminated (C. Roth, ‘A History of
The Marranos’, p. 64)

1504 A.D. – Piacenza, Italy – Jews Expelled b/c a non-Jew bank came to town (C. Roth, ‘The
History of the Jews of Italy’, p. 182)

1505 A.D. – Orange, France – Jews Expelled (B. Booker, ‘The Lie: Exposing the Satanic Plot
Behind Anti-Semitism’, Ch. 4)

1506 A.D. – Lisbon, Portugal – Jewish Marranos Expelled/over 500 (another source says
between 2 and 4 thousand) killed by peasant mob mainly because there was a famine and a
New Christian tax-farmer, who just so happened to be the richest and most hated man in
Lisbon, was blamed for it (probably correctly)(Philip Broadhead/Chris Cook, ‘The Routledge
Companion to Early Modern Europe, 1453-1763; C. Roth, ‘A History of The Marranos’, p. 64-
66)

1506 A.D. – Nola, Italy – Jews Expelled (C. Roth, ‘The History of the Jews of Italy’, p. 283)

1507 A.D. – Nordlingen, Germany – Jews Expelled (Bell and Burnett, ‘ Jews, Judaism, and The
Reformation in Sixteenth Century Germany’, p. 433)

1509 A.D. – Treviso, Italy – Jews Expelled due to banking complaints (C. Roth, ‘The History of
the Jews of Italy, p. 184)

1509 A.D. – Verona, Italy – Jews Expelled due to banking complaints (C. Roth, ‘The History of
the Jews of Italy, p. 184)

1509 A.D. – Novi, Italy – Jews Expelled for Ritual Murder (C. Roth, ‘The History of the Jews of
Italy’, p. 183)

1509 A.D. – Padua, Italy – Jews Expelled after city is sacked (C. Roth, ‘The History of the Jews
of Italy’, p. 194)

1510 A.D. – Braunschweig, Germany – Jews Expelled (Bell and Burnett, ‘ Jews, Judaism, and
The Reformation in Sixteenth Century Germany’, p. 433)

1510 A.D. – Brandenberg, Austria – Jews Expelled for Host Desecration and theft of Church
property (Bell and Burnett, ‘ Jews, Judaism, and The Reformation in Sixteenth Century
Germany’, p. 433)

1510 A.D. – Berlin, Germany – Jews Expelled for Host Desecration
(http://www.jewishvirtuallibrary.org/berlin-germany-jewish-history-tour)

1510 A.D. – Naples, Italy – Jews Expelled for third time by King Ferdinand II of Aragon (C.
Roth, ‘The History of the Jews of Italy’, p. 180)

1510 A.D. – Prussia – Jews Expelled

1510 A.D. – Apulia, Italy – Jews Expelled (C. Roth, ‘The History of the Jews of Italy’, p. 283)

1510 A.D. – Calabria, Italy – Jews Expelled (C. Roth, ‘The History of the Jews of Italy’, p. 189,
283)

1511 A.D. – Conegliano, Italy – Jews Expelled (unsuccessful)
(http://www.jewishvirtuallibrary.org/conegliano)

1511 A.D. – Reggio, Italy – Jews Expelled (C. Roth, ‘The History of the Jews of Italy’, p. 283)

1511 A.D. – Castrovillari, Italy – Jews Expelled (C. Roth, ‘The History of the Jews of Italy’, p.
283)

1511 A.D. – Lecce, Italy – Jews Expelled (C. Roth, ‘The History of the Jews of Italy’, p. 283)

1512 A.D. – Colmar, France – Jews Expelled (http://www.jewishvirtuallibrary.org/bischheim)

1512 A.D. – Regensburg, Germany – Jews Expelled (Raphael Straus, ‘Regensburg And
Augsburg’, p. 13)

1513 A.D. – Munzenbourg, Germany – Jews Expelled (Bell and Burnett, ‘ Jews, Judaism, and
The Reformation in Sixteenth Century Germany’, p. 442)

1514-1515 A.D. – Strasbourg, Germany – Jews Expelled (Bell and Burnett, ‘ Jews, Judaism,
and The Reformation in Sixteenth Century Germany’, p. 436)

1515 A.D. – Genoa, Italy – Jews Expelled (B. Booker, ‘The Lie: Exposing the Satanic Plot
Behind Anti-Semitism’, Ch. 4)

1515 A.D. – Ljubljana, Slovenia – Jews Expelled for a 4th time by Emperor Maximilian I
(http://www.jewishhistory.or.il/history.php)

1515 A.D. – Apulia, Italy – Jews/Marannos Expelled by Papal Inquisition (C. Roth, ‘The History
of the Jews of Italy’, p. 284)

1515 A.D. – Calabria, Italy – Jews/Marannos Expelled by Papal Inquisition (C. Roth, ‘The
History of the Jews of Italy’, p. 284)

1515 A.D. – Ragusa, Italy – Jews Expelled (C. Roth, ‘The History of the Jews of Italy’, p. 284)

1516 A.D. – Venice, Italy – Jews Expelled b/c rulers were “anti-Semitic” (C. Roth, ‘The History
of the Jews of Italy’, p. 186)

1516 A.D. – Lowicz, Poland – Jews Expelled (B. Booker, ‘The Lie: Exposing the Satanic Plot
Behind Anti-Semitism’, Ch. 4)

1516 A.D. – Gelnhausen, Germany – Jews Expelled/unsuccessful after a territorial-wide
meeting between princes, nobles, etc (Bell and Burnett, ‘ Jews, Judaism, and The
Reformation in Sixteenth Century Germany’, p. 442)

1516 A.D. – Hanau, Germany – Jews Expelled/unsuccessful after a territorial-wide meeting
between princes, nobles, etc (Bell and Burnett, ‘ Jews, Judaism, and The Reformation in
Sixteenth Century Germany’, p. 442)

1516 A.D. – Lindheim, Germany – Jews Expelled/unsuccessful after a territorial-wide meeting
between princes, nobles, etc (Bell and Burnett, ‘ Jews, Judaism, and The Reformation in
Sixteenth Century Germany’, p. 442)

1516 A.D. – Ruckingen, Germany – Jews Expelled/unsuccessful after a territorial-wide
meeting between princes, nobles, etc (Bell and Burnett, ‘ Jews, Judaism, and The
Reformation in Sixteenth Century Germany’, p. 442)

1518 A.D. – Conegliano, Italy – Jews Expelled/unsuccessful
(http://www.jewishvirtuallibrary.org/conegliano)

1519 A.D. – Weutemberg, Germany – Jews Expelled (B. Booker, ‘The Lie: Exposing the Satanic
Plot Behind Anti-Semitism’, Ch. 4)

1519 A.D. – Regensburg, Germany – Jews Expelled by Emperor Maximilian I at the instigation
of the radical reformer Balthasar Hubmaier (Bell and Burnett, ‘ Jews, Judaism, and The
Reformation in Sixteenth Century Germany’, p. 433, 441)

1519 A.D. – Dangolsheim, Germany – Jews Expelled (Bell and Burnett, ‘ Jews, Judaism, and
The Reformation in Sixteenth Century Germany’, p. 436)

1519-1520 A.D. – Rothenburg ob der Tauber, Germany – Jews Expelled (Bell and Burnett, ‘
Jews, Judaism, and The Reformation in Sixteenth Century Germany’, p. 433)

1522 A.D. – Nuremberg, Germany – Attempted Jewish Expulsion for forging coins and
smuggling good coins out of the region (Bell and Burnett, ‘ Jews, Judaism, and The
Reformation in Sixteenth Century Germany’, p. 436)

1523 A.D. – Medina, Italy – Jews Expelled after riots on Jewish quarters (C. Roth, ‘The History
of the Jews of Italy’, p. 182)

1523 A.D. – Bologna, Italy – Jews Expelled for Arson (C. Roth, ‘The History of the Jews of
Italy’, p. 182)

1524 A.D. – Hesse, Germany – Attempted Expulsion of Jews; failed after Jews bribe
Landgrave William II (Bell and Burnett, ‘ Jews, Judaism, and The Reformation in Sixteenth
Century Germany’, p. 441-443)

1524 A.D. – Kassel, Germany – Jews Expelled (Bell and Burnett, ‘ Jews, Judaism, and The
Reformation in Sixteenth Century Germany’, p. 443)

1524 A.D. – Marburg an der Lahn, Germany – Jews Expelled (Bell and Burnett, ‘ Jews,
Judaism, and The Reformation in Sixteenth Century Germany’, p. 443)

1524 A.D. – Calabria, Italy – Jews Expelled

1526 A.D. – Croatia – Jews Expelled by Emperor Ferdinand I for aiding the invading Turks
(http://www.jewishhistory.org)

1526 A.D. – Capua, Italy – Jews Expelled for moneylending (C. Roth, ‘The History of the Jews
of Italy’, p. 285)

1526 A.D. – Hungary – Jews Expelled by Emperor Ferdinand I for aiding the invading Turks
(http://www.jewishhistory.org)

1527 A.D. – Florence, Italy – Jews Expelled along with Medici family (C. Roth, ‘The History of
the Jews of Italy’, p. 190)

1527 A.D. – Pavia, Italy – Jews Expelled b/c of Plague (C. Roth, ‘The History of the Jews of
Italy’, p. 180)

1527 A.D. – Rome, Italy – Jews Expelled/unsuccessful because of bribe to Cardinal della Valle
(C. Roth, ‘The History of the Jews of Italy’, p. 191)

1528 A.D. – Hagenau, Germany – Jews Expelled (Bell and Burnett, ‘ Jews, Judaism, and The
Reformation in Sixteenth Century Germany’, p. 436)

1528 A.D. – Alentejo, Portugal – Marrano Jews Expelled/Exterminated (C. Roth, ‘A History of
The Marranos’ p. 68)

1528 A.D. – Santarem, Portugal – Marrano Jews Expelled/Exterminated (C. Roth, ‘A History of
The Marranos’ p. 68)

1528 A.D. – Gouvea, Portugal – Marrano Jews Expelled/Exterminated (C. Roth, ‘A History of
The Marranos’ p. 68)

1528 A.D. – Santarem, Portugal – Marrano Jews Expelled/Exterminated (C. Roth, ‘A History of
The Marranos’ p. 68)

1528 A.D. – Olivenca, Portugal – Marrano Jews Expelled/Exterminated (C. Roth, ‘A History of
The Marranos’ p. 68)

1528 A.D. – The Azores, Portugal – Marrano Jews Expelled/Exterminated (C. Roth, ‘A History
of The Marranos’ p. 68)

1528 A.D. – Madeira, Portugal – Marrano Jews Expelled/Exterminated (C. Roth, ‘A History of
The Marranos’ p. 68)

1529 A.D. – Posen, Germany – Jews Expelled/self-deport/30 burned at the stake for ritual
murder (Bell and Burnett, ‘ Jews, Judaism, and The Reformation in Sixteenth Century
Germany’, p. 436)

1530 A.D. – Modena, Italy – Jews Expelled for Ritual Murder (C. Roth, ‘The History of the Jews
of Italy’, p. 183)

1530 A.D. – Augsburg, Germany – Attempted Jewish Expulsion for Jews colluding with Turks
in Hungary; cancelled by Josel of Rosheim’s lobbying/bribing efforts (Bell and Burnett, ‘
Jews, Judaism, and The Reformation in Sixteenth Century Germany’, p. 436)

1530 A.D. – Strasbourg, Germany – Jews Expelled for moneylending/usury activities (Bell and
Burnett, ‘ Jews, Judaism, and The Reformation in Sixteenth Century Germany’, p. 443)
1531 A.D. – Capua, Italy – Jews Expelled again (C. Roth, ‘The History of the Jews of Italy’, p.
285)

1533 A.D. – Silesia, Germany – Jews Expelled for ritual murder (Bell and Burnett, ‘ Jews,
Judaism, and The Reformation in Sixteenth Century Germany’, p. 436)

1533 A.D. – Constance, Germany – Jews Expelled (B. Booker, ‘The Lie: Exposing the Satanic
Plot Behind Anti-Semitism’, Ch. 4)

1533 A.D. – Naples, Italy – Jews Expelled (C. Roth, ‘The History of the Jews of Italy’, p. 285)

1535 A.D. – Wurttemberg, Germany – Jews Expelled (Bell and Burnett, ‘ Jews, Judaism, and
The Reformation in Sixteenth Century Germany’, p. 436)

1536-1537 A.D. – Saxony, Germany – Jews Expelled (Paul Johnson, ‘A History of the Jews’, p.
242; Bell and Burnett, ‘ Jews, Judaism, and The Reformation in Sixteenth Century Germany’,
p. 436, 443)

1539 A.D. – Hesse, Germany – Jews Expelled (Bell and Burnett, ‘ Jews, Judaism, and The
Reformation in Sixteenth Century Germany’, p. 436)

1539 A.D. – Naples, Italy – Jews Expelled again (C. Roth, ‘The History of the Jews of Italy’, p.
286)

1540 A.D. – Milan, Italy – Jews Expelled by the occupying Spanish; exhiled to The Levant (C.
Roth, ‘The History of the Jews of Italy’, p. 187)

1540 A.D. – Naples, Italy – Jews Expelled (P.E. Grosser/E.G. Halperin, ‘Anti-Semitism: Causes
and Effects’)

1540 A.D. – Prague, Hungary – Jews Expelled

1541 A.D. – Otranto, Italy – Jews Expelled (C. Roth, ‘The History of the Jews of Italy’, p. 287)

1541 A.D. – Naples, Italy – Jews Expelled again (C. Roth, ‘The History of the Jews of Italy’, p.
180, 189, 286)

1541 A.D. – Tittingen, Germany – Jews Expelled for ritual murder (Bell and Burnett, ‘ Jews,
Judaism, and The Reformation in Sixteenth Century Germany’, p. 436)

1541-1542 A.D. – Bohemia, Germany – Jews Expelled by Emperor Ferdinand I for aiding
invading Turks (http://www.jewishhistory.org)

1542 A.D. – Prague, Hungary – Jews Expelled

1542 A.D. – Piotrkow, Poland – Jews Expelled (http://www.jewishhistory.org)

1542 A.D. – Hildesheim, Germany – Jews Expelled (Bell and Burnett, ‘ Jews, Judaism, and The
Reformation in Sixteenth Century Germany’, p. 433)

1543 A.D. – Muehlhausen, Germany – Jews Expelled (B. Booker, ‘The Lie: Exposing the
Satanic Plot Behind Anti-Semitism’)

1543-1544 A.D. – Goslar, Germany – Jews Expelled (Bell and Burnett, ‘ Jews, Judaism, and
The Reformation in Sixteenth Century Germany’, p. 434)

1544 A.D. – Wurzburg, Germany – Jews Expelled for ritual murder (Bell and Burnett, ‘ Jews,
Judaism, and The Reformation in Sixteenth Century Germany’, p. 436)

1546 A.D. – Braunschweig, Germany – Jews Expelled (Bell and Burnett, ‘ Jews, Judaism, and
The Reformation in Sixteenth Century Germany’, p. 433, 439-442)

1547 A.D. – Ancona, Italy – Jews Expelled/Self-deported after friar’s boycott of Jewish banks
(C. Roth, ‘The History of the Jews of Italy’, p. 182)

1547 A.D. – Poland – Jews Expelled/Killed for Ritual Murder (http://www.jewishhistory.org)

1547 A.D. – Treviso, Italy – Jews Expelled/Killed (B. Booker, ‘The Lie: Exposing the Satanic Plot
Behind Anti-Semitism’)

1549 A.D. – Goslar, Germany – Jews Expelled (Bell and Burnett, ‘ Jews, Judaism, and The
Reformation in Sixteenth Century Germany’, p. 434)

1550 A.D. – Henneberg, Germany – Jews Expelled (Bell and Burnett, ‘ Jews, Judaism, and The
Reformation in Sixteenth Century Germany’, p. 433)

1550 A.D. – Madrid, Spain – Jews Expelled by King (C. Roth, ‘The History of the Jews of Italy’,
p. 322)

1550 A.D. – Genoa, Italy – Jews Expelled b/c non-Jew medical faculty was “jealous” (C. Roth,
‘The History of the Jews of Italy’, p. 183, 309)

1550 A.D. – Venice, Italy – Marranno Jews Expelled (C. Roth, ‘The History of the Jews of Italy,
p. 187)

1551 A.D. – Bavaria, Germany – Jews Expelled (P.E. Grosser/E.G. Halperin, ‘Anti-Semitism:
Causes and Effects’)

1553 A.D. – Asti, Italy – Jews Expelled for Ritual Murder (C. Roth, ‘The History of the Jews of
Italy’, p. 183)

1554 A.D. – Ancona, Italy – Jews partially Expelled; burning of The Talmud ensues (R. Maryks,
‘The Jesuit Order as a Synagogue of Jews’, p. 93)

1555 A.D. – Pesaro, Italy – Jews Expelled (P.E. Grosser/E.G. Halperin, ‘Anti-Semitism: Causes
and Effects’)

1555 A.D. – Rome, Italy – Jews Expelled by Cardinal Farnese/The Pope
intervened/unsuccessful (C. Roth, ‘The History of the Jews of Italy’, p. 183)

1556 A.D. – Thuringia, Germany – Jews Expelled (Bell and Burnett, ‘ Jews, Judaism, and The
Reformation in Sixteenth Century Germany’, p. 430)

1556 A.D. – Benevento, Italy – Jews Expelled (C. Roth, ‘The History of the Jews of Italy’, p.
299)

1556 A.D. – Ancona, Italy – Marrano Jews Expelled (C. Roth, ‘The History of the Jews of Italy’,
p. 314)

1556 A.D. – Ancona, Italy – All Jews Expelled (C. Roth, ‘The History of the Jews of Italy’, p.
299, 301)

1556 A.D. – Rome, Italy – Maranno Jews Expelled/Burned at the stake (C. Roth, ‘The History
of the Jews of Italy’, p. 300)

1556 A.D. – Udine, Italy – Jews Expelled (C. Roth, ‘The History of the Jews of Italy’, p. 309)

1557 A.D. – Prague, Hungary – Jews Expelled for 3rd time by Emperor Ferdinand I
(www.yivoencyclopedia.org)

1557 A.D. – Bohemia, Germany- Jews Expelled for 3rd time by Emperor Ferdinand I
(www.yivoencyclopedia.org)

1557 A.D. – Cremona, Italy – Jews Expelled for printing of Talmud and Zohar (C. Roth, ‘The
History of the Jews of Italy’, p. 303)

1558 A.D. – Recanati, Italy – Jews Expelled (http://www.jewishhistory.org)

1558 A.D. – Urbino, Italy – Marrano Jews Expelled by the Duke (C. Roth, ‘The History of the
Jews of Italy’, p. 302)

1559 A.D. – Austria – Jews Expelled (P.E. Grosser/E.G. Halperin, ‘Anti-Semitism: Causes and
Effects’)

1559 A.D. – Bohemia, Germany – Jews Expelled for 4th time by Emperor Ferdinand I
(http://www.jewishhistory.org)

1559 A.D. – Civitanova, Italy – Jews Expelled for attempting to convert a Franciscan friar to
Judaism (C. Roth, ‘The History of the Jews of Italy’, p. 302)

1559 A.D. – Pavia, Italy – Jews Expelled after pogroms (C. Roth, ‘The History of the Jews of
Italy’, p. 304)

1560 A.D. – Conegliano, Italy – Jews Expelled/unsuccessful
(http://www.jewishvirtuallibrary.org)

1560 A.D. – Piedmont, Savoy, Italy – Jews Expelled by Duke Emanuele Filiberto, “Iron
Head”/cancelled shortly after intercession by a bribed Azariah de’Rossi, (C. Roth, ‘The
History of the Jews of Italy’, p. 312-313)

1560 A.D. – Monferrat, Italy – Jews Expelled (C. Roth, ‘The History of the Jews of Italy’, p.
313)

1560 A.D. – Casale, Italy – Jews Expelled (C. Roth, ‘The History of the Jews of Italy’, p. 313)

1561 A.D. – Prague, Hungary – Jews Expelled again (P.E. Grosser/E.G. Halperin, ‘AntiSemitism:
Causes and Effects’)

1561-1565 A.D. – Gorizia, Italy – Jews Expelled (C. Roth, ‘The History of the Jews of Italy’, p.
310)

1561-1565 A.D. – Friuli, Italy – Jews Expelled (C. Roth, ‘The History of the Jews of Italy’, p.
310)

1561-1565 A.D. – Piedmont, Savoy, Italy – Jews Expelled again/cancelled again because of
“20,000 florin” bribe (C. Roth, ‘The History of the Jews of Italy’, p. 313)

1562 A.D. – Acqui, Italy – Jews Expelled after pogrom (C. Roth, ‘The History of the Jews of
Italy’, p. 313)

1566 A.D. – Madrid, Spain – Jews Expelled/Cancelled by bribe (C. Roth, ‘The History of the
Jews of Italy’, p. 322)

1565 A.D. – Prague, Hungary – Jews Expelled again (Rafael Patai, ‘The Jews of Hungary’, p.
175)

1566 A.D. – Papal States, Italy – Jews Expelled out of main city/segregated in Ghetto (C. Roth,
‘The History of the Jews of Italy’, p. 309)

1566 A.D. – Alessandria, Italy – Jews Expelled out of city walls/segregated in Ghetto (C. Roth,
‘The History of the Jews of Italy’, p. 309)

1567 A.D. – Conegliano, Italy – Jews Expelled/unsuccessful
(http://www.jewishvirtuallibrary.org)

1567 A.D. – Wurzbburg, Germany – Jews Expelled (P.E. Grosser/E.G. Halperin, ‘Anti-Semitism:
Causes and Effects’)
1567-1568 A.D. – Genoa, Ital
y – Jews Expelled again from adjacent territories (C. Roth, ‘The
History of the Jews of Italy’, p. 183, 309)

1568 A.D. – Bologna, Italy – Jews Expelled for printing of The Talmud (C. Roth, ‘The History of
the Jews of Italy’, p. 306)

1568 A.D. – Bergheim, Germany – Jews Expelled after synagogue is plundered (Bell and
Burnett, ‘ Jews, Judaism, and The Reformation in Sixteenth Century Germany’, p. 433)

1569 A.D. – Benevento, Italy – Jews Expelled by Pope Pius V (C. Roth, ‘The History of the Jews
of Italy’, p. 307)

1569 A.D. – Este, Italy – Jews Expelled (C. Roth, ‘The History of the Jews of Italy’, p. 307)
1569 A.D. – Umbria, Italy – Jews Expelled (C. Roth, ‘The History of the Jews of Italy’, p. 307)

1569 A.D. – Campania, Italy – Jews Expelled (C. Roth, ‘The History of the Jews of Italy’, p.
307)

1569 A.D. – Camerino, Italy – Jews Expelled (C. Roth, ‘The History of the Jews of Italy’, p. 307)

1569 A.D. – Fano, Italy – Jews Expelled (C. Roth, ‘The History of the Jews of Italy’, p. 307)

1569 A.D. – Orvieto, Italy – Jews Expelled (C. Roth, ‘The History of the Jews of Italy’, p. 307)

1569 A.D. – Spoleto, Italy – Jews Expelled (C. Roth, ‘The History of the Jews of Italy’, p. 307)

1569 A.D. – Ravenna, Italy – Jews Expelled (C. Roth, ‘The History of the Jews of Italy’, p. 307)

1569 A.D. – Terracina, Italy – Jews Expelled (C. Roth, ‘The History of the Jews of Italy’, p. 307)

1569 A.D. – Perugia, Italy – Jews Expelled (C. Roth, ‘The History of the Jews of Italy’, p. 307)

1569 A.D. – Viterbo, Italy – Jews Expelled (C. Roth, ‘The History of the Jews of Italy’, p. 307)

1569 A.D. – Senigallia, Italy – Jews Expelled (C. Roth, ‘The History of the Jews of Italy’, p. 307)

1569 A.D. – Pesaro, Italy – Jews Expelled (C. Roth, ‘The History of the Jews of Italy’, p. 307)

1569 A.D. – Volterra, Italy – Jews Expelled (C. Roth, ‘The History of the Jews of Italy’, p. 310)

1570 A.D. – Urbino, Italy – Jews Expelled by Guidubaldo della Rovere/forced into ghetto
outside city walls (C. Roth, ‘The History of the Jews of Italy’, p. 309)

1570 A.D. – Parma, Italy – Jews Expelled/shortly summoned back (C. Roth, ‘The History of the
Jews of Italy’, p. 309)

1570 A.D. – Piacenza, Italy – Jews Expelled/shortly summoned back (C. Roth, ‘The History of
the Jews of Italy’, p. 309)

1570 A.D. – Florence, Italy – Jews of the Banking family Da Pisa Expelled for Usury (C. Roth,
‘The History of the Jews of Italy’, p. 310)

1570 A.D. – Florence, Italy – All Jews of the 21 “contados” Expelled by Cosimo I Medici (C.
Roth, ‘The History of the Jews of Italy’, p. 311)

1571 A.D. – Brandenburg, Austria – Jews Expelled (P.E. Grosser/E.G. Halperin, ‘Anti-Semitism:
Causes and Effects’)

1571 A.D. – Berlin, Germany – Jews Expelled (http://www.jewishvirtuallibrary.org)

1571 A.D. – Sienna, Italy – Jews Expelled (C. Roth, ‘The History of the Jews of Italy’, p. 311)

1571 A.D. – Venice, Italy – Jews Expelled for aiding the Turks at Lepanto/cancelled two years
later by a “lavish bribe” on the part of the Jews (C. Roth, ‘The History of the Jews of Italy’, p.
311)

1572 A.D. – Lucca, Italy – Jews Expelled/no explanation (C. Roth, ‘The History of the Jews of
Italy’, p. 309)

1573 A.D. – Breisgau and other towns in Austria – Jews Expelled (Bell and Burnett, ‘ Jews,
Judaism, and The Reformation in Sixteenth Century Germany’, p. 430)

1573 A.D. – Germany – Jews Expelled (Marvin Lowenthal, ‘The Jews of Germany: A Story of
Sixteen Centuries’, p. 202)

1575 A.D. – The Palatinate, Germany – Jews Expelled (Philip Broadhead/Chris Cook, ‘The
Routledge Companion to Early Modern Europe, 1453-1763’)

1575 A.D. – Casale, Italy – Jews Expelled for not wearing “Jewish Badge of Shame” (C. Roth,
‘The History of the Jews of Italy’, p. 313)

1576 A.D. – Gellnausen, Germany – Jews Expelled finally for what they did in 1516 (Bell and
Burnett, ‘ Jews, Judaism, and The Reformation in Sixteenth Century Germany’, p. 442)

1577 A.D. – Mantua, Italy – Jews Expelled for moneylending (C. Roth, ‘The History of the Jews
of Italy’, p. 313)

1581 A.D. – Diosces of Basel, Germany – Jews Expelled
(http://www.jewishvirtuallibrary.org/baden)

1581 A.D. – Ferrara, Italy – Jews Expelled by Duke Alfonso (C. Roth, ‘The History of the Jews
of Italy’, p. 314)

1582 A.D. – Pavia, Italy – Jews Expelled for Heresy (C. Roth, ‘The History of the Jews of Italy’,
p. 322)

1582 A.D. – The Netherlands – Jews Expelled (P.E. Grosser/E.G. Halperin, ‘Anti-Semitism:
Causes and Effects’)

1582 A.D. – Hungary – Jews Expelled (Rafael Patai, ‘The Jews of Hungary’, p. 399)

1583 A.D. – Trieste, Italy – Jews Expelled due to “atrocious crimes”, likely Ritual
Murder/cancelled (C. Roth, ‘The History of the Jews of Italy’, p. 310)

1583 A.D. – Campo di Fiori, Italy – Jews Expelled/Burned at the stake (C. Roth, ‘The History of
the Jews of Italy’, p. 314)

1585 A.D. – Venice, Italy – Jews Expelled/cancelled/confined to Ghetto (C. Roth, ‘The History
of the Jews of Italy’, p. 323)

1587 A.D. – Hanover, Germany – Jews Expelled after Protestant preachers preach against
Jews, Usury, and their toleration (Bell and Burnett, ‘ Jews, Judaism, and The Reformation in
Sixteenth Century Germany’, p. 433)

1590 A.D. – Lombardy, Italy – Jews Expelled by King Philip II of Spain (William Thomas Walsh,
‘Phillip II’, p. 137)

1590 A.D. – Milan, Italy – Jews Expelled (http://www.jewishvirtuallibrary.org/alessandria)

1590 A.D. – Mantua, Italy – “Foreign” Jews Expelled (C. Roth, ‘The History of the Jews of
Italy’, p. 325)

1590 A.D. – Petrokov, Poland – Jews Expelled for Ritual Murder (B. Booker, ‘The Lie: Exposing
the Satanic Plot Behind Anti-Semitism’, Ch. 4)

1590-1591 A.D. – Braunshweig/Wolfenbuttel, Germany – Jews Expelled (Bell and Burnett, ‘
Jews, Judaism, and The Reformation in Sixteenth Century Germany’, p. 428)

1591 A.D. – Hanau, Germany – Jews Expelled for what they did in 1516 (Bell and Burnett, ‘
Jews, Judaism, and The Reformation in Sixteenth Century Germany’, p. 442)

1591 A.D. – Pavia, Italy – Jews Expelled again by King Philip (C. Roth, ‘The History of the Jews
of Italy’, p. 322)

1591 A.D. – Milan, Italy – Jews Expelled by King Philip (C. Roth, ‘The History of the Jews of
Italy’, p. 322)

1591 A.D. – Cremona, Italy – Jews Expelled (C. Roth, ‘The History of the Jews of Italy’, p. 323)
1591 A.D. – Lodi, Italy – Jews Expelled (C. Roth, ‘The History of the Jews of Italy’, p. 323)
1591 A.D. – Alessandria, Italy – Jews Expelled (C. Roth, ‘The History of the Jews of Italy’, p.
323, 343)
1593 A.D. – Perugia, Italy – Jews Expelled by Pope Clement VIII
(http://www.jewishvirutallibrary.org/perugia)
1593 A.D. – Bologna, Italy – Jews Expelled by Pope Clement VIII
(http://www.jewishvirtuallibrary.org/bologna-jewish-history-tour)

1593 A.D. – Brandenburg, Austria – Jews Expelled (Henry Wickham Steed, ‘The Hapsburg
Monarchy’, 1914, p. 60)

1593 A.D. ñ The Papal States, Italy ñ Jews Expelled (C. Roth, ‘The History of the Jews of Italy’,
p. 300, 313)

1593 A.D. ñ Bavaria, Germany ñ Jews Expelled (James F. Harris, ‘The People Speak: AntiSemitism
and Emancipation’, p. 17)

1593 A.D. – Brunswick, England – Jews Expelled (P.E. Grosser/E.G. Halperin, ‘Anti-Semitism:
Causes and Effects’)

1595 A.D. – Hildersheim, Germany – Jews Expelled; reversed in 1601 (Bell and Burnett, ‘
Jews, Judaism, and The Reformation in Sixteenth Century Germany’, p. 431)

1597 A.D. – Cremona – Jews Expelled (P.E. Grosser/E.G. Halperin, ‘Anti-Semitism: Causes and
Effects’)

1597 A.D. – Pavia – Jews Expelled (P.E. Grosser/E.G. Halperin, ‘Anti-Semitism: Causes and
Effects’)

1597 A.D. – Lodi – Jews Expelled (P.E. Grosser/E.G. Halperin, ‘Anti-Semitism: Causes and
Effects’)

1597 A.D. – Milan, Italy – Jews Expelled (C. Roth, ‘The History of the Jews of Italy’, p. 182)

1598 A.D. – Hanover, Germany – Jews Expelled (Bell and Burnett, ‘ Jews, Judaism, and The
Reformation in Sixteenth Century Germany’, p. 434)

1599 A.D. – Genoa, Italy – Jews Expelled (C. Roth, ‘The History of the Jews of Italy’, p. 183)

1600 A.D. – Rome, Italy – Jews Expelled/Burned at the stake (C. Roth, ‘The History of the
Jews of Italy’, p. 288)

1600 A.D. – Mantua, Italy – Jews burned alive for “sorcery” (C. Roth, ‘The History of the Jews
of Italy’, p. 325)

1602 A.D. – Mirandola, Italy – Jews Expelled for failing to wear “Jewish Badge of Shame” (C.
Roth, ‘The History of the Jews of Italy’, p. 326, 341)

1603 A.D. – Verona, Italy – Jews accused of Ritual Murder (C. Roth, ‘The History of the Jews
of Italy’, p. 388)

1608 A.D. – Spain – crypto-Jews expelled from the Society of Jesus (Jesuits) by Jesuit
Superior-General Claudio Acquaviva (Robert Markys, ‘The Jesuit Order as a Synagogue of
Jews: Jesuits of Jewish Ancestry and Purity-of-Blood Laws in the early Society of Jesus’, p.
146)

1609 A.D. – London, England – Jews Expelled (http://www.jewishvirtuallibrary.org/london)

1611 A.D. – Casale, Italy – Jews accused of Ritual Murder (C. Roth, ‘The History of the Jews of
Italy’, p. 388)

1612 A.D. – Guine, Africa – Natives and Portuguese Christians attempt to expel Jews; denied
by King Baol of Lambaia after gifts/bribery (Kagen and Morgan, ‘Atlantic Diasporas: Jews,
Conversos, and Crypto-Jews in the Age of Mercantilism, 1500-1800’, p. 176, 283)

1612 A.D. – Guine, Africa – Natives and Portuguese Christians attempt (again) to expel Jews;
denied by the King of Sine Bur Sun after bribe (Kagen and Morgan, ‘Atlantic Diasporas: Jews,
Conversos, and Crypto-Jews in the Age of Mercantilism, 1500-1800’, p. 176, 283)

1612 A.D. – Casale, Italy – Jews Expelled/Confined to Ghetto outside city (C. Roth, ‘The
History of the Jews of Italy’, p. 314)

1612-1614 A.D. – Rovigo, Italy – Jews Expelled (unsuccessful)/Confined to Ghetto (C. Roth,
‘The History of the Jews of Italy’, p. 325 371)

1614 A.D. – Frankfort, Germany – Jews Expelled; allowed to resettle within a decade (P.E.
Grosser/E.G. Halperin, ‘Anti-Semitism: Causes and Effects’; Bell and Burnett, ‘ Jews, Judaism,
and The Reformation in Sixteenth Century Germany’, p. 33)

1614 A.D. – Baden, Germany – Jews Expelled (http://www.jewishvirtuallibrary.org/baden)

1615 A.D. – Worms, Germany – Jews Expelled; allowed to resettle within a decade (P.E.
Grosser/E.G. Halperin, ‘Anti-Semitism: Causes and Effects’; Bell and Burnett, ‘ Jews, Judaism,
and The Reformation in Sixteenth Century Germany’, p. 33)

1615 A.D. – France – Jews Expelled by King Louis XIII of France (William Chester Jordan, ‘The
French Monarchy and the Jews: From Philip Augustus to the Last Capetians’, p. 180)

1618 A.D. – German towns – Jews Expelled during 30 Years War
(http://www.jewishhistory.org)

1618 A.D. – Moravian towns – Jews Expelled during 30 Years War
(http://www.jewishhistory.org)

1619 A.D. – Kiev, Russia – Jews Expelled (http://www.yivoencyclopedia.org/article.aspx/Kiev)

1620 A.D. – Florence, Italy – Jewish silkweavers Expelled for illegality (C. Roth, ‘The History of
the Jews of Italy’, p. 372)

1622 A.D. – Udine, Italy – Jews Expelled (C. Roth, ‘The History of the Jews of Italy’, p. 309)

1623 A.D. – Piedmont, Italy – Jewish Goldsmiths/Merchants Expelled (C. Roth, ‘The History of
the Jews of Italy’, p. 376)

1624 A.D. – Ferrara, Italy – Jews Expelled/Self-Deport (C. Roth, ‘The History of the Jews of
Italy’, p. 321)

1626 1627 A.D. – Mantua, Italy – Jewish Merchants Expelled/Re-called quickly after antiJewish
riot (C. Roth, ‘The History of the Jews of Italy’, p. 338, 375)

1628 A.D. – Casale, Italy – Jews accused of Ritual Murder (again) (C. Roth, ‘The History of the
Jews of Italy’, p. 388)

1629 A.D. – Mantua, Italy – Jews Expelled for being loyal to the ousted ruler Charles de
Rethel (C. Roth, ‘The History of the Jews of Italy’, p. 339)

1637 A.D. – Conegliano, Italy – Jews Expelled/Confined to Ghetto (C. Roth, ‘The History of the
Jews of Italy’, p. 325)

1637 A.D. – Mirandola, Italy – Jewish synagogues destroyed after pogrom (C. Roth, ‘The
History of the Jews of Italy’, p. 383)

1638 A.D. – Modena, Italy – Jews Expelled/Confined to Ghetto (C. Roth, ‘The History of the
Jews of Italy’, p. 328, 340)

1639 A.D. – Massa, Italy – Jews Expelled/Self-Deport (C. Roth, ‘The History of the Jews of
Italy’, p. 321)

1639 A.D. – Bagnacavallo, Italy – Jews Expelled/Confined to Ghetto outside city (C. Roth, ‘The
History of the Jews of Italy’, p. 321)

1639 A.D. – Rome, Italy – Jewish insurrection in the Ghetto/Brutally suppressed (C. Roth, ‘The
History of the Jews of Italy’, p. 380)

1639 A.D. – Padua, Italy – Jewish Merchants/Traders partially expelled after riots for 6 days
(c. Roth, ‘The History of the Jews of Italy’, p. 389)

1639 A.D. – Turin, Italy – Jews Expelled for siding with enemy after city is sacked during civil
war (C. Roth, ‘The History of the Jews of Italy’, p. 389)

1639 A.D. – Pisa, Italy – Jews Murdered after pogroms at University (C. Roth, ‘The History of
the Jews of Italy’, p. 389)

1648 A.D. – Ferrara, Italy – Jews Expelled after assault on Ghetto (C. Roth, ‘The History of the
Jews of Italy’, p. 332)

1648 A.D. – Ukraine – Jews Expelled (P.E. Grosser/E.G. Halperin, ‘Anti-Semitism: Causes and
Effects’)

1648 A.D. – Poland – Jews Expelled (Bernard D. Weinryb, ‘The Jews of Poland: A Social and
Economic History of the Jewish Community in Poland from 1100 to 1800, p. 50)

1648 A.D. – Gorizia, Italy – Jews Expelled/Self-Deported (C. Roth, ‘The History of the Jews of
Italy’, p. 328)

1649 A.D. – Hamburg, Germany – Jews Expelled
(http://www.jewishvirtuallibrary.org/hamburg)

1654 A.D. ñ New Amsterdam, United States ñ Jews Expelled by Peter Stuyvesant

1654 A.D. – Little Russia (Beylorus) – Jews Expelled (P.E. Grosser/E.G. Halperin, ‘AntiSemitism:
Causes and Effects’)

1655 A.D. – Sandomierz, Poland – Jews Expelled/Killed (B. Booker, ‘The Lie: Exposing the
Satanic Plot Behind Anti-Semitism’)

1655 A.D. – Tamobrzeg, Poland – Jews Expelled/Killed (B. Booker, ‘The Lie: Exposing the
Satanic Plot Behind Anti-Semitism’)

1656 A.D. – Perisa – Jews Expelled by Sultan Shah Abbas II

1656 A.D. – Lithuania – Jews Expelled (P.E. Grosser/E.G. Halperin, ‘Anti-Semitism: Causes and
Effects’)

1660 A.D. – London, England – city petitions Charles II to expel Jews on restoration of
Stuarts/Jewish commerce hurting England/unsuccessful (Johnathon Israel, ‘ European Jewry
in the Age of Mercantilism, 1550-1750’, p. 160)

1665 A.D. – Jamaica – Jews Expelled (many moving to New York) (Kagan and Morgan,
‘Atlantic Diasporas: Jews, Conversos, and Crypto-Jews in the Age of Mercantilism, 1500-
1800’, p. 37)

1665 A.D. – Verona, Italy – Jews Killed after plague/pogrom (C. Roth, ‘The History of the Jews
of Italy’, p. 357)

1666 A.D. – Cayenne (French territory in the Caribbean) – Jews Expelled after French defeat
the Dutch (Kagen and Morgan, ‘Atlantic Diasporas: Jews, Conversos, and Crypto-Jews in the
Age of Mercantilism, 1500-1800’, p. 46)

1666 A.D. – Este, Italy – Jews Expelled/Confined to Ghetto for Heresy (Sabbatianism) (C.
Roth, ‘The History of the Jews of Italy’, p. 325)

1669 A.D. – Oran, North Africa – Jews Expelled for Heresy (Sabbatianism) (P.E. Grosser/E.G.
Halperin, ‘Anti-Semitism: Causes and Effects’)

1669-1671 A.D. – Reggio, Italy – Jews Expelled/Self-Deported to Palestine (C. Roth, ‘The
History of the Jews of Italy’, p. 328)

1670 A.D. – Vienna, Austria – Jews Expelled by Emperor Leopold I (Joseph A. Biesinger,
‘Germany: A Reference Guide from the Renaissance to the Present’, p. 216)

1671 A.D. – Fulda, Germany – Jews Expelled (Bell and Burnett, ‘ Jews, Judaism, and The
Reformation in Sixteenth Century Germany’, p. 432)

1678 A.D. – Florence, Italy – Jewish merchants/manufacturers Expelled (C. Roth, ‘The History
of the Jews of Italy’, p. 372)

1678 A.D. – Yemen – Jews Expelled by Sultan Mehmed IV for Heresy (Sabbatianism) (Necan
Alkan, ‘Dissent and Heterodoxy in the Late Ottoman Empire’, 2008)

1679 A.D. – Turin, Italy – Jews Expelled/Confined to Ghetto (C. Roth, ‘The History of the Jews
of Italy’, p. 328, 372)

1681 A.D. – Reggio, Italy – Jews Expelled to ghetto outside city (C. Roth, ‘The History of the
Jews of Italy’, p. 340)

1682 A.D. – Marseilles, France – Jews Expelled by Louis XIV for Jewish
commerce/treason/giving the Duth info on war planning (Johnathon Israel, ‘European Jewry
in the Age of Mercantilism, 1550-1750, p. 162)

1682 A.D. – Bordeaux, France – Jews Expelled by Louis XIV for Jewish
commerce/treason/giving the Duth info on war planning (Johnathon Israel, ‘European Jewry
in the Age of Mercantilism, 1550-1750, p. 163)

1683 A.D. – Martinique (French colony) – Jews Expelled by King Louis XIV for Jewish
commerce/supplying info to pirates/treason (Johnathon Israel, ‘European Jewry in the Age
of Mercantilism, 1550-1750’, p. 162)

1683 A.D. – Guadeloupe (French colony) – Jews Expelled by King Louis XIV for Jewish
commerce/supplying info to pirates/treason (Johnathon Israel, ‘European Jewry in the Age
of Mercantilism, 1550-1750’, p. 162)

1683 A.D. – Cayenne (French colony) – Jews Expelled by King Louis XIV for Jewish
commerce/supplying info to pirates/treason (Johnathon Israel, ‘European Jewry in the Age
of Mercantilism, 1550-1750’, p. 162)

1683 A.D. – Moravia – Jews Expelled by Hungarians for Heresy (Sabbatianism)
(http://www.jewishhistory.org)

1683 A.D. – Padua, Italy – Jewish merchants Expelled for illegal activity (C. Roth, ‘The History
of the Jews of Italy’, p. 372)

1684 A.D. – Buda, Hungary – Jews Expelled after helping Turks seige the city (C. Roth, ‘The
History of the Jews of Italy’, p. 388)

1684-1687 A.D. – Trieste, Italy – Jews Expelled/Forced into Ghettos (C. Roth, ‘The History of
the Jews of Italy’, p. 337)

1691-1700 A.D. – Ferrara, Italy – Jews Expelled/Forced into Baptism (C. Roth, ‘The History of
the Jews of Italy’, p. 381)

1693-1695 A.D. – Trieste, Italy – Jews paritally Expelled/Self-Deported (C. Roth, ‘The History
of the Jews of Italy’, p. 328)

1695 A.D. – Trieste, Italy – Jews Expelled/Accused of Ritual Murder (C. Roth, ‘The History of
the Jews of Italy’, p. 337)

1697 A.D. – Tuscany, Italy – Jews accused of Ritual Murder/Sorcery/Heresy (C. Roth, ‘The
History of the Jews of Italy’, p. 410)

1700 A.D. – Leghorn, Italy – Jews Expelled for spreading Heresy (Sabbatianism) (C. Roth, ‘The
History of the Jews of Italy’, p. 405)

1700 A.D. – Casale, Italy – Jews accused of Ritual Murder for 3rd time (C. Roth, ‘The History
of the Jews of Italy’, p. 388)

1700 A.D. – Monferrat, Italy – Jews Expelled/Confined to Ghetto outside city (C. Roth, ‘The
History of the Jews of Italy’, p. 328)

1700 A.D. – Finale, Italy – Jews confined to ghetto (C. Roth, ‘The History of the Jews of Italy’,
p. 340)

1702 A.D. – Sicily, Italy – Jews Expelled/Recalled in 1740 (C. Roth, ‘The History of the Jews of
Italy’, p. 351)

1702 A.D. – Modena, Italy – Jews partially Expelled for Heresy (Sabbatianism)/Self-Deported
to Palestine (C. Roth, ‘The History of the Jews of Italy’, p. 405)

1705 A.D. – Venice, Italy – Jews accused of Ritual Murder/partially expelled (C. Roth, ‘The
History of the Jews of Italy’, p. 388)

1705 A.D. – Viterbo, Italy – Jews accused of Ritual Murder (C. Roth, ‘The History of the Jews
of Italy’, p. 388)

1708 A.D. – Pieve di Cento, Italy – Jews Expelled/Transfered (C. Roth, ‘The History of the Jews
of Italy’, p. 333)

1710 A.D. – Geoningen, The Netherlands – Jews Expelled (B. Booker, ‘The Lie: Exposing the
Satanic Plot Behind Anti-Semitism’, Ch. 4)

1711 A.D. – Ancona, Italy – Jews accused of Ritual Murder/partially expelled (C. Roth, ‘The
History of the Jews of Italy’, p. 388)

1712 A.D. – Sandomir – Jews Expelled (P.E. Grosser/E.G. Halperin, ‘Anti-Semitism: Causes and
Effects’)

1712 A.D. – Poland – Jews Expelled by King Augustus II for Ritual Murder
(http://www.jewishhistory.org)

1717 A.D. – Gibraltar, British Territory – Jews Expelled (http://www.jewishhistory.org)

1721 A.D. – Senigallia, Italy – Jews accused of Ritual Murder (C. Roth, ‘The History of the Jews
of Italy’, p. 388)

1724 A.D. – Vercelli, Italy – Jews Expelled (C. Roth, ‘The History of the Jews of Italy’, p. 328)

1727 A.D. – Russia – Jews Expelled by Catherine I of Russia (P.E. Grosser/E.G. Halperin, ‘AntiSemitism:
Causes and Effects’)

1729 A.D. – Piedmont, Italy – Jews forced into countryside after new Constitution (C. Roth,
‘The History of the Jews of Italy’, p. 409)

1730 A.D. – Cuorgne, Italy – Jews self-deport/transfer to Turin (C. Roth, ‘The History of the
Jews of Italy’, p. 409)

1736 A.D. – Modena, Italy – Jews Expelled/Self-Deported (C. Roth, ‘The History of the Jews of
Italy’, p. 328)

1736 A.D. – Correggio, Italy – Jews Expelled/Confined to Ghetto (C. Roth, ‘The History of the
Jews of Italy’, p. 328)

1736 A.D. – Finale, Italy – Jews forced into Ghetto for Heresy (C. Roth, ‘The History of the
Jews of Italy’, p. 416)

1737 A.D. – St. Salvatore, Italy – Jews forced to move to Casale (C. Roth, ‘The History of the
Jews of Italy’, p. 409)

1737 A.D. – Genoa, Italy – Jews Expelled (but not for long) (C. Roth, ‘The History of the Jews
of Italy’, p. 416)

1738 A.D. – Wurtemburg, Germany – Jews Expelled (P.E. Grosser/E.G. Halperin, ‘AntiSemitism:
Causes and Effects’)

1739 A.D. – Monastero, Italy – Jews forced to move to Acqui (C. Roth, ‘The History of the
Jews of Italy’, p. 409)

1740 A.D. – Little Russia (Beylorus) – Jews Expelled (P.E. Grosser/E.G. Halperin, ‘AntiSemitism:
Causes and Effects’)

1742 A.D. – Russian towns – Jews Expelled by Empress Elizabeth of Russia
(http://www.jewishhistory.org)

1744 A.D. – Sardinia, Italy – Jews partially Expelled/forced into Ghettos (C. Roth, ‘The History
of the Jews of Italy’, p. 417)

1744 A.D. – Breslau, Germany – Jews Expelled by Frederik II The Great

1744 A.D. – Prague, Hungary – Jews Expelled (Rafael Patai, ‘The Jews of Hungary’, p. 319-321)

1744 A.D. – Bohemia – Jews Expelled

1744 A.D. ñ Hungary ñ Jews Expelled for the third time by Queen Maria Theresa (Rafael
Patai, ‘The Jews of Hungary’, p. 320-322)

1744 A.D. – Slovakia – Jews Expelled

1744 A.D. – Livonia – Jews Expelled (P.E. Grosser/E.G. Halperin, ‘Anti-Semitism: Causes and
Effects’)

1744 A.D. – Breslau, Germany – Jews Expelled by Fredrik II The Great

1745 A.D. – Verona, Italy – Jews partially expelled (C. Roth, ‘The History of the Jews of Italy’,
p. 413)

1745 A.D. – Moravia – Jews Expelled (P.E. Grosser/E.G. Halperin, ‘Anti-Semitism: Causes and
Effects’)

1745 A.D. – Prague, Bohemia – Jews Expelled by Archduchess of Austria Maria Theresa (Philip
Broadhead/Chris Cook, ‘The Routledge Companion to Early Modern Europe, 1453-1763’)

1746 A.D. – Budapest, Hungary – Jews Expelled for spreading Heresy (B. Booker, ‘The Lie:
Exposing the Satanic Plot Behind Anti-Semitism’)

1746 A.D. – Sicily, Italy – Jews Expelled by King Charles IV of Bourbon (C. Roth, ‘The History of
the Jews of Italy’, p. 351)

1746 A.D. – Naples, Italy – Jews Expelled by King Charles IV of Bourbon (C. Roth, ‘The History
of the Jews of Italy’, p. 351)

1750 A.D. – Rome, Italy – Jewish Spice Traders Expelled (C. Roth, ‘The History of the Jews of
Italy’, p. 375)

1751 A.D. – Leghorn, Italy – Jewish riots/pogroms after Jews found in possession of
“muskets” (C. Roth, ‘The History of the Jews of Italy’, p. 413)

1753 A.D. – Verona, Italy – Jews remaining Expelled/Rabbis killed (C. Roth, ‘The History of the
Jews of Italy’, p. 413)

1753 A.D. – Rome, Italy – Jews partially expelled for possession of “forbidden books” (The
Talmud) (C. Roth, ‘The History of the Jews of Italy’, p. 411)

1753 A.D. – Kovard, Lithuania – Jews Expelled (P.E. Grosser/E.G. Halperin, ‘Anti-Semitism:
Causes and Effects’)

1754 A.D. – Mantua, Italy – Jewish pogroms/riots (C. Roth, ‘The History of the Jews of Italy’,
p. 413)

1754 A.D. – Ferrara, Italy – Jewish pogroms/riots (C. Roth, ‘The History of the Jews of Italy’, p.
413)

1754 A.D. – Alessandria, Italy – Jewish pogroms/riots (C. Roth, ‘The History of the Jews of
Italy’, p. 413)

1758 A.D. – Parma, Italy – Jews Expelled by Bourbon Duke (C. Roth, ‘The History of the Jews
of Italy’, p. 417)

1758 A.D. – Busseto, Italy – Jews Expelled by Bourbon Duke (C. Roth, ‘The History of the Jews
of Italy’, p. 417)

1761 A.D. – Lubeck, Germany – Jews Expelled (http://www.jewishhistory.org)

1761 A.D. – Bordeaux, France – Jews Expelled (P.E. Grosser/E.G. Halperin, ‘Anti-Semitism:
Causes and Effects’)

1761 A.D. – Kaunas, Lithuania – Jews Expelled (http://www.jewishvirtuallibrary.org/kaunas)

1763 A.D. – Bohemia – Foreign-born Jews Expelled
(http://www.jewishvirtuallibrary.org/sunderland)

1766 A.D. – Rome, Italy – Roman Rabbis Imprisoned/Cemetary, Syangogue destroyed (C.
Roth, ‘The History of the Jews of Italy’, p. 411)

1767 A.D. – Modena, Italy – Jewish loan-bankers Expelled (C. Roth, ‘The History of the Jews
of Italy’, p. 416)

1770 A.D. – Correggio, Italy – Jews Expelled (unsuccessful) (C. Roth, ‘The History of the Jews
of Italy’, p. 416)

1772 A.D. – Poland – Jews Expelled/Deported to the Pale of Settlement (P.E. Grosser/E.G.
Halperin, ‘Anti-Semitism: Causes and Effects’)

1772 A.D. – Russia – Jews Expelled/Deported to the Pale of Settlement (P.E. Grosser/E.G.
Halperin, ‘Anti-Semitism: Causes and Effects’)

1775 A.D. – Warsaw, Poland – Jews Expelled (http://www.jewishhistory.org)

1775 A.D. – Alsace, France – Jews Expelled (P.E. Grosser/E.G. Halperin, ‘Anti-Semitism:
Causes and Effects’)

1777 A.D. – Venice, Italy – Jewish merchants/manufacturers Expelled for
criminality/racketerring (C. Roth, ‘The History of the Jews of Italy’, p. 415, 497)

1778 A.D. – Friuli, Italy – Jews Expelled (C. Roth, ‘The History of the Jews of Italy’, p. 423)

1779 A.D. – Correggio, Italy – Jews Expelled/Self-Deported (C. Roth, ‘The History of the Jews
of Italy’, p. 328)

1780 A.D. – Padua, Italy – Jewish silk-weavers Expelled for criminality/organized crime (C.
Roth, ‘The History of the Jews of Italy’, p. 416)

1781 A.D. – Montagnana, Italy – Jews Expelled for not staying in Ghetto (C. Roth, ‘The History
of the Jews of Italy’, p. 416)

1782 A.D. – Conselve, Italy – Jews Expelled for not staying in Ghetto (C. Roth, ‘The History of
the Jews of Italy’, p. 416)

1782 A.D. – Cittadella, Italy – Jews Expelled for not staying in Ghetto (C. Roth, ‘The History of
the Jews of Italy’, p. 416)

1783 A.D. – Ancona, Italy – 60 Jews arrested for kidnapping ring/partially Expelled (C. Roth,
‘The History of the Jews of Italy’, p. 418)

1783 A.D. – Spilimbergo, Italy – Jews Expelled for not staying in Ghetto (C. Roth, ‘The History
of the Jews of Italy’, p. 416)

1783 A.D. – Friuli, Italy – Jews Expelled for not staying in Ghetto (C. Roth, ‘The History of the
Jews of Italy’, p. 416)

1783 A.D. – Morocco – Jews partially Expelled by Sultan Mohammed Ben Abdellah al-Khatib
(http://www.jewishhistory.org)

1784 A.D. – Morocco – Jews Expelled again (http://www.jewishhistory.org)

1785 A.D. – Libya – Jews Expelled/Killed by Ali Burzi Pasha
(http://www.jewishvirutallibrary.org)

1786 A.D. – Morocco – Jews Expelled for 3rd time (http://www.jewishhistory.org)

1786 A.D. – Jedda, Arabia – Jews Expelled by Sultan Abdulhamid I
(http://www.jewishhistory.org)

1789 A.D. – Alsace, France – Jews Expelled again (Beatrice Philippe, ‘La Revolution et
l’Empire’, 1979)

1790 A.D. – Leghorn, Italy – Jews partially Expelled after pogrom (known as the “Insurrection
of Santa Giulia”) (C. Roth, ‘The History of the Jews of Italy’, p. 426)

1790 A.D. – Florence, Italy – Jews Killed after pogrom/riot in reaction to the “Insurrection of
Santa Giulia”) (C. Roth, ‘The History of the Jews of Italy’, p. 426)

1790 A.D. – Warsaw, Poland – Jews Expelled again (http://www.jewishhistory.org)

1791 A.D. – Saint-Domingue, Hispaniola – Jews Expelled

1791 A.D. – Polish towns – Jews Expelled by Catherine II of Russia
(http://www.haaretz.com/jewish/this-day-in-jewish-history/.premium-1.564905)

1791 A.D. – Russian towns – Jews Expelled by Catherine II of Russia
(http://www.haaretz.com/jewish/this-day-in-jewish-history/.premium-1.564905)

1793 A.D. – Ancona, Italy – Jewish Ghetto burned after conspiracy plot by Jewish Merchants
is discovered (C. Roth, ‘The History of the Jews of Italy’, p. 431)

1793 A.D. – Rome, Italy – Jews assaulted for sympathy with invading Revolutionary French
forces/Assassination (C. Roth, ‘The History of the Jews of Italy’, p. 426)

1796 A.D. – Piedmont, Italy – Jews assaulted/partially expelled after their ghetto is sacked by
“reactionaries” (C. Roth, ‘The History of the Jews of Italy’, p. 428)

1797 A.D. – Pesaro, Italy – Jews killed for engaging in plot to supply invading French with
arms (C. Roth, ‘The History of the Jews of Italy’, p. 431)

1797 A.D. – Lugo, Italy – Jews killed when city is sacked (C. Roth, ‘The History of the Jews of
Italy’, p. 430)

1797 A.D. – Padua, Italy – Jews Killed/Imprisoned for “Revolutionary sympathies” (C. Roth,
‘The History of the Jews of Italy’, p. 432)

1797 A.D. – Kaunas, Lithuania – Jews Expelled/unsuccessful

1798 A.D. – Rome, Italy – “Viva Maria” riots/Jews Killed (C. Roth, ‘The History of the Jews of
Italy’, p. 432, 434)

1798 A.D. – Pesaro, Italy – Jews Killed/Ransomed after 2 synagogues are sacked by Italians
(C. Roth, ‘The History of the Jews of Italy’, p. 438)

1798 A.D. – Venice, Italy – Jews killed during Napoleon’s absence/campaign in Egypt (C. Roth,
‘The History of the Jews of Italy’, p. 438)

1798 A.D. – Lugo, Italy – Jews killed during Napoleon’s absence/campaign in Egypt (C. Roth,
‘The History of the Jews of Italy’, p. 438)

1798 A.D. – Cento, Italy – Jews killed during Napoleon’s absence/campaign in Egypt (C. Roth,
‘The History of the Jews of Italy’, p. 438)

1798 A.D. – Reggio, Italy – Jews killed during Napoleon’s absence/campaign in Egypt (C. Roth,
‘The History of the Jews of Italy’, p. 438)

1798 A.D. – Modena, Italy – Jews killed during Napoleon’s absence/campaign in Egypt (C.
Roth, ‘The History of the Jews of Italy’, p. 438)

1798 A.D. – Campformio, Italy – Jews killed during Napoleon’s absence/campaign in Egypt (C.
Roth, ‘The History of the Jews of Italy’, p. 438)

1798 A.D. – Padua, Italy – Jews killed during Napoleon’s absence/campaign in Egypt (C. Roth,
‘The History of the Jews of Italy’, p. 438)

1798 A.D. – Verona, Italy – Jews killed during Napoleon’s absence/campaign in Egypt (C.
Roth, ‘The History of the Jews of Italy’, p. 438)

1798 A.D. – Piedmont, Italy – Jews killed during Napoleon’s absence/campaign in Egypt (C.
Roth, ‘The History of the Jews of Italy’, p. 438)

1798 A.D. – Chieri, Italy – Jews killed during Napoleon’s absence/campaign in Egypt (C. Roth,
‘The History of the Jews of Italy’, p. 438)

1798 A.D. – Alessandria, Italy – Jews killed during Napoleon’s absence/campaign in Egypt (C.
Roth, ‘The History of the Jews of Italy’, p. 438)

1798 A.D. – Acqui, Italy – Jews killed during Napoleon’s absence/campaign in Egypt (C. Roth,
‘The History of the Jews of Italy’, p. 438)

1798 A.D. – Fossano, Italy – Jews killed during Napoleon’s absence/campaign in Egypt (C.
Roth, ‘The History of the Jews of Italy’, p. 438)

1798 A.D. – Senigallia, Italy – Jews killed during Napoleon’s absence/campaign in Egypt (C.
Roth, ‘The History of the Jews of Italy’, p. 439)

1799 A.D. – Malta, Italy – Jews Killed/Captured/Held for Ransom after pogrom (C. Roth, ‘The
History of the Jews of Italy’, p. 350)

1799 A.D. – Urbino, Italy – Jews Killed/partially Expelled after city is recaptured from French
(C. Roth, ‘The History of the Jews of Italy’, p. 434)

1799 A.D. – Senigallia, Italy – Jews Killed/Expelled after city is sacked after French withdrawal
(C. Roth, ‘The History of the Jews of Italy’, p. 435)

1799 A.D. – Ancona, Italy – Jews Killed/Expelled/Accused of “summoning the foreigner
(French)” (C. Roth, ‘The History of the Jews of Italy’, p. 435)

1799 A.D. – Ferrara, Italy – Jews killed/Ghetto Sacked after French troops retire (C. Roth, ‘The
History of the Jews of Italy’, p. 437)

1799 A.D. – Bologna, Italy – Jews Expelled on charges of disloyalty/subversive activity (C.
Roth, ‘The History of the Jews of Italy’, p. 439)

1799 A.D. – Milan, Italy – Jews Expelled on charges of disloyalty/subversive activity (C. Roth,
‘The History of the Jews of Italy’, p. 439)

1799 A.D. – Modena, Italy – Jews Expelled on charges of disloyalty/subversive activity (C.
Roth, ‘The History of the Jews of Italy’, p. 439)

1799 A.D. – Mantua, Italy – Jews Expelled on charges of disloyalty/subversive activity (C.
Roth, ‘The History of the Jews of Italy’, p. 439)

1799 A.D. – Elbe, Italy – Jews Expelled/Imprsoned for attacking the Catholic religion as well
as priests (C. Roth, ‘The History of the Jews of Italy’, p. 439)

1800 A.D. – Arezzo, Italy – Jews killed/Expelled along with French soldiers (C. Roth, ‘The
History of the Jews of Italy’, p. 436)

1801 A.D. – Florence, Italy – Jews Expelled/unsuccessful (Jewish bribe to Archbishop Antonia
Martini) (C. Roth, ‘The History of the Jews of Italy’, p. 436)

1801 A.D. – Sienna, Italy – Jews Expelled/Self-Deported (C. Roth, ‘The History of the Jews of
Italy’, p. 437)

1801 A.D. – Monte San Savino – Jews Expelled/Killed in “Viva Maria” riots (C. Roth, ‘The
History of the Jews of Italy’, p. 437)

1801 A.D. – Ivrea, Italy – Jews attacked/self-emigrate (C. Roth, ‘The History of the Jews of
Italy’, p. 442)

1802 A.D. – Tuscany, Italy – Jews Killed/paritally expelled by Austrians for sympathy with
French (C. Roth, ‘The History of the Jews of Italy’, p. 437)

1803 A.D. – Asti, Italy – Jews Expelled out of Ghetto (C. Roth, ‘The History of the Jews of
Italy’, p. 442)

1804 A.D. – Villages in Russia – Jews Expelled (Aleksander Solzhenitsyn, ‘200 Years Together’)

1806 A.D. – Lucca, Italy – anti-Jewish “manifestations” and commercial boycott of Jewcontrolled
industries/banks (C. Roth, ‘The History of the Jews of Italy’, p. 442)

1808 A.D. – Villages & Countrysides, Russia – Jews Expelled (Aleksander Solzhenitsyn, ‘200
Years Together’)

1809 A.D. – Sermide, Italy – Jews killed in an agrarian revolt (C. Roth, ‘The History of the Jews
of Italy’, p. 442)

1809 A.D. – Ferrara, Italy – Jews killed in an agrarian revolt (C. Roth, ‘The History of the Jews
of Italy’, p. 442)

1809 A.D. – Rovigo, Italy – Jews killed in an agrarian revolt (C. Roth, ‘The History of the Jews
of Italy’, p. 442)

1811 A.D. – Alsace, France – Jewish merchants expelled (C. Roth, ‘The History of the Jews of
Italy’, p. 442)

1814 A.D. – Elba, Italy – Napoleon partially expels Jews/limits Jewish immigration (C. Roth,
‘The History of the Jews of Italy’, p. 442)

1814 A.D. – Piedmont, Italy – Jews once more confined to Ghettos (C. Roth, ‘The History of
the Jews of Italy’, p. 448)

1814 A.D. – Nice, Italy – Jewish students expelled from all educational institutions (C. Roth,
‘The History of the Jews of Italy’, p. 448)

1815 A.D. – Lubeck, Germany – Jews Expelled (Joseph A. Biesinger, ‘Germany: A Reference
Guide from the Renaissance to the Present’, p. 216)

1815 A.D. – Bremen, Germany – Jews Expelled (Joseph A. Biesinger, ‘Germany: A Reference
Guide from the Renaissance to the Present’, p. 216)

1815 A.D. – Franconia, Germany – Jews Expelled (H.I. Bach, ‘The German Jew: A Synthesis of
Judaism and Western Civilization, 1730-1930’, p. 108)

1815 A.D. – Swabia, Germany – Jews Expelled (H.I. Bach, ‘The German Jew: A Synthesis of
Judaism and Western Civilization, 1730-1930’, p. 109)

1815 A.D. – Bavaria, Germany – Jews Expelled (H.I. Bach, ‘The German Jew: A Synthesis of
Judaism and Western Civilization, 1730-1930’, p. 109)

1820 A.D. – Bremes, France – Jews Expelled (P.E. Grosser/E.G. Halperin, ‘Anti-Semitism:
Causes and Effects’)

1820 A.D. – The Corso, Italy – Jewish merchants expelled (C. Roth, ‘The History of the Jews of
Italy’, p. 450)

1820 A.D. – Rome, Italy – Jews ordered back into Ghettos (C. Roth, ‘The History of the Jews of
Italy’, p. 450)

1822 A.D. – Rubiera, Italy – Jews Expelled by Duke of Medina for subversive activity (The
Carbonari) (C. Roth, ‘The History of the Jews of Italy’, p. 455)

1822 A.D. – Russian villages – Jews Expelled (B. Booker, ‘The Lie: Exposing the Satanic Plot
Behind Anti-Semitism’, Ch. 4)

1824 A.D. – Mantua, Italy – Jews accused of Ritual Murder and pogromed (C. Roth, ‘The
History of the Jews of Italy’, p. 453)

1825 A.D. – Mohilev, Poland – Jews Expelled by Emperor Alexander I
(http://www.jewishhistory.org)

1825 A.D. – Vitebsk, Poland – Jews Expelled by Emperor Alexander I
(http://www.jewishhistory.org)

1828 A.D. – Slerno, Italy – Jews killed for conspiring with The Carbonari (C. Roth, ‘The History
of the Jews of Italy’, p. 455)

1829 A.D. – Rome, Italy – Jews Killed/partially expelled after death of Pope Leo XIII (C. Roth,
‘The History of the Jews of Italy’, p. 453)

1829 A.D. – Hamah, Syria – Jews Expelled for Ritual Murder of Muslim girl (Sir Richard Francis
Burton, ‘The Jew, The Gypsy, and El Islam’, 1898)

1829 A.D. – Kiev, Russia – Jews Expelled (B. Booker, ‘The Lie: Exposing the Satanic Plot Behind
Anti-Semitism’, Ch. 4)

1829 A.D. – Nikolayev, Russia – Jews Expelled (B. Booker, ‘The Lie: Exposing the Satanic Plot
Behind Anti-Semitism’, Ch. 4)

1830-1831 A.D. – Poland – Jews Expelled by General Ghlopicki
(http://www.jewishhistory.org)

1831 A.D. – Leghorn, Italy – Jews partially expelled for revolutionary sympathies with
Mazzini’s ‘Young Italy’ (C. Roth, ‘The History of the Jews of Italy’, p. 457)

1831 A.D. – Moldova – Jews who could not prove their usefullness expelled
(http://www.jewishhistory.org)

1831 A.D. – Wallchia, Poland – Jews Expelled (http://www.jewishhistory.org)

1833 A.D. – Leghorn, Italy – Jews partially expelled for financing/aiding Mazzini’s ‘Young Italy’
(C. Roth, ‘The History of the Jews of Italy’, p. 457)

1836 A.D. – Bologna, Italy – Jews Expelled for Jewing the economy (C. Roth, ‘The History of
the Jews of Italy’, p. 452, 491)

1840 A.D. – Piedmont, Italy – Jewish rabbis expelled for revolutionary sympathies (C. Roth,
‘The History of the Jews of Italy’, p. 454)

1842 A.D. – Mantua, Italy – Jews pogromed/accused of Ritual Murder (C. Roth, ‘The History
of the Jews of Italy’, p. 454)

1842 A.D. – Milan, Italy – Jews partially expelled for subversive activity (‘Young Italy’) (C.
Roth, ‘The History of the Jews of Italy’, p. 459)

1843 A.D. – Russian Border – Jews Expelled (P.E. Grosser/E.G. Halperin, ‘Anti-Semitism:
Causes and Effects’)

1843 A.D. – Austria – Jews Expelled (P.E. Grosser/E.G. Halperin, ‘Anti-Semitism: Causes and
Effects’)

1843 A.D. – Prussia – Jews Expelled (P.E. Grosser/E.G. Halperin, ‘Anti-Semitism: Causes and
Effects’)

1844 A.D. – Genoa, Italy – Jews Bankers Expelled after violence against communisty (C. Roth,
‘The History of the Jews of Italy’, p. 453)

1848 A.D. – Paris, France – Jews partially expelled for aiding/financing revolution (Priscilla
Robertson, ‘Revolutions of 1848: A Social History’, p. 72)

1848 A.D. – Milan, Italy – Jews partially expelled for aiding/financing revolution (Priscilla
Robertson, ‘Revolutions of 1848: A Social History’, p. 350)

1848 A.D. – Acqui, Italy – Jews partially expelled for aiding/financing revolution (C. Roth, ‘The
History of the Jews of Italy’, p. 466)

1848 A.D. – Venice, Italy – Jews partially expelled for aiding/financing revolution (C. Roth,
‘The History of the Jews of Italy’, p. 493)

1848 A.D. – Berlin, Germany – Jews partially expelled for aiding/financing revolution (Priscilla
Robertson, ‘Revolutions of 1848: A Social History’, p. 121)

1848 A.D. – Austria – Jews partially expelled by Hapsburgs for aiding/financing revolution
(Priscilla Robertson, ‘Revolutions of 1848: A Social History’, p. 237)

1850 A.D. – Romania – Jews Expelled by Interior Minister Ion Bratianu
(http://www.jewishhistory.org)

1851 A.D. – Venice, Italy – Jews partially expelled/self-deported (C. Roth, ‘The History of the
Jews of Italy’, p. 468)

1851 A.D. – Tuscany, Italy – Jews partially expelled (C. Roth, ‘The History of the Jews of Italy’,
p. 468)

1851 A.D. – Bologna, Italy – Jews imprisoned/partially expelled (C. Roth, ‘The History of the
Jews of Italy’, p. 468)

1851 A.D. – Ferrara, Italy – Jews Merchants Expelled for “secret society” participation (C.
Roth, ‘The History of the Jews of Italy’, p. 468)

1855 A.D. – Badia, Rovigo, Italy – Jews accused of Ritual Murder and pogromed (C. Roth, ‘The
History of the Jews of Italy’, p. 453)

1855 A.D. – Coro, Venezuela – Jews Expelled (http://wwwjewishvirtuallibrary.org/theexpelled-jews-of-coro-venezuela)

1858 A.D. – Rome, Italy – Jews accused of Ritual Murder at Passover (C. Roth, ‘The History of
the Jews of Italy’, p. 471)

1858 A.D. – Sardinia, Italy – Jews pogromed/expelled (unsuccessful due to bribery to The
Pope) (C. Roth, ‘The History of the Jews of Italy’, p. 471)

1862 A.D. – Areas in the United States under General Grant’s jurisdiction – Jews Expelled
(http://www.jewishhistory.org)

1862 A.D. – Velletri, Italy – Jewish Merchants Expelled (C. Roth, ‘The History of the Jews of
Italy’, p. 471)

1864 A.D. – Izmir, Ottoman Empire – Jews accused of Ritual Murder (Tracy K Harris, Death of
a Language, p. 43)

1864 A.D. – Genoa, Italy – Jews pogromed/self-deported (C. Roth, ‘The History of the Jews of
Italy’, p. 491)

1866 A.D. – Constantinople – Jews accused of Ritual Murder (Tracy K Harris, Death of a
Language, p. 43)

1866 A.D. – Galtaz, Romania – Jews Expelled
(http://kehilalinks.jewishgen.org/galati/Galatz_history.htm)

1867 A.D. – Romanian villages – Jews Expelled (B. Booker, ‘The Lie: Exposing the Satanic Plot
Behind Anti-Semitism’, Ch. 4)

1868 A.D. – Constantinople – Jews accused of Ritual Murder/partially expelled (Tracy K
Harris, Death of a Language, p. 43)

1872 A.D. – Izmir, Ottoman Empire – Jews accused of Ritual Murder (Tracy K Harris, Death of
a Language, p. 43)

1874 A.D. – Constantinople – Jews accused of Ritual Murder (Tracy K Harris, Death of a
Language, p. 43)

1875 A.D. – Izmir, Ottoman Empire – Jews accused of Ritual Murder (Tracy K Harris, Death of
a Language, p. 43)

1881-1884 A.D. – Russia – Jews Expelled (Alex Bein, ‘The Jewish Question: Biography of a
World Problem’, p. 265)

1891 A.D. – Moscow, Russia – Jews Expelled by Governor Grand Duke Sergei
(http://www.jewishhistory.org)

1910 A.D. – Kiev, Russia – Jews Expelled (http://www.jewishhistory.org)

1911 A.D. – Tuscany, Italy – Jews partially expelled for aiding Muslims during Italo-Turkish
War (C. Roth, ‘The History of the Jews of Italy’, p. 479)

1915 A.D. – Kovno, Russia – Jews Expelled by Commander Niolai A. (Petr L. Bark,
‘Vospominania’, 1966, p. 93)

1915 A.D. – Kurland, Russia – Jews Expelled by Commander Niolai A. (Petr L. Bark,
‘Vospominania’, 1966, p. 93)

1919 A.D. – Bavaria, Germany – Foreign-born Jews Expelled (P.E. Grosser/E.G. Halperin, ‘AntiSemitism:
Causes and Effects’)

1921 A.D. – Austria – Jews Expelled (http://www.jewishhistory.org)

1921 A.D. – Mongolia – Jews Expelled/Deported
(https://en.wikipedia.org/wiki/History_of_the_Jews_in_Central_Asia)

1925 A.D. – Milan, Italy – Jews partially expelled/imprisoned in an “anti-Fascist” rising (C.
Roth, ‘The History of the Jews of Italy’, p. 510)

1933-1934 A.D. – Towns in Afghanistan – Jews Expelled (http://www.jewishhistory.org)

1934 A.D. – Piedmont, Italy – Jews arrested/expelled for “subversive activities” (C. Roth, ‘The
History of the Jews of Italy’, p. 516)

1935 A.D. – Libya (possession of Italy) – Jews stripped of citizenship/ ordered to leave within
6 months (C. Roth, ‘The History of the Jews of Italy’, p. 529)

1935 A.D. – Aegean Islands (possession of Italy) – Jews stripped of citizenship/ordered to
leave within 6 months (C. Roth, ‘The History of the Jews of Italy’, p. 529)

1936 A.D. – Palestine – Jews killed in riots (C. Roth, ‘The History of the Jews of Italy’, p. 518)

1937 A.D. – Milan, Italy – Mussolini issues decree prohibiting Jewish immigration/ordering
Jews to evacuate within 6 months (C. Roth, ‘The History of the Jews of Italy’, p. 527)

1937 A.D. – Florence/Triest, Italy – ‘Institute for the Study of the Jewish Problem’ is
established (C. Roth, ‘The History of the Jews of Italy’, p. 532)

1937 A.D. – Rome, Italy – Jews partially expelled/self-deported for “subversive activity” (C.
Roth, ‘The History of the Jews of Italy’, p. 532)

1937 A.D. – Milan, Italy – Jews partially expelled after riots (C. Roth, ‘The History of the Jews
of Italy’, p. 532)

1937 A.D. – Florence, Italy – Jews partially expelled after riots (C. Roth, ‘The History of the
Jews of Italy’, p. 532)

1938 A.D. – Ecuador – Jews Expelled (http://trove.hla.gov.au/newspaper/article/11142190)

1938-1945 A.D. – Germany – Jews Expelled

1939 A.D. – Albania – Jews Expelled (C. Roth, ‘The History of the Jews of Italy’, p. 535)

1939 A.D. – Ecuador – Jews Expelled

1939 A.D. – Poland – Jews Expelled

1939 A.D. – Hungary – Jews Expelled

1940 A.D. – France – Jews Expelled

1940 A.D. – Rome, Italy – Jews partially expelled after pogrom (C. Roth, ‘The History of the
Jews of Italy’, p. 536)

1940 A.D. – Trieste, Italy – Jews partially expelled after pogrom (C. Roth, ‘The History of the
Jews of Italy’, p. 536)

1940 A.D. – Sicily, Italy – Jews Expelled (C. Roth, ‘The History of the Jews of Italy’, p. 537)

1940 A.D. – Sardinia, Italy – Jews Expelled (C. Roth, ‘The History of the Jews of Italy’, p. 537)

1940 A.D. – Milan, Italy – Jewish bankers expelled for British support/pogroms (C. Roth, ‘The
History of the Jews of Italy’, p. 538)

1940 A.D. – Genoa, Italy – Jewish bankers expelled for British support/pogroms (C. Roth, ‘The
History of the Jews of Italy’, p. 538)

1940 A.D. – Fiume, Italy – Jews arrested/expelled for spreading anti-Fascist propaganda (C.
Roth, ‘The History of the Jews of Italy’, p. 538)

1941 A.D. – Africa (Italian possessions) – Jews arrested and deported after riots against them
(C. Roth, ‘The History of the Jews of Italy’, p. 538)

1941 A.D. – Austria – Jews Expelled

1941 A.D. – Checkloslavia – Jews Expelled

1942-1943 A.D. – Tripoli, Africa – Jews Expelled (C. Roth, ‘The History of the Jews of Italy’, p.
539)

1943 A.D. – The Balkans – Jews Expelled/arrested/self-deported (C. Roth, ‘The History of the
Jews of Italy’, p. 540)

1943 A.D. – Alessandria, Italy – Jews Expelled by Minister of the Interior Buffarini Guidi
(http://www.jewishviturallibrary.org/alessandria)

1943 A.D. – Ferrara, Italy – Jews attacked/imprisoned/partially expelled for assassination of
Fascist leader (C. Roth, ‘The History of the Jews of Italy’, p. 543, 545)

1943 A.D. – Rome, Italy – Jews pogromed/100 partially expelled (C. Roth, ‘The History of the
Jews of Italy’, p. 543)

1943 A.D. – Verona, Italy – Jews stripped of citizenship (C. Roth, ‘The History of the Jews of
Italy’, p. 544)

1944 A.D. – Rome, Italy – Jews pogromed in retaliation for ambush of German troops (C.
Roth, ‘The History of the Jews of Italy’, p. 545)

1944 A.D. – Florence, Italy – Jews pogromed/sent to concentration camps (C. Roth, ‘The
History of the Jews of Italy’, p. 545)

1944 A.D. – Pisa, Italy – Jews pogromed/sent to concentration camps (C. Roth, ‘The History of
the Jews of Italy’, p. 545)

1944 A.D. – Alessandria, Italy – Jewish homes/synagogue destroyed (C. Roth, ‘The History of
the Jews of Italy’, p. 548)

1944 A.D. – Fiume, Italy – Jewish homes/synagogue destroyed (C. Roth, ‘The History of the
Jews of Italy’, p. 548)

1944 A.D. – Turin, Italy – Jewish homes/synagogue destroyed (C. Roth, ‘The History of the
Jews of Italy’, p. 548)

1944 A.D. – Casale, Italy – Jewish homes/synagogue destroyed (C. Roth, ‘The History of the
Jews of Italy’, p. 549)

1947 A.D. ñ Yemen ñ Jews Expelled/Killed

1948 A.D. ñ Iraq ñ Jews Expelled by Prime Minister Nuri as-Said (Orit Bashkin, ‘New
Babylonians: A History of Jews in Modern Iraq’, 2012, p. 277)

1948 A.D. ñ Bombay, India ñ Jews Expelled
(https://en.wikipedia.org/wiki/Jewish_exudus_from_Arab_and_Muslim_countries)

1948 A.D. ñ Pakistan ñ Jews Expelled
(https://en.wikipedia.org/wiki/Jewish_exudus_from_Arab_and_Muslim_countries)

1948 A.D. – West Bank – Jews Expelled

1948 A.D. – Jerusalem – Jews Expelled

1948 A.D. – Morocco – Jews Expelled (Yehuda Grinker, ‘The Emigration of Atlas Jews to
Israel’, 1973)

1948-1949 A.D. – Yemen – Jews Expelled/Killed for Ritual Murder
(http://www.jewishvirtuallibrary.org/jewish-refugees-from-arab-countries-yemen)

1956 A.D. ñ Egypt ñ Jews Expelled (Derek Hopwood, ‘Egypt, 1945-1990: Politics and Society’,
2002)

1959 A.D. – Cuba – Jews Expelled/forced into exile

1963 A.D. – Algeria, Africa – Jews Expelled after Algerian independence
(https://en.wikipedia.org/wiki/History_of_the_Jews_in_Algeria)

1968 A.D. – Poland – Jews Expelled
(https://en.wikipedia.org/wiki/1968_Polish_political_crisis)

1972 A.D. – Uganda – Jews Expelled by President Idi Amin (M. Jamison, ‘Idi Amin and
Uganda: An Annotated Bibliography’, 1992, p. 155)
 
2014 A.D. – San Juan la Laguana, Guatemala – Jews Expelled due to lack of contact with
locals
(http://www.telegraph.co.uk/news/worldnews/centralamericandthecaribbean/guatemala/

11065563/Jewish-sect-expelled-from-Guatemalan-village-after-clashes-with-Mayanvillagers.html)