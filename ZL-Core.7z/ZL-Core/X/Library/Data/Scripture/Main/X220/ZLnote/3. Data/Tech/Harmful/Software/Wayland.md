Thread:
- https://archive.rebeccablacktech.com/g/thread/78490275

Feature:
- Need `D-Bus` for screenshot
- discord screen sharing don't work
- The Jitsi Meet app is broken. Its authors say "there is nothing we can do from the Jitsi Meet side."
- Wayland is so barebones it requires a ton of code to implement lots of features which means it's delegated to DEs which have the resources to implement them (Gnome and KDE)
- No XEmbed support (goodbye XFCE which is built on top of XEmbed - the settings application and desktop panels)
- It makes implementing anything even remotely as effective as RDP impossible, as the compositor works will full frames/rectangles and has no idea what is changing in them and what's not. VNC (which is the only option) has always sucked tremendously.
- No graphical output APIs whatsoever. Imagine three different applications using three different graphical toolkits under Wayland. Now imagine you want all these three apps have the same 1) fonts settings and rendering 2) zoom 3) color palette. Looks like there's no option to sync these settings as the wayland compositor does absolutely nothing aside from window management, right?
- Surprise surprise, Qt applications don't work on Wayland if you don't ship their wayland support parts.
- Wine develeopers wrote that wine cannot be ported to wayland because of inability to get coordinates of the window. I find this inability mobile-friendly, but not desktop or laptop friendly.
- LoLoSwitcher is in no way eligible for porting on Wayland for now. Actually, there is no way to make compositor-independent layout switchers yet, not even mentioning that advanced ones.
- I'll try once again: I'm using module-x11-bell which replaces the terrible pcspeaker "beep" with a nice "bubble" sample.
All terminals, firefox and other programs nicely notify me of their events.
Is there a some alternative for wayland?
- Wayland, until now, is unsuitable for Color Management:
https://discuss.pixls.us/t/wayland-color-management/10804

**Let's be honest: Wayland is a thin layer on top of KMS. It's not a graphical server or even a decent graphical protocol as found in X11, Windows, MacOS or Android.**

Wayland was created in 2008. X was created in 1984. X was 24 years old at the time Wayland was created to replace it, because X was “deprecated and old”. But Wayland is 12 years old now and has barely even gotten off the ground and the vast majority of computers that run Nvidia can’t even use it. Which means that we have 12 years until Wayland also becomes old and deprecated and it hasn’t even close to replacing X.

https://gist.github.com/probonopd/9feb7c20257af5dd915e3a9f2d1f2277
Why does Wayland depend on so much RH garbage? D-Bus, glib and PipeWire should have nothing to do with Wayland.

`strycore commented on Oct 31, 2020`
Here's a fun one: There's no available Python API for getting screen modes / changing resolutions in Wayland. There is one specific to Mutter (Gnome). It's packaged in a non-production ready library called libgnomedesktop which caused a bunch of people to think that I was making the whole Gnome desktop a dependency of Lutris.

Wayland was invented to actively subvert and destroy the Linux Desktop.
X11 was messy but it was the one thing that everybody agreed upon. It was a standard.
If you help Wayland "fixing bugs" you are helping the enemy and do work that multi billion dollar companies could easly do. But they don't because their agenda is neither a thriving FOSS community nor stable interfaces that everybody can rely on.
If you purposely destroy a community established standard developed over 30 years for absolutely dubious reasons you are a traitor, nothing else.

`birdie-github commented on Nov 5, 2020`
>`erm2587 commented on Nov 5, 2020` I understand it is way easier for you to blame others for innovations that would force you (and the rest of us) to make some extra work, than sitting down and actually doing the job.

Wayland has been peddled as a second coming of Christ, sorry, something which is leaps and bounds better than X11/X.org. Only it's been 12 years. Only it still sucks everywhere outside of Gnome and it's not even fully usable under KDE. How much should we wait for to get something which is not mired in tons of limitations or features working suboptimally?

When you replace something and expect wide acceptance, you don't replace it with something substantially worse which doesn't even work for lots of people.

>https://github.com/ReimuNotMoe/ydotool ?

"This program requires access to /dev/uinput. This usually requires root permissions."


Is it just me or is there a pattern that goes like this:

[Wayland shortcoming] can be overcome by using [additional software made specifically for Wayland]?

Turning a stack like this:

Kernel, Xorg, the application (no Gnome, no KDE needed)
into a stack like this:

Kernel, Wayland, a special compositor, Pipewire, Xdg portals (leaning toward Flatpak), the application with special patches for Wayland (works only properly on Gnome and if you are lucky KDE)


IMO wayland being secure than X is a joke.
The security model of OS should based on user, not process or "app", since X already support running without root there no way a malware could affects other users.
If you're running a malware under wayland, it's may not be able to record your screen or keystroke, but it'll still be able to add extension to your firefox profile to steal your credit card numbers, or encrypt your files and ask you to pay bitcoins, wayland can't really protect you.
The worst thing is if you want to do ui automation or global key capture you have to run such app under root, it's much more dangerous than X.
If you want real securtiy, you should run untrusted apps under hypervisor, for example, Qubes OS uses X on both dom0 and vms, it's much secure than those distributions that use wayland.

---

Wayland devs sound just like gnome and systemd devs.
>you MUST use our way
>if you don't do it our way you are wrong
>Missing feature? wontfix
>Strange behavior? wontfix
>Valid criticism? It's someone else's fault.