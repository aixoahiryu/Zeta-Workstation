People:
- Admiral Byrd

Operation:
- High Jump
- Antarctic Treaty