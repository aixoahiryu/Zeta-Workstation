https://boards.4chan.org/pol/thread/312102157

According to Eustace Mullins who is Ezra Pounds protege, Marx was commissioned by the Rothschild to create an ideology for the new world order and that’s how communism was birthed
![fuckmarxists.jpg](https://i.imgur.com/ppNXyMk.jpg)

Karl Heinrich Marx was born on 5 May 1818 to Heinrich Marx (1777–1838) and Henriette Pressburg (1788–1863). He was born at Brückengasse 664 in Trier, a town then part of the Kingdom of Prussia's Province of the Lower Rhine.[22] Marx was ethnically Jewish. His maternal grandfather was a Dutch rabbi, while his paternal line had supplied Trier's rabbis since 1723, a role taken by his grandfather Meier Halevi Marx.[23] His father, as a child known as Herschel, was the first in the line to receive a secular education. He became a lawyer with a comfortably upper class income.

Putin: Soviet government was mostly jewish, 85%

https://www.youtube.com/watch?v=oIeYoF1VhHc

e.g. Karl Marx himself = JEW

e.g. The first Central Committee of the Bolshevik Party:

- Krylenko Russian
- Lounatcharski Russian
- Ulyanov (Lenin) *JEW*
- Bronstein (Trotsky) *JEW*
- Apfelbaum (Zinovief) *JEW*
- Lourie (Larine) *JEW*
- Ouritski *JEW*
- Volodarski *JEW*
- Rosenfeldt (Kamanef) *JEW*
- Smidovitch *JEW*
- Sverdlof (Yankel) *JEW*
- Nakhamkes (Steklof) *JEW*

The first Council of the People’s Commissars:

- Foreign Affairs Tchitcherine Russian
- Nationalities Djugashvili (Stalin) Georgian
- Agriculture Protian Armenian
- Public Instruction Lounatcharsky Russian
- Ulyanov (Lenin) *JEW*
- Economic Council Lourie (Larine) *JEW*
- Food Schlichter *JEW*
- Army & Navy Bronstein (Trotsky) *JEW*
- State Control Lander *JEW*
- State Lands Kauffman *JEW*
- Works V. Schmidt *JEW*
- Social Relief E. Lelina (Knigissen) *JEW*ess
- Religions Spitzberg *JEW*
- Interior Apfelbaum (Zinovief) *JEW*
- Hygiene Anvelt *JEW*
- Finance Isidore Goukovski *JEW*
- Press Volodarski *JEW*
- Elections Ouritski *JEW*
- Justice I. Steinberg *JEW*
- Refugees Fenigstein *JEW*
- Refugees (assist.) Savitch *JEW*
- Refugees (assist.) Zaslovski *JEW*

>On May 17, 1948, only three days after Israel declared independence, Stalin legally recognized it de jure, becoming the very first country to grant recognition to the Jewish state