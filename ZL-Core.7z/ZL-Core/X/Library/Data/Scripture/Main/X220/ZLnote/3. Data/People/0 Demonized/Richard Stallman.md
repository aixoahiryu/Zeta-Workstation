https://boards.4channel.org/g/thread/80850676
https://boards.4channel.org/g/thread/80854924

https://eldritchdata.neocities.org/GNULinux/DefenseOfRMS.html

A famous MIT researcher went to Epstein's rape island, but didn't know the 16 year olds were under 18 and didn't have sex with any of them. When his name showed up on the list of rape island tourists an old mailing list of MIT students and researchers wouldn't shut up about it. RMS was on the mailing list and pointed out

>80845944
No one is accusing Stallman of anything. Stallman annoyed the cathedral by pointing out that Marvin Minsky was never accused of anything so you shouldn't call him a rapist.

Some bitch on twitter misquoted RMS out of context and some professional liars ("journalists") further misquoted her misquotation to rile people up. The end result was that RMS was forced out of the FSF and MIT, with the instigators' managers (high-ups in the FSF) rising higher in the foundation and gaining a tighter grip on the foundation's money. A real "grassroots" show.