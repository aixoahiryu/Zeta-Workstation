https://www.makeuseof.com/nextdoor-roll-out-anti-racism-notifications/
![](https://i.imgur.com/kj7ey8s.png)