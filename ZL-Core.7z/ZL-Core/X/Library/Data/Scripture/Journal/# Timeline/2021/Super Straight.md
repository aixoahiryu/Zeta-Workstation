https://boards.4chan.org/pol/thread/311281163

You must be quite a young buck then. The correct and polite terms were "normal" and "queer."

The term "straight" is a globohomo invention to subtly reinforce the idea of homosexual relationships being a normal thing.

The term "superstraight" is a way to turn some of that retarded logic back onto trannies and stem the tide of all the crazy rapists trying to fuck kids and lesbos.

---

Discord trannies are mad as fuck that their pilpul wordsalad is being used against them. Gays, lesbians and Bis are siding with US against THEM over this. Nobody wants their disgusting troonwounds.

So they're trying desperately to tie SS to /pol/ to try and poison the well. The SS runeflag is guaranteed to be part of that, as are any Black Sun edits. The thing is, normies aren't buying it because everyone knows it was some zoomer kid on tiktok that started it.

/Pol/ is doing what /pol/ always does, but SS didn't start here. It isn't a "psyop". It's the entire world's natural revulsion at troons being let loose and the troons simply cannot handle it. So they feel compelled to try and ruin it.

Literally no one outside of /pol/ thinks it started here. Literally no one outside of /pol/ thinks "Le ebul naht-zeez did it!". Discord trannies are trying so desperately to push this anywhere they can that they're astroturfing it themselves in their delusional breakdown states.

Now the troon jannies are getting in on it. Deleting the /ss/ general and leaving these clearly astroturfed threads trying desperately to tie /ss/ to nazi icongraphy, sloganeering and propaganda. They're then taking the screencaps of these threads (that they're probably creating themselves) and running to twitter to scream in their mannish voices, "SEE, LE EBUL NAHTZEES DID IT LIKE I SAID! YOU HAVE TO ABANDON SUPERSTRAIGHT NOW AND FUCK MY TROON WOUND!"