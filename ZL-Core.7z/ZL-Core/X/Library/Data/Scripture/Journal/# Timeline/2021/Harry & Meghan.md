Do normie retards actually not notice blatant mental disorders?
The matchmaker that set them up was a kike. The kikes have blackmail on the royal family of course. It's not hard to put two and two together.
Jews are the most abhorrent creatures on the face of the earth