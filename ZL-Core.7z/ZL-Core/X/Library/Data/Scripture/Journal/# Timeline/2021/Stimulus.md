>$1.9 trillion divided by 350 million people = $5,430 per person
>we only get $1,400

But wait it gets worse
>$1.9 trillion divided by 220 million adults = $8630 per person

WHERE IS THE REST GOING?
![1613450465255.jpg](https://i.imgur.com/UF0EZBZ.jpg)