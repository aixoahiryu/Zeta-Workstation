Biden:
- Mar10-2021 https://boards.4chan.org/pol/thread/311448343

![A7BC3833-A604-40E4-BB3E-8A21675B69DC.jpg](https://i.imgur.com/TKVq1xQ.jpeg)

![Martial Law.jpg](https://i.imgur.com/q2mz5hk.jpg)