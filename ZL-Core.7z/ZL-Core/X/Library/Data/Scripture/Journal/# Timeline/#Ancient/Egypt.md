Egypt was a land of unprecedented prosperity and reliability, honestly. The Nile was so regular that they could plan everything, their economy, religion, trips, wars all around the river's floods, and their legendary fertility.

Nothing like the manufactured bust-boom cycle of today that exists as a trap.

You have to wonder why nothing was ever built to last after a certain point, and when did it start? The US and most early modern and post modern societies are like the ponzi scheme stock market, strait up and strait down with the bull and bust cycles every so often, with the men in the back cashing out to the next refuge when they decide the party is over.

It started around 1910 when a bunch of lightbulb manufacturers got together in secret to lower the average lifespan of a bulb from 5000-10000 hours to 1,000 hours. They fined companies that made longer lasting bulbs and had strict testing to make sure their products were inferior enough.

A Jew in the 1930's named London tried to get a law past in the US that all consumer goods have to be returned to the government of disposal after x number of years. Every single appliance or good would come with an expiry date.