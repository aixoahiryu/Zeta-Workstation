![crazy_QRD2.png](https://i.imgur.com/zAOQoKp.png)
![Crazy_Times_Carnival_orig](https://i.imgur.com/5xMsgmf.png)