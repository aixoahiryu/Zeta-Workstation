![1610407874894.jpg](https://i.imgur.com/1JFiMdz.jpeg)
![1614287285323.jpg](https://i.imgur.com/T7SbmqK.jpg)

The Jan 6 thing scared the shit out of the kikes in D.C., they have never felt so vulnerable in their entire lives. All of these years sitting in their cozy offices robbing the country blind while importing a hostile foreign people to replace the rightful European stock.

The troops are meant to intimidate the conservatives in this nation under the guise of an unbreakable allegiance to the rulers.

They know that the Jan 6 riots weren't meant to be violent but but if they were it would have been a real, real problem for them.

They're scared of us, anon.