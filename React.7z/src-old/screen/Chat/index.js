import ChatScreen from './ChatScreen';
export default ChatScreen;
