import TabIcon from './TabIcon';
export default TabIcon;
