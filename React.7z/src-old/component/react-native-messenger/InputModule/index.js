import InputModule from './InputModule';
export default InputModule;
