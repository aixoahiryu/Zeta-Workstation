import SearchHeader from './SearchHeader';
export default SearchHeader;
