import FBStatusBar from './FBStatusBar';
export default FBStatusBar;
