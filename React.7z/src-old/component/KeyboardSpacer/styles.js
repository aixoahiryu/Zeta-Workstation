import { StyleSheet } from 'react-native';

const styles = StyleSheet.create({
    wrapper: {}
});

export default styles;
