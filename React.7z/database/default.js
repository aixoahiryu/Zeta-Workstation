import React, { useState } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';

const DefaultData = () =>  {
	AsyncStorage.setItem('background-enabled', 'false' );
	AsyncStorage.setItem('background-hour', '2' );
	AsyncStorage.setItem('darkmode-enabled', 'false' );

	AsyncStorage.setItem('domains', '[]' );
}

export default DefaultData;