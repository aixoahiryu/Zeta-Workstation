import * as React from 'react';
import { Button, Text, View } from 'react-native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { createNativeStackNavigator } from '@react-navigation/native-stack';

import { Ionicons } from '@expo/vector-icons';

import Home from '../../src/screen/home';
import Settings from '../../src/screen/settings';
import Help from '../../src/screen/help';

const Tab = createBottomTabNavigator();
export default function TabContainer() {
  return (
    
      <Tab.Navigator
        screenOptions={ ({ route }) => ({
          tabBarIcon: ({ focused, color, size }) => {
            let iconName;

            if (route.name === 'Rank') { iconName = focused ? 'bar-chart' : 'bar-chart-outline'; }
            else if (route.name === 'Settings') { iconName = focused ? 'cog' : 'cog-outline'; }
            else if (route.name === 'Help') { iconName = focused ? 'help' : 'help-outline'; }

            return <Ionicons name={iconName} size={size} color={color} />;
          },
          tabBarActiveTintColor: 'tomato',
          tabBarInactiveTintColor: 'gray',
          headerShown: false , 
        })}
      >
        <Tab.Screen name="Rank" component={Home} />
        <Tab.Screen name="Settings" component={Settings} options={{ tabBarBadge: 3 }} />
        <Tab.Screen name="Help" component={Help} />
      </Tab.Navigator>
    
  );
}