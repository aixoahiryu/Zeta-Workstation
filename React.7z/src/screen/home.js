import React, { useState } from 'react';
import { Platform, Text, View, ScrollView, Button, TouchableOpacity, SectionList, TextInput } from 'react-native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { useNavigation } from '@react-navigation/native';
//import matchAll from 'string.prototype.matchAll';
//import { WebView } from 'react-native-webview';
import axios from 'axios';
//import { polyfill } from 'react-native-polyfill-globals';

import style from '../../src/config/style';


const DATA = [
  {
    title: "example.com",
    data: ["Locale: international", "Keyword: example", "Rank: 6"]
  },
  {
    title: "Sides",
    data: ["French Fries", "Onion Rings", "Fried Shrimps"]
  },
  {
    title: "Drinks",
    data: ["Water", "Coke", "Beer"]
  },
  {
    title: "Desserts",
    data: ["Cheese Cake", "Ice Cream"]
  }
];

const Item = ({ title }) => (
  <View style={style.item}>
    <Text style={style.title}>{title}</Text>
  </View>
);

//======================================================

function RankScreen() {
  //matchAll.shim();

  const [domain, setDomain] = useState("example.com");
  const [locale, setLocale] = useState("");
  const [keyword, setKeyword] = useState("example");
  const [rank, setRank] = useState("0");
  const [debug, setDebug] = useState("...");
  const [debug2, setDebug2] = useState("...");
  const [debug3, setDebug3] = useState("...");

  const options = {
    method: 'GET',
    mode: 'no-cors'
  };

  return (
    <ScrollView style={style.container}>
      <Text>Domain</Text>
      <TextInput style={style.input}  value={domain} onChangeText={ (data) => {setDomain(data)} } />

      <Text>Locale</Text>
      <TextInput style={style.input} value={locale}  onChangeText={ (data) => {setLocale(data)} } />

      <Text>Keyword</Text>
      <TextInput style={style.input} value={keyword}  onChangeText={ (data) => {setKeyword(data)} } />
      <Button
          title="Get rank"
          onPress={() => {
            //https://www.google.com/search?q=example&num=100&nfpr=1
            //const url = 'https://www.google.com' + locale + '/search?q=' + keyword + '&num=100&nfpr=1'
            //const url = 'https://cors-anywhere.herokuapp.com/https://www.google.com' + locale + '/search?q=' + keyword + '&num=100&nfpr=1'
            const url = 'https://zeta-cors.herokuapp.com/https://www.google.com' + locale + '/search?q=' + keyword + '&num=100&nfpr=1'
            //const url = 'https://textbin.net/raw/g75tkkliiu'
            //const url = 'https://cors-anywhere.herokuapp.com/https://textbin.net/raw/g75tkkliiu'
            
            //const regex = /class=\"rc(.*?)class=\"r\"(.*?)<a\\shref=\"([^\"]*?)\"\\sping/g
            //const regex = /https?:\/\/(?:www\.)?/g
            //const regex = /^https?\:\/\/([^\/?#]+)(?:[\/?#]|$)/gi
            //const regex  = /#<h3.*?><a href="(.*?)".*?<\/h3>#/g
            //const regex = /^https?\:\/\/([^\/:?#]+)(?:[\/:?#]|$)/gi
            //const regex = /<div class="[^"]*?yuRUbf[^"]*?">(.*?)<\/div>/g
            //const regex = /<div class="[^"]*?yuRUbf[^"]*?">(.*?)data\-ved\=/g
            //const regexg = /<div class="[^"]*?yuRUbf[^"]*?">(.*?)data\-ved\=/
            const regex = /yuRUbf(.*?)data\-ved\=/g
            const regexg = /yuRUbf(.*?)data\-ved\=/
            //var regexA = new RegExp("kCrYT(.*?)\"><h3", "g");
            //const regexA = /egMi0 kCrYT(.*?)\"><h3/g
            //const regexA = /\<a href=\"\/url\?q\=(.*?)\"><h3/g
            const regexA = /kCrYT\"><a href=\"\/url\?q\=(.*?)\"><h3/g
            //const regex2 = /https?\:\/\/www.([^\/:?#]+)(?:[\/:?#]|$)/
            const regex2 = /([^\/:?#]+)/g
            //const regex2 = /((?!-))(xn--)?[a-z0-9][a-z0-9-_]{0,61}[a-z0-9]{0,1}\.(xn--)?([a-z0-9\-]{1,61}|[a-z0-9-]{1,30}\.[a-z]{2,})/
            //const regex2 = /[a-zA-Z0-9][a-zA-Z0-9-]{1,61}[a-zA-Z0-9]\.[a-zA-Z]{2,}/

            /*
            fetch(url)
            .then( (data) => {
              return data.text();
              console.log(data);
            } )
            .then( (data) => {
              setDebug(data.toString());
              console.log(data);
            } )
            .catch(e => { console.log(e); });

            axios.get(url).then((response) => {
              setDebug(response.data);
            });
            */

            //https://stackoverflow.com/questions/43462367/how-to-overcome-the-cors-issue-in-reactjs
            let config = {
              headers: {
                'X-Requested-With': 'XMLHttpRequest',
              }
            }

            axios.get( encodeURI(url), config ).then((response) => {
              setDebug(response.data);
              
              /*const matches = response.data.matchAll(regex);
              const matches3 = Array.from(matches, x => x[1]);*/
              //matches3 = [...response.data.matchAll(regex)];
              //matches3 = [...matchAll(response.data, regex)];
              /*var match_result = response.data.match(regex);
               for (let index in match_result){
                 var item = match_result[index];
                 matches3[index] = item.match(new RegExp(regexg));
               }*/
              var matches3 = [];
              if (Platform.OS === 'android' || Platform.OS === 'ios'){
                const teststr = response.data.substr(0, response.data.length);
                console.log(response.data.substr(response.data.indexOf('data-ved')-1000, 1000));
                console.log('length: '+response.data.length);
                console.log('</body>: '+response.data.indexOf('</body>'));
                console.log('yuRUbf: '+response.data.indexOf('yuRUbf'));
                console.log('kCrYT: '+response.data.indexOf('kCrYT'));
                console.log('data-ved: '+response.data.indexOf('data-ved'));
                console.log(response.data.match(regexA));

                var match_result = response.data.match(regexA);
                for (let index in match_result){
                  var item = match_result[index];
                  matches3[index] = item.match(new RegExp(regexA));
                }
              }
              else { matches3 = [...response.data.matchAll(regex)]; }
              setDebug2(matches3.toString());

              var result = [];   var result2 = [];
              for (var i = 0; i < matches3.length; i++) {
                var str1='';    var str2='';
                str1 = matches3[i][0].match(regex2);
                if (Platform.OS === 'android'){ str2 = str1[3].replace('www.', ''); }
                else { str2 = str1[1].replace('www.', ''); }

                result.push(str2);
                if (str2==domain) { result2.push(i); }
              }
              //setDebug3( result.toString().replaceAll(',' , '\n') );
              setDebug3( result.toString().replace(/,/g , '\n') );
              setRank( (result2[0] + 1).toString() );
              console.log(domain);  console.log(result2);
            })
            .catch((error) => { console.log(error); });

          } }
        />
        <View style={style.row}>
        <Text>Rank</Text>
        <TextInput style={{ width: 100, borderWidth: 1 }} value={rank} />
        </View>

      <Text style={{ marginTop: 50 }} >Debug data:</Text>
      <TextInput style={{ height: 250, borderWidth: 1 }} value={debug} multiline={true} />
      <TextInput style={{ height: 250, borderWidth: 1 }} value={debug2} multiline={true} />
      <TextInput style={{ height: 250, borderWidth: 1 }} value={debug3} multiline={true} />

    </ScrollView>
  );
}

function DetailsScreen() {
  return (
    <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
      <Text>Details!</Text>
    </View>
  );
}

function AddScreen() {
  return (
    <View style={style.container}>
      <Text>Domain</Text>
      <TextInput
        style={style.input}
        />
      <Text>Locale</Text>
      <TextInput
        style={style.input}
        />
      <Text>Keywords (separate with ,)</Text>
      <TextInput
        style={style.input}
        />
      <Button
          title="Add"
          onPress={() => alert('Added') }
        />
    </View>
  );
}

function HomeScreen({ navigation }) {
  return (
    <View style={style.container}>
      <View style={style.row}>
      <Button
          title="Demo: rank"
          onPress={() => navigation.navigate('Ranking')}
        />
        <Button
          title="Details"
          onPress={() => navigation.navigate('Details')}
        />
        <Button
          title="Add"
          onPress={() => navigation.navigate('Add')}
        />
      </View>

      <SectionList
          sections={DATA}
          keyExtractor={(item, index) => item + index}
          renderItem={({ item }) => <Item title={item} />}
          renderSectionHeader={({ section: { title } }) => (
            <Text style={style.header}>{title}</Text>
          )}
        />
    </View>
  );
}

const HomeStack = createNativeStackNavigator();

function HomeStackScreen() {
  const navigation = useNavigation();

  return (
    <HomeStack.Navigator>
      <HomeStack.Screen name="Home" component={HomeScreen} options={{
            headerTitle: 'Rank',
            headerRight: () => (
              <Button
                style={style.headerButton}
                onPress={() => navigation.navigate('Add')}
                title="+"
              />
            ),
          }} />
      <HomeStack.Screen name="Details" component={DetailsScreen} />
      <HomeStack.Screen name="Add" component={AddScreen} />
      <HomeStack.Screen name="Ranking" component={RankScreen} />
    </HomeStack.Navigator>
  );
}


export default class Home extends React.Component {
  render() {
    return (
        <HomeStackScreen />
    );
  }
}
