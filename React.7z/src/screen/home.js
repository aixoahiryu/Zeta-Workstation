import React, { useState, useEffect } from 'react';
import { ActivityIndicator, Platform, Text, View, ScrollView, Button, TouchableOpacity, SectionList, TextInput } from 'react-native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { useNavigation, useFocusEffect } from '@react-navigation/native';
import AsyncStorage from '@react-native-async-storage/async-storage';
//import matchAll from 'string.prototype.matchAll';
//import { WebView } from 'react-native-webview';
import axios from 'axios';
//import { polyfill } from 'react-native-polyfill-globals';

import { Ionicons } from '@expo/vector-icons';

import style from '../../src/config/style';
import GoogleRank from '../../src/network/google';


const DATA = [
  {
    title: "example.com",
    data: ["Locale: international", "Keyword: example", "Rank: 6"]
  },
  {
    title: "Sides",
    data: ["French Fries", "Onion Rings", "Fried Shrimps"]
  },
  {
    title: "Drinks",
    data: ["Water", "Coke", "Beer"]
  },
  {
    title: "Desserts",
    data: ["Cheese Cake", "Ice Cream"]
  }
];

const Item = ({ title }) => (
  <View style={style.item}>
    <Text style={style.title}>{title}</Text>
  </View>
);

const sleep = ms => new Promise(r => setTimeout(r, ms));

//======================================================

function RankScreen() {
  //matchAll.shim();

  const [domain, setDomain] = useState("example.com");
  const [locale, setLocale] = useState("");
  const [keyword, setKeyword] = useState("example");
  const [rank, setRank] = useState("0");
  const [debug, setDebug] = useState("...");
  const [debug2, setDebug2] = useState("...");
  const [debug3, setDebug3] = useState("...");

  const options = {
    method: 'GET',
    mode: 'no-cors'
  };

  return (
    <ScrollView style={style.container}>
      <Text>Domain</Text>
      <TextInput style={style.input}  value={domain} onChangeText={ (data) => {setDomain(data)} } />

      <Text>Locale</Text>
      <TextInput style={style.input} value={locale}  onChangeText={ (data) => {setLocale(data)} } />

      <Text>Keyword</Text>
      <TextInput style={style.input} value={keyword}  onChangeText={ (data) => {setKeyword(data)} } />
      <Button
          title="Get rank"
          onPress={() => {
            //https://www.google.com/search?q=example&num=100&nfpr=1
            //const url = 'https://www.google.com' + locale + '/search?q=' + keyword + '&num=100&nfpr=1'
            //const url = 'https://cors-anywhere.herokuapp.com/https://www.google.com' + locale + '/search?q=' + keyword + '&num=100&nfpr=1'
            const url = 'https://zeta-cors.herokuapp.com/https://www.google.com' + locale + '/search?q=' + keyword + '&num=100&nfpr=1'
            //const url = 'https://textbin.net/raw/g75tkkliiu'
            //const url = 'https://cors-anywhere.herokuapp.com/https://textbin.net/raw/g75tkkliiu'
            
            //const regex = /class=\"rc(.*?)class=\"r\"(.*?)<a\\shref=\"([^\"]*?)\"\\sping/g
            //const regex = /https?:\/\/(?:www\.)?/g
            //const regex = /^https?\:\/\/([^\/?#]+)(?:[\/?#]|$)/gi
            //const regex  = /#<h3.*?><a href="(.*?)".*?<\/h3>#/g
            //const regex = /^https?\:\/\/([^\/:?#]+)(?:[\/:?#]|$)/gi
            //const regex = /<div class="[^"]*?yuRUbf[^"]*?">(.*?)<\/div>/g
            //const regex = /<div class="[^"]*?yuRUbf[^"]*?">(.*?)data\-ved\=/g
            //const regexg = /<div class="[^"]*?yuRUbf[^"]*?">(.*?)data\-ved\=/
            const regex = /yuRUbf(.*?)data\-ved\=/g
            const regexg = /yuRUbf(.*?)data\-ved\=/
            //var regexA = new RegExp("kCrYT(.*?)\"><h3", "g");
            //const regexA = /egMi0 kCrYT(.*?)\"><h3/g
            //const regexA = /\<a href=\"\/url\?q\=(.*?)\"><h3/g
            const regexA = /kCrYT\"><a href=\"\/url\?q\=(.*?)\"><h3/g
            //const regex2 = /https?\:\/\/www.([^\/:?#]+)(?:[\/:?#]|$)/
            const regex2 = /([^\/:?#]+)/g
            //const regex2 = /((?!-))(xn--)?[a-z0-9][a-z0-9-_]{0,61}[a-z0-9]{0,1}\.(xn--)?([a-z0-9\-]{1,61}|[a-z0-9-]{1,30}\.[a-z]{2,})/
            //const regex2 = /[a-zA-Z0-9][a-zA-Z0-9-]{1,61}[a-zA-Z0-9]\.[a-zA-Z]{2,}/

            /*
            fetch(url)
            .then( (data) => {
              return data.text();
              console.log(data);
            } )
            .then( (data) => {
              setDebug(data.toString());
              console.log(data);
            } )
            .catch(e => { console.log(e); });

            axios.get(url).then((response) => {
              setDebug(response.data);
            });
            */

            //https://stackoverflow.com/questions/43462367/how-to-overcome-the-cors-issue-in-reactjs
            let config = {
              headers: {
                'X-Requested-With': 'XMLHttpRequest',
              }
            }

            axios.get( encodeURI(url), config ).then((response) => {
              setDebug(response.data);
              
              /*const matches = response.data.matchAll(regex);
              const matches3 = Array.from(matches, x => x[1]);*/
              //matches3 = [...response.data.matchAll(regex)];
              //matches3 = [...matchAll(response.data, regex)];
              /*var match_result = response.data.match(regex);
               for (let index in match_result){
                 var item = match_result[index];
                 matches3[index] = item.match(new RegExp(regexg));
               }*/
              var matches3 = [];
              if (Platform.OS === 'android' || Platform.OS === 'ios'){
                const teststr = response.data.substr(0, response.data.length);
                console.log(response.data.substr(response.data.indexOf('data-ved')-1000, 1000));
                console.log('length: '+response.data.length);
                console.log('</body>: '+response.data.indexOf('</body>'));
                console.log('yuRUbf: '+response.data.indexOf('yuRUbf'));
                console.log('kCrYT: '+response.data.indexOf('kCrYT'));
                console.log('data-ved: '+response.data.indexOf('data-ved'));
                console.log(response.data.match(regexA));

                var match_result = response.data.match(regexA);
                for (let index in match_result){
                  var item = match_result[index];
                  matches3[index] = item.match(new RegExp(regexA));
                }
              }
              else { matches3 = [...response.data.matchAll(regex)]; }
              setDebug2(matches3.toString());

              var result = [];   var result2 = [];
              for (var i = 0; i < matches3.length; i++) {
                var str1='';    var str2='';
                str1 = matches3[i][0].match(regex2);
                if (Platform.OS === 'android'){ str2 = str1[3].replace('www.', ''); }
                else { str2 = str1[1].replace('www.', ''); }

                result.push(str2);
                if (str2==domain) { result2.push(i); }
              }
              //setDebug3( result.toString().replaceAll(',' , '\n') );
              setDebug3( result.toString().replace(/,/g , '\n') );
              setRank( (result2[0] + 1).toString() );
              console.log(domain);  console.log(result2);
            })
            .catch((error) => { console.log(error); });

          } }
        />
        <View style={style.row}>
        <Text>Rank</Text>
        <TextInput style={{ width: 100, borderWidth: 1 }} value={rank} />
        </View>

      <Text style={{ marginTop: 50 }} >Debug data:</Text>
      <TextInput style={{ height: 250, borderWidth: 1 }} value={debug} multiline={true} />
      <TextInput style={{ height: 250, borderWidth: 1 }} value={debug2} multiline={true} />
      <TextInput style={{ height: 250, borderWidth: 1 }} value={debug3} multiline={true} />

    </ScrollView>
  );
}

function DetailsScreen({route, navigation}) {
  return (
    <ScrollView style={style.container}>
      <Text>Domain: {route.params.item.domain}</Text>
      <Text>Locale: {route.params.item.locale}</Text>
      {route.params.item.keywords.map(i2 => {
        return(
          <Text>{i2.keyword}: {i2.rank.toString()}</Text>
        )
       })}
    </ScrollView>
  );
}

function AddScreen({ navigation }) {
  //const navigation = useNavigation();
  const [domain, setDomain] = useState("example.com");
  const [locale, setLocale] = useState("");
  const [keywords, setKeywords] = useState("example, test");

  return (
    <View style={style.container}>
      <Text>Domain</Text>
      <TextInput style={style.input}  value={domain} onChangeText={ (data) => {setDomain(data)} }  />
      <Text>Locale</Text>
      <TextInput style={style.input}  value={locale} onChangeText={ (data) => {setLocale(data)} }  />
      <Text>Keywords (separate with ,)</Text>
      <TextInput style={style.input}  value={keywords} onChangeText={ (data) => {setKeywords(data)} } />
      <Button
          title="Add"
          onPress={() => {
            AsyncStorage.getItem('domains').then( (data) => {
              var domains = JSON.parse(data);
              var json1 = 
              {
                domain: domain,
                locale: locale,
                keywords: [
                  {
                    keyword: "test",
                    rank: [ 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 ]
                  },
                  {
                    keyword: "example",
                    rank: [ 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 ]
                  }
                ]
              }

              if ( (domains.includes(domain)) == false ) { 
                domains.push(domain);     domains.sort(); 
                json1.keywords = [];        const keywords1 = keywords.split(',');
                for(var i=0; i<keywords1.length; i++){
                  var keyword1 = { keyword: keywords1[i].trim(), rank: [] };
                  json1.keywords.push(keyword1);
                }
                AsyncStorage.setItem( 'domains', JSON.stringify(domains) );
                AsyncStorage.setItem( domain, JSON.stringify(json1) );
                navigation.navigate('Home', {update: true});
              }
              else { alert('Domain already exists') }

              //console.log(JSON.stringify(domains)); console.log(domains);
              //console.log(JSON.stringify(json1)); console.log(json1);
              //for(var i=0; i<domains.length; i++){ AsyncStorage.getItem(domains[i]).then( (data) => {   console.log(JSON.parse(data)); }) }
            } );
          } }
        />
    </View>
  );
}

function EditScreen({ route, navigation }) {
  const [domain, setDomain] = useState(route.params.item.domain);
  const [locale, setLocale] = useState(route.params.item.locale);
  const [keywords, setKeywords] = useState('');
  /*route.params.item.keywords.map(i2 => {
    keywords1 = keywords1 + i2.keyword + ', ';
    if ( i2.keyword == route.params.item.keywords[route.params.item.keywords.length-1].keyword ){
      setKeywords(keywords1);
    }
  } );*/

  useEffect(() => {
    var keywords1 = '';
    for(var i=0; i<route.params.item.keywords.length; i++){
      keywords1 = keywords1 + route.params.item.keywords[i].keyword + ', ';
      if( i == (route.params.item.keywords.length - 1) ) { setKeywords(keywords1); }
      console.log(i + ' | ' + (route.params.item.keywords.length - 1) );
      if( i == (route.params.item.keywords.length - 1) ) { console.log(true) }
    }
  }, []);

  return (
    <View style={style.container}>
      <Text>Domain</Text>
      <TextInput style={style.input}  value={domain} />
      <Text>Locale</Text>
      <TextInput style={style.input}  value={locale} onChangeText={ (data) => {setLocale(data)} }  />
      <Text>Keywords (separate with ,)</Text>
      <TextInput style={style.input}  value={keywords} onChangeText={ (data) => {setKeywords(data)} } />
      <Button
          title="Edit"
          onPress={() => {
            AsyncStorage.getItem('domains').then( (data) => {
              var domains = JSON.parse(data);
              var json1 = 
              {
                domain: domain,
                locale: locale,
                keywords: [
                  {
                    keyword: "test",
                    rank: [ 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 ]
                  },
                  {
                    keyword: "example",
                    rank: [ 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 ]
                  }
                ]
              }

              if ( (domains.includes(domain)) == true ) { 
                //domains.push(domain);     domains.sort(); 
                json1.keywords = [];        const keywords1 = keywords.split(',');
                for(var i=0; i<keywords1.length; i++){
                  var keyword1 = { keyword: keywords1[i].trim(), rank: [] };
                  if( keywords1[i].trim() != '' ) { json1.keywords.push(keyword1); }
                }
                AsyncStorage.setItem( 'domains', JSON.stringify(domains) );
                AsyncStorage.setItem( domain, JSON.stringify(json1) );
                navigation.navigate('Home', {update: true});
              }
              else { alert('Domain does not exists') }
              GoogleRank(domain, locale, keywords.split(',')[0]);
              //console.log(JSON.stringify(domains)); console.log(domains);
              //console.log(JSON.stringify(json1)); console.log(json1);
              //for(var i=0; i<domains.length; i++){ AsyncStorage.getItem(domains[i]).then( (data) => {   console.log(JSON.parse(data)); }) }
            } );
          } }
        />
        <Button
          title="Delete"
          onPress={() => {
            AsyncStorage.getItem('domains').then( (data) => {
              var domains = JSON.parse(data);
              const index = domains.indexOf(route.params.item.domain);
              if (index > -1) { 
                domains.splice(index, 1);
              }

              AsyncStorage.setItem( 'domains', JSON.stringify(domains) );
              AsyncStorage.setItem( route.params.item.domain, '' );
              navigation.navigate('Home', {update: true});
            })
          } }
        />
    </View>
  );
}

function HomeScreen({ route, navigation }) {
  //var domains = [1,2,3];
  const [items, setItems] = useState([1,2,3]);
  const [loadingScreen, setLoadingScreen] = useState(true);

  const getData = () => {
    setLoadingScreen(true);
    var items1 = [];

    AsyncStorage.getItem('domains').then( (data) => { 
      const domains = JSON.parse(data);
      for(var i=0; i<domains.length; i++){
        AsyncStorage.getItem(domains[i]).then( (data) => {  
         var data1 = JSON.parse(data);
         items1.push(data1);
         if( data1.domain == domains[domains.length-1] ) { setItems(items1); setLoadingScreen(false); console.log(items1); }
        }) }
      //setItems(domains); setLoadingScreen(false);
    } );
  }

  const watchRank = () => {
    var found = false;
      AsyncStorage.getItem('domains').then( (data) => { 
      const domains = JSON.parse(data);
      for(var i=0; i<domains.length; i++){    if (found === true) { break; }
        AsyncStorage.getItem(domains[i]).then( (data) => {
         var data1 = JSON.parse(data);
         for(var i2=0; i2<data1.keywords.length; i2++){      if (found === true) { break; }
          if ( data1.keywords[i2].rank[data1.keywords[i2].rank.length-1] == null ) {
            GoogleRank(data1.domain, data1.locale, data1.keywords[i2].keyword);
            found = true;
          }
         }
        }) }
      } );
  }

  useEffect(() => {
    getData();
    watchRank();

    setInterval( () => { getData(); }, 20000);
    setInterval( () => { watchRank(); }, 60000);
  }, []);

  useFocusEffect(
    React.useCallback(() => {
      if (route.params?.update) { getData() }
      if (route.params?.delete) { getData(); }
      return () => {
        //alert('Screen was unfocused');
      };
    }, [route.params?.update, route.params?.delete])
  );

  const renderElement = (items) => {
    if (loadingScreen){
      return (
        <View style={style.fullScreen}>
          <Text style={{ fontSize: 20 }}>...</Text>
        </View>
      );
    }
    else{
      //return null;
      return(
        <View>
          {items.map(i => { 
         return(
            <View style={style.domain} >
              <View style={style.row} >
                <Text> Domain: {i.domain} </Text>
                <Button title="Details" onPress={() => navigation.navigate('Details', {item: i})} />
                <Button title="Edit" onPress={() => navigation.navigate('Edit', {item: i})} />
              </View>
              <Text> Locale: {i.locale} </Text>
              <Text> Keywords:  </Text>
              {i.keywords.map(i2 => {
                return(<View style={style.row} >
                  <Text>{i2.keyword}: {i2.rank.toString()}</Text> 
                  { i2.rank[i2.rank.length-1] == null ? <ActivityIndicator /> : null }
                  { i2.rank[i2.rank.length-1] == 0 ? <Text> - </Text> : null }
                  { i2.rank[i2.rank.length-1] > 0 ? <Text>{i2.rank[i2.rank.length-1]}</Text>  : null }
                </View>)
              })}
            </View>
          )
      }) }
        </View>
      )
    }
    
  };

  return (
    <ScrollView style={style.container}>
      {renderElement(items)}

      

      {/*<SectionList
          sections={DATA}
          keyExtractor={(item, index) => item + index}
          renderItem={({ item }) => <Item title={item} />}
          renderSectionHeader={({ section: { title } }) => (
            <Text style={style.header}>{title}</Text>
          )}
        />*/}
    </ScrollView>
  );
}

const HomeStack = createNativeStackNavigator();

function HomeStackScreen() {
  const navigation = useNavigation();

  const reloadRank = () => {
   var items1 = [];
    AsyncStorage.getItem('domains').then( (data) => { 
      const domains = JSON.parse(data);
      for(var i=0; i<domains.length; i++){
        AsyncStorage.getItem(domains[i]).then( (data) => {  
         var data1 = JSON.parse(data);
         items1.push(data1);
         if( data1.domain == domains[domains.length-1] ) { reloadRank2(domains, items1) }
        }) }
    } );
  }

  async function reloadRank2(domains, items1){
    for(var i=0; i<domains.length; i++){
      for(var i2=0; i2<items1[i].keywords.length; i2++){
        GoogleRank(items1[i].domain, items1[i].locale, items1[i].keywords[i2].keyword);
        await sleep(60*1000);
      }
    }
  }

  return (
    <HomeStack.Navigator>
      <HomeStack.Screen name="Home" component={HomeScreen} options={{
            headerTitle: 'Rank',
            headerRight: () => (
              <View style={{flexDirection:"row"}}>
              <Button
                onPress={() => navigation.navigate('Add')}
                title="Add"
              />
              <Button
                onPress={() => reloadRank()}
                title="Reload"
              />
              <Button
                title="Demo: rank"
                onPress={() => navigation.navigate('Ranking')}
              />
              </View>
            ),
          }} />
      <HomeStack.Screen name="Details" component={DetailsScreen} />
      <HomeStack.Screen name="Add" component={AddScreen} />
      <HomeStack.Screen name="Edit" component={EditScreen} />
      <HomeStack.Screen name="Ranking" component={RankScreen} />
    </HomeStack.Navigator>
  );
}


export default class Home extends React.Component {
  render() {
    return (
        <HomeStackScreen />
    );
  }
}
