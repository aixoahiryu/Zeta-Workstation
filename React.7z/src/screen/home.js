import React, { useState } from 'react';
import { Text, View, ScrollView, Button, TouchableOpacity, SectionList, TextInput } from 'react-native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
//import { WebView } from 'react-native-webview';
import axios from 'axios';
//import { polyfill } from 'react-native-polyfill-globals';

import style from '../../src/config/style';

const DATA = [
  {
    title: "Main dishes",
    data: ["Pizza", "Burger", "Risotto"]
  },
  {
    title: "Sides",
    data: ["French Fries", "Onion Rings", "Fried Shrimps"]
  },
  {
    title: "Drinks",
    data: ["Water", "Coke", "Beer"]
  },
  {
    title: "Desserts",
    data: ["Cheese Cake", "Ice Cream"]
  }
];

const Item = ({ title }) => (
  <View style={style.item}>
    <Text style={style.title}>{title}</Text>
  </View>
);

//======================================================

function RankScreen() {
  const [domain, setDomain] = useState("example.com");
  const [locale, setLocale] = useState("");
  const [keyword, setKeyword] = useState("example");
  const [rank, setRank] = useState("0");
  const [debug, setDebug] = useState("...");
  const [debug2, setDebug2] = useState("...");
  const [debug3, setDebug3] = useState("...");

  const options = {
    method: 'GET',
    mode: 'no-cors'
  };

  return (
    <ScrollView style={style.container}>
      <Text>Domain</Text>
      <TextInput style={style.input}  value={domain} onChangeText={ (data) => {setDomain(data)} } />

      <Text>Locale</Text>
      <TextInput style={style.input} value={locale}  onChangeText={ (data) => {setLocale(data)} } />

      <Text>Keyword</Text>
      <TextInput style={style.input} value={keyword}  onChangeText={ (data) => {setKeyword(data)} } />
      <Button
          title="Get rank"
          onPress={() => {
            
            //const url = 'https://www.google.com' + locale + '/search?q=' + keyword + '&num=100&nfpr=1'
            const url = 'https://cors-anywhere.herokuapp.com/https://www.google.com' + locale + '/search?q=' + keyword + '&num=100&nfpr=1'
            //const url = 'https://textbin.net/raw/g75tkkliiu'
            //const url = 'https://cors-anywhere.herokuapp.com/https://textbin.net/raw/g75tkkliiu'
            
            //const regex = /class=\"rc(.*?)class=\"r\"(.*?)<a\\shref=\"([^\"]*?)\"\\sping/g
            //const regex = /https?:\/\/(?:www\.)?/g
            //const regex = /^https?\:\/\/([^\/?#]+)(?:[\/?#]|$)/gi
            //const regex  = /#<h3.*?><a href="(.*?)".*?<\/h3>#/g
            //const regex = /^https?\:\/\/([^\/:?#]+)(?:[\/:?#]|$)/gi
            //const regex = /<div class="[^"]*?yuRUbf[^"]*?">(.*?)<\/div>/g
            const regex = /<div class="[^"]*?yuRUbf[^"]*?">(.*?)data\-ved\=/g
            //const regex2 = /https?\:\/\/www.([^\/:?#]+)(?:[\/:?#]|$)/g
            const regex2 = /([^\/:?#]+)/g

            /*
            fetch(url)
            .then( (data) => {
              return data.text();
              console.log(data);
            } )
            .then( (data) => {
              setDebug(data.toString());
              console.log(data);
            } )
            .catch(e => { console.log(e); });

            axios.get(url).then((response) => {
              setDebug(response.data);
            });
            */

            //https://stackoverflow.com/questions/43462367/how-to-overcome-the-cors-issue-in-reactjs
            axios.get(url).then((response) => {
              setDebug(response.data);
              //const matches = response.data.matchAll(regex);
              //const matches3 = Array.from(matches, x => x[1]);
              const matches3 = [...response.data.matchAll(regex)];
              setDebug2(matches3.toString());
              var result = [];   var result2 = [];
              for (var i = 0; i < matches3.length; i++) {
                var str1 = matches3[i][1].match(regex2);
                var str2 = str1[1].replace('www.', '');

                result.push(str2);
                if (str2==domain) { result2.push(i); }
                console.log(str2);
              }
              setDebug3( result.toString().replaceAll(',' , '\n') );
              setRank(result2[0] + 1);
            });

          } }
        />
        <Button
          title="Regex"
          onPress={() => {
            const regexp = /t(e)(st(\d?))/g;
            const str = 'test1test2';
            const array = [...str.matchAll(regexp)];
            console.log(array);
          }}
        />
        <View style={style.row}>
        <Text>Rank</Text>
        <TextInput style={{ width: 100, borderWidth: 1 }} value={rank} />
        </View>

      <Text style={{ marginTop: 50 }} >Debug data:</Text>
      <TextInput style={{ height: 250, borderWidth: 1 }} value={debug} multiline={true} />
      <TextInput style={{ height: 250, borderWidth: 1 }} value={debug2} multiline={true} />
      <TextInput style={{ height: 250, borderWidth: 1 }} value={debug3} multiline={true} />

    </ScrollView>
  );
}

function ServiceScreen() {
  return (
    <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
      <Text>Details!</Text>
    </View>
  );
}

function DetailsScreen() {
  return (
    <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
      <Text>Details!</Text>
    </View>
  );
}

function AddScreen() {
  return (
    <View style={style.container}>
      <Text>Domain</Text>
      <TextInput
        style={style.input}
        />
      <Text>Locale</Text>
      <TextInput
        style={style.input}
        />
      <Text>Keywords (separate with ,)</Text>
      <TextInput
        style={style.input}
        />
      <Button
          title="Add"
          onPress={() => alert('Added') }
        />
    </View>
  );
}

function HomeScreen({ navigation }) {
  return (
    <View style={style.container}>
      <View style={style.row}>
      <Button
          title="Demo: rank"
          onPress={() => navigation.navigate('Ranking')}
        />
        <Button
          title="Demo: background"
          onPress={() => navigation.navigate('Service') }
        />
        <Button
          title="Details"
          onPress={() => navigation.navigate('Details')}
        />
        <Button
          title="Add"
          onPress={() => navigation.navigate('Add')}
        />
      </View>

      <SectionList
          sections={DATA}
          keyExtractor={(item, index) => item + index}
          renderItem={({ item }) => <Item title={item} />}
          renderSectionHeader={({ section: { title } }) => (
            <Text style={style.header}>{title}</Text>
          )}
        />
    </View>
  );
}

const HomeStack = createNativeStackNavigator();

function HomeStackScreen() {
  return (
    <HomeStack.Navigator>
      <HomeStack.Screen name="Home" component={HomeScreen} />
      <HomeStack.Screen name="Details" component={DetailsScreen} />
      <HomeStack.Screen name="Add" component={AddScreen} />
      <HomeStack.Screen name="Ranking" component={RankScreen} />
      <HomeStack.Screen name="Service" component={ServiceScreen} />
    </HomeStack.Navigator>
  );
}


export default class Home extends React.Component {
  render() {
    return (
        <HomeStackScreen />
    );
  }
}
