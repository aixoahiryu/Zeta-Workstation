import React, { useState } from 'react';
import { StyleSheet, Text, View, TouchableOpacity, Switch, TextInput } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';

import style from '../../src/config/style';

const Settings = () =>  {
  const [isEnabled, setIsEnabled] = useState( async () => {
        AsyncStorage.getItem('background-enabled').then( (data) => setIsEnabled(JSON.parse(data)) );
      } );
  const toggleSwitch = async () => {
    const updated = !isEnabled;
    await AsyncStorage.setItem('background-enabled', JSON.stringify(updated) );
    setIsEnabled(updated);
  }

  const [number, setNumber] = useState( async () => {
        AsyncStorage.getItem('background-hour').then( (data) => setNumber(parseInt(data) ) );
      } );


  const [isDark, setIsDark] = useState( async () => {
        AsyncStorage.getItem('darkmode-enabled').then( (data) => setIsDark(JSON.parse(data)) );
      } );
  const toggleDark = async () => {
    const updated = !isDark;
    await AsyncStorage.setItem('darkmode-enabled', JSON.stringify(updated) );
    setIsDark(updated);
  }


  const onPressImport = () => {
    alert('import');
  }

  const onPressExport = () => {
    alert('export');
  }

  const onPressDelete = () => {
    AsyncStorage.clear();
    alert('Storage successfully cleared!');
  }

    return (
      <View style={style.container}>

        <View style={style.row}>
          <Text>Background check</Text>
          <Switch
          trackColor={{ false: "#767577", true: "#81b0ff" }}
          thumbColor={isEnabled ? "#f5dd4b" : "#f4f3f4"}
          ios_backgroundColor="#3e3e3e"
          onValueChange={toggleSwitch}
          value={isEnabled}
          />
        </View>

        <Text>Time: (24-hours)</Text>
        <TextInput
        style={style.input}
        onChangeText={ (data) => {
          setNumber(data);
          AsyncStorage.setItem('background-hour', data.toString() );
        } }
        value={number}
        placeholder="(24 hours time)"
        keyboardType="numeric"
        />

        <View style={style.row}>
          <Text>Dark mode</Text>
          <Switch
          trackColor={{ false: "#767577", true: "#81b0ff" }}
          thumbColor={isDark ? "#f5dd4b" : "#f4f3f4"}
          ios_backgroundColor="#3e3e3e"
          onValueChange={toggleDark}
          value={isDark}
          />
        </View>

        <TouchableOpacity
                  onPress={onPressImport}
                  style={{
                    flexDirection: 'row',
                    paddingVertical: 5,
                    alignItems: 'center',
                  }}>
                  <Text style={{fontSize: 17, paddingLeft: 15}}>
                    Import data
                  </Text>
                </TouchableOpacity>
        <TouchableOpacity
                  onPress={onPressExport}
                  style={{
                    flexDirection: 'row',
                    paddingVertical: 5,
                    alignItems: 'center',
                  }}>
                  <Text style={{fontSize: 17, paddingLeft: 15}}>
                    Export data
                  </Text>
        </TouchableOpacity>
        <TouchableOpacity
                  onPress={onPressDelete}
                  style={{
                    flexDirection: 'row',
                    paddingVertical: 5,
                    alignItems: 'center',
                  }}>
                  <Text style={{fontSize: 17, paddingLeft: 15}}>
                    Delete all data
                  </Text>
        </TouchableOpacity>

      </View>
    );
}

export default Settings;