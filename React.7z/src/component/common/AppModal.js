import React from 'react';
import {View, TouchableOpacity, Text, Modal, ScrollView} from 'react-native';
import PropTypes from 'prop-types';

import Icon from '../../../src/config/icon';
import style from '../../../src/config/style';

const AppModal = ({
  modalVisible,
  modalFooter,
  modalBody,
  title,
  setModalVisible,
  closeOnTouchOutside,
}) => {
  return (
    <Modal visible={modalVisible} transparent>
      <TouchableOpacity
        onPress={() => {
          if (closeOnTouchOutside) {
            setModalVisible(false);
          }
        }}
        style={style.wrapper}>
        <View style={style.modalView}>
          <ScrollView>
            <View style={style.header}>
              <TouchableOpacity
                onPress={() => {
                  setModalVisible(false);
                }}>
                <Icon size={27} type="evil" name="close" />
              </TouchableOpacity>
              <Text style={style.title}>{title || 'RNContacts'}</Text>

              <View />
              <View />
              <View />
              <View />
              <View />
            </View>
            <View style={style.footerSeparator} />

            <View style={style.body}>{modalBody}</View>
            {modalFooter}

            {!modalFooter && (
              <View>
                <>
                  <View style={style.footerSeparator} />
                  <View style={style.footerItems}>
                    <View style={style.footer}>
                      <Text style={style.footerText}>Privacy Policy</Text>
                      <View style={style.termsView} />
                      <Text style={style.footerText}>Terms of Service</Text>
                    </View>
                  </View>
                </>
              </View>
            )}
          </ScrollView>
        </View>
      </TouchableOpacity>
    </Modal>
  );
};

AppModal.propTypes = {
  closeOnTouchOutside: PropTypes.bool,
};

AppModal.defaultProps = {
  closeOnTouchOutside: true,
};

export default AppModal;
