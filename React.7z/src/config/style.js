import {StyleSheet} from 'react-native';
import color from './color';

export default StyleSheet.create({
  container: {
    flex: 1,
    marginVertical: 15,
    marginHorizontal: 15,
  },
  title: {
    fontSize: 24,
  },
  item: {
    padding: 20,
    marginVertical: 8
  },
  header: {
    fontSize: 32,
    flexDirection: 'row',
    padding: 15,
    alignItems: 'center',
    width: '100%',
    justifyContent: 'space-between',
  },
  row: {
  	flexDirection: 'row',
  	justifyContent: 'space-between',
  },
  input: {
    height: 40,
    margin: 12,
    borderWidth: 1,
    padding: 10,
  },
  
  wrapper: {
    backgroundColor: 'rgba(0,0,0,0.6)',
    flex: 1,
    justifyContent: 'center',
  },

  modalView: {
    backgroundColor: color.white,
    marginHorizontal: 20,
    borderRadius: 4,
    minHeight: 300,
  },

  body: {
    minHeight: 300,
    paddingHorizontal: 20,
    paddingVertical: 10,
  },

  footer: {
    justifyContent: 'space-evenly',
    paddingVertical: 7,
    alignItems: 'center',
    flexDirection: 'row',
  },

  termsView: {
    width: 5,
    height: 5,
    borderRadius: 100,
    backgroundColor: color.grey,
  },

  footerSeparator: {
    height: 0.5,
    backgroundColor: color.grey,
  },

  footerItems: {
    width: '100%',
    padding: 10,
  },

  footerText: {
    fontSize: 12,
  },
});