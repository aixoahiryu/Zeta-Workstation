import React, { useState } from 'react';
import { Platform } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import axios from 'axios';

/*let GoogleRank = new Promise(function(Resolve, Reject) {


  Resolve();
  Reject();
});*/

const GoogleRank = (domain, locale, keyword) =>  {
	//https://www.google.com/search?q=example&num=100&nfpr=1
            //const url = 'https://www.google.com' + locale + '/search?q=' + keyword + '&num=100&nfpr=1'
            //const url = 'https://cors-anywhere.herokuapp.com/https://www.google.com' + locale + '/search?q=' + keyword + '&num=100&nfpr=1'
            const url = 'https://zeta-cors.herokuapp.com/https://www.google.com' + locale + '/search?q=' + keyword + '&num=100&nfpr=1'
            //const url = 'https://textbin.net/raw/g75tkkliiu'
            //const url = 'https://cors-anywhere.herokuapp.com/https://textbin.net/raw/g75tkkliiu'
            
            //const regex = /class=\"rc(.*?)class=\"r\"(.*?)<a\\shref=\"([^\"]*?)\"\\sping/g
            //const regex = /https?:\/\/(?:www\.)?/g
            //const regex = /^https?\:\/\/([^\/?#]+)(?:[\/?#]|$)/gi
            //const regex  = /#<h3.*?><a href="(.*?)".*?<\/h3>#/g
            //const regex = /^https?\:\/\/([^\/:?#]+)(?:[\/:?#]|$)/gi
            //const regex = /<div class="[^"]*?yuRUbf[^"]*?">(.*?)<\/div>/g
            //const regex = /<div class="[^"]*?yuRUbf[^"]*?">(.*?)data\-ved\=/g
            //const regexg = /<div class="[^"]*?yuRUbf[^"]*?">(.*?)data\-ved\=/
            const regex = /yuRUbf(.*?)data\-ved\=/g
            const regexg = /yuRUbf(.*?)data\-ved\=/
            //var regexA = new RegExp("kCrYT(.*?)\"><h3", "g");
            //const regexA = /egMi0 kCrYT(.*?)\"><h3/g
            //const regexA = /\<a href=\"\/url\?q\=(.*?)\"><h3/g
            const regexA = /kCrYT\"><a href=\"\/url\?q\=(.*?)\"><h3/g
            //const regex2 = /https?\:\/\/www.([^\/:?#]+)(?:[\/:?#]|$)/
            const regex2 = /([^\/:?#]+)/g
            //const regex2 = /((?!-))(xn--)?[a-z0-9][a-z0-9-_]{0,61}[a-z0-9]{0,1}\.(xn--)?([a-z0-9\-]{1,61}|[a-z0-9-]{1,30}\.[a-z]{2,})/
            //const regex2 = /[a-zA-Z0-9][a-zA-Z0-9-]{1,61}[a-zA-Z0-9]\.[a-zA-Z]{2,}/

            /*
            fetch(url)
            .then( (data) => {
              return data.text();
              console.log(data);
            } )
            .then( (data) => {
              setDebug(data.toString());
              console.log(data);
            } )
            .catch(e => { console.log(e); });

            axios.get(url).then((response) => {
              setDebug(response.data);
            });
            */

            //https://stackoverflow.com/questions/43462367/how-to-overcome-the-cors-issue-in-reactjs
            let config = {
              headers: {
                'X-Requested-With': 'XMLHttpRequest',
              }
            }

            axios.get( encodeURI(url), config ).then((response) => {
			 /*const matches = response.data.matchAll(regex);
              const matches3 = Array.from(matches, x => x[1]);*/
              //matches3 = [...response.data.matchAll(regex)];
              //matches3 = [...matchAll(response.data, regex)];
              /*var match_result = response.data.match(regex);
               for (let index in match_result){
                 var item = match_result[index];
                 matches3[index] = item.match(new RegExp(regexg));
               }*/
              var matches3 = [];
              if (Platform.OS === 'android' || Platform.OS === 'ios'){
                const teststr = response.data.substr(0, response.data.length);
                console.log(response.data.substr(response.data.indexOf('data-ved')-1000, 1000));
                console.log('length: '+response.data.length);
                console.log('</body>: '+response.data.indexOf('</body>'));
                console.log('yuRUbf: '+response.data.indexOf('yuRUbf'));
                console.log('kCrYT: '+response.data.indexOf('kCrYT'));
                console.log('data-ved: '+response.data.indexOf('data-ved'));
                console.log(response.data.match(regexA));

                var match_result = response.data.match(regexA);
                for (let index in match_result){
                  var item = match_result[index];
                  matches3[index] = item.match(new RegExp(regexA));
                }
              }
              else { matches3 = [...response.data.matchAll(regex)]; }

              var result = [];   var result2 = [];
              for (var i = 0; i < matches3.length; i++) {
                var str1='';    var str2='';
                str1 = matches3[i][0].match(regex2);
                if (Platform.OS === 'android'){ str2 = str1[3].replace('www.', ''); }
                else { str2 = str1[1].replace('www.', ''); }

                result.push(str2);
                if (str2==domain) { result2.push(i); }
              }

              console.log( 'rank: '+(result2[0] + 1) );
              AsyncStorage.getItem(domain).then( (data) => {
              	const data1 = JSON.parse(data);
              	for(var i2=0; i2<data1.keywords.length; i2++){
		          if ( data1.keywords[i2].keyword == keyword ) {
		          	if(result2[0] == null) { data1.keywords[i2].rank.push(0); }
		          	else { data1.keywords[i2].rank.push(result2[0] + 1); }
		            AsyncStorage.setItem(domain, JSON.stringify(data1));
		          }
		         }
              })
            })
            .catch((error) => { console.log(error); });
}

export default GoogleRank;