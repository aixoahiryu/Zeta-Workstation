.. default-domain:: py
.. currentmodule:: natsort

.. _examples:

Examples and Recipes
====================

This page has been moved to the
`natsort wiki <https://github.com/SethMMorton/natsort/wiki/How-Does-Natsort-Work%3F>`_.
