.. default-domain:: py
.. currentmodule:: natsort

.. _shell:

Shell Script
============

This page has been moved to the
`natsort wiki <https://github.com/SethMMorton/natsort/wiki/Shell-Script>`_.
