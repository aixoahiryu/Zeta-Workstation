.. _changelog:

Changelog
=========

Please visit https://github.com/SethMMorton/natsort/blob/main/CHANGELOG.md.
