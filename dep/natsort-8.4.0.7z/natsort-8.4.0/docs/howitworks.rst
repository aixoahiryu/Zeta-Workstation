.. default-domain:: py
.. currentmodule:: natsort

.. _howitworks:

How Does Natsort Work?
======================

This page has been moved to the
`natsort wiki <https://github.com/SethMMorton/natsort/wiki/How-Does-Natsort-Work%3F>`_.

Special Cases Everywhere!
-------------------------

This page has been
`moved as well <https://github.com/SethMMorton/natsort/wiki/How-Does-Natsort-Work%3F#special-cases-everywhere>`_.
