.. default-domain:: py
.. currentmodule:: natsort

.. _locale_issues:

Possible Issues with :func:`~natsort.humansorted` or ``ns.LOCALE``
==================================================================

This page has been moved to the
`natsort wiki <https://github.com/SethMMorton/natsort/wiki/Possible-Issues-with-natsort.humansorted-or-ns.LOCALE>`_.
