import Zeta


antifragment = True
antiflicker = False

module = {'panel': True}
module['image'] = True
module['dragdrop'] = False
module['hotkey'] = False
module['raw'] = True


class Editor():
	pass

class Browser():
	pass

class OS():
	pass