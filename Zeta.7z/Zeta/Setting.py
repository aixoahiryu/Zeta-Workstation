import Zeta


antifragment = True
antiflicker = False
lazyload = True
opacity = 0.77
opacityneon = 0.88

module = {'panel': True}
module['image'] = True
module['dragdrop'] = False
module['hotkey'] = False
module['raw'] = True


class Editor():
	pass

class Browser():
	pass

class OS():
	pass