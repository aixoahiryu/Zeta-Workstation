import Zeta


antifragment = True
antiflicker = False

module = {'panel': True}
module['image'] = True
module['dragdrop'] = False
module['hotkey'] = False
module['raw'] = True


class Editor():
    def __init__(self):
        pass

class Browser():
    def __init__(self):
        pass

class OS():
    def __init__(self):
        pass