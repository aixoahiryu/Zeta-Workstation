def read(path):
	with open(path, 'r+', encoding='utf-8') as target:
		content = target.read()
	return content