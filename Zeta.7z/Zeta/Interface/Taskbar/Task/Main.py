import Zeta
from Zeta.Panel import *

class Task(Toplevel):
	def __init__(self, *args, **kwargs):
		Toplevel.__init__(self, *args, **kwargs)
		self.attributes('-topmost', True)
		self.attributes('-alpha', Zeta.Setting.opacityneon)
		# self.geometry(f"150x25+0-{Zeta.System.Size.taskbar}")
		self.geometry(f"+0-{Zeta.System.Size.taskbar}")
		self.overrideredirect(1)

		appframe = Frame(self)
		appframe.pack(side='left', fill='y')
		Button2(appframe, text='Mind', relief='flat', side='left', fill='y', geometry='top', listdir=True, path='<X>/Matter/Filter/Mind')
		Button2(appframe, text='File', relief='flat', side='left', fill='y', geometry='top', listdir=True, path='<X>/Matter/Filter/File')
		Button2(appframe, text='Network', relief='flat', side='left', fill='y', geometry='top', listdir=True, path='<X>/Matter/Filter/Network')

		self.theme(self, bg=Workspace.color.hue, fg=Workspace.color.hex)