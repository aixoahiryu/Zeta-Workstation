import Zeta
from Zeta.Panel import *

class Task2(Toplevel):
	def __init__(self, *args, **kwargs):
		Toplevel.__init__(self, *args, **kwargs)
		self.attributes('-topmost', True)
		self.attributes('-alpha', Zeta.Setting.opacityneon)
		self.geometry(f"30x25+0+0")
		self.overrideredirect(1)

		appframe = Frame(self)
		appframe.pack(side='left', fill='y')
		Button2(appframe, text='Tab', relief='flat', side='left', fill='y', geometry='bottom', listdir=True, path='<Scraps>/tab/# Commit')

		self.theme(self, bg=Workspace.color.hue, fg=Workspace.color.hex)