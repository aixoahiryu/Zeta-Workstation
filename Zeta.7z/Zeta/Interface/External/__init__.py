from .File.Main import File
from .Lounge.Main import Lounge
from .Network.Search.Main import Search

from .Taskbar.Main import Taskbar
from .Taskbar2.Main import Taskbar2
from .Switcher.Main import Switcher
from .Wallpaper.Main import Wallpaper

from .sidebarext import Sidebar