import Zeta

from Zeta.Panel import *
import os
import subprocess

class Camp(Window):
	def __init__(self, *args, **kwargs):
		Window.__init__(self, mode='border', color2='green', *args, **kwargs)
		bottom = Zeta.System.Size.taskbar
		self.geometry(f'+{25+10}-{bottom}')
		self.attributes('-topmost', True)
		self.attributes('-alpha', Zeta.Setting.opacityneon)
		self.imghdd=Zeta.Image.Icon.Load(icon='hddw', icontype='bw').image
		self.corner=Zeta.Image.Icon.Load(icon='cornerw', icontype='bw').image
		self.InitWindow()

		Button2(self.frame, text=' Camp', image=self.imghdd, compound='left', side='left', fill='y', hover=self._Camp, toggle=self._Camp, geometry='top')
		Button2(self.frame, text=' Lounge', image=self.imghdd, compound='left', side='left', fill='y', hover=self._Lounge, toggle=self._Lounge, geometry='top')
		Button2(self.frame, text=' Study', image=self.imghdd, compound='left', side='left', fill='y', hover=self._Study, toggle=self._Study, geometry='top')
		Frame(self.frame, highlightbackground=self.neon, highlightthickness=1).pack(side='left', fill='y')
		Button2(self.frame, text=' Base', image=self.imghdd, compound='left', side='left', fill='y', hover=self._Base, toggle=self._Base, geometry='top')
		Button2(self.frame, text=' Survival', image=self.imghdd, compound='left', side='left', fill='y', hover=self._Survival, toggle=self._Survival, geometry='top')
		Button2(self.frame, text=' Strategy', image=self.imghdd, compound='left', side='left', fill='y', hover=self._Strategy, toggle=self._Strategy, geometry='top')
		Button2(self.frame, text=' Adventure', image=self.imghdd, compound='left', side='left', fill='y', hover=self._Adventure, toggle=self._Adventure, geometry='top')
		Frame(self.frame, highlightbackground=self.neon, highlightthickness=1).pack(side='left', fill='y')

		self.theme(self.frame, bg=self.hue, fg='#ffffff')

	def InitWindow(self):
		x = Window(mode='border', color2='green')
		x.attributes('-topmost', True)
		x.attributes('-alpha', Zeta.Setting.opacityneon)
		Button(x.frame, text=' Project Aego', relief='flat', image=self.corner, compound='left', anchor='w').pack(side='top', fill='x')
		Button(x.frame, text=' Stranded', relief='flat', image=self.corner, compound='left', anchor='w').pack(side='top', fill='x')
		Button(x.frame, text=' The Smoke Room', relief='flat', image=self.corner, compound='left', anchor='w').pack(side='top', fill='x')
		Frame(x.frame, highlightbackground=self.neon, highlightthickness=1).pack(side='top', fill='x')
		Button(x.frame, text=' Tent', relief='flat', image=self.corner, compound='left', anchor='w').pack(side='top', fill='x')
		Button(x.frame, text=' Stealth', relief='flat', image=self.corner, compound='left', anchor='w').pack(side='top', fill='x')
		Button(x.frame, text=' Desert', relief='flat', image=self.corner, compound='left', anchor='w').pack(side='top', fill='x')
		Frame(x.frame, highlightbackground=self.neon, highlightthickness=1).pack(side='top', fill='x')
		x.theme(x.frame, fg='#ffffff', bg=x.hue)
		self._Camp = x

		x = Window(mode='border', color2='green')
		x.attributes('-topmost', True)
		x.attributes('-alpha', Zeta.Setting.opacityneon)
		Button(x.frame, text=' Polar night', relief='flat', image=self.corner, compound='left', anchor='w').pack(side='top', fill='x')
		Button(x.frame, text=' Machina Lutris', relief='flat', image=self.corner, compound='left', anchor='w').pack(side='top', fill='x')
		Button(x.frame, text=' Lackadaisy', relief='flat', image=self.corner, compound='left', anchor='w').pack(side='top', fill='x')
		Frame(x.frame, highlightbackground=self.neon, highlightthickness=1).pack(side='top', fill='x')
		Button(x.frame, text=' No Umbrellas Allowed', relief='flat', image=self.corner, compound='left', anchor='w').pack(side='top', fill='x')
		Button(x.frame, text=' Strange Horticulture', relief='flat', image=self.corner, compound='left', anchor='w').pack(side='top', fill='x')
		Button(x.frame, text=' Potion craft', relief='flat', image=self.corner, compound='left', anchor='w').pack(side='top', fill='x')
		Frame(x.frame, highlightbackground=self.neon, highlightthickness=1).pack(side='top', fill='x')
		x.theme(x.frame, fg='#ffffff', bg=x.hue)
		self._Lounge = x

		x = Window(mode='border', color2='green')
		x.attributes('-topmost', True)
		x.attributes('-alpha', Zeta.Setting.opacityneon)
		Button(x.frame, text=' Intertwined', relief='flat', image=self.corner, compound='left', anchor='w').pack(side='top', fill='x')
		Frame(x.frame, highlightbackground=self.neon, highlightthickness=1).pack(side='top', fill='x')
		Button(x.frame, text=' City', relief='flat', image=self.corner, compound='left', anchor='w').pack(side='top', fill='x')
		Button(x.frame, text=' Masion', relief='flat', image=self.corner, compound='left', anchor='w').pack(side='top', fill='x')
		Button(x.frame, text=' Library', relief='flat', image=self.corner, compound='left', anchor='w').pack(side='top', fill='x')
		Button(x.frame, text=' Greenhouse', relief='flat', image=self.corner, compound='left', anchor='w').pack(side='top', fill='x')
		Button(x.frame, text=' Conservatory', relief='flat', image=self.corner, compound='left', anchor='w').pack(side='top', fill='x')
		Frame(x.frame, highlightbackground=self.neon, highlightthickness=1).pack(side='top', fill='x')
		x.theme(x.frame, fg='#ffffff', bg=x.hue)
		self._Study = x

		x = Window(mode='border', color2='green')
		x.attributes('-topmost', True)
		x.attributes('-alpha', Zeta.Setting.opacityneon)
		Button(x.frame, text=' This war of mine', relief='flat', image=self.corner, compound='left', anchor='w').pack(side='top', fill='x')
		Button(x.frame, text=' Don\'t starve', relief='flat', image=self.corner, compound='left', anchor='w').pack(side='top', fill='x')
		Button(x.frame, text=' Sunless Sea', relief='flat', image=self.corner, compound='left', anchor='w').pack(side='top', fill='x')
		Button(x.frame, text=' Frostpunk', relief='flat', image=self.corner, compound='left', anchor='w').pack(side='top', fill='x')
		Frame(x.frame, highlightbackground=self.neon, highlightthickness=1).pack(side='top', fill='x')
		Button(x.frame, text=' Beholder', relief='flat', image=self.corner, compound='left', anchor='w').pack(side='top', fill='x')
		Button(x.frame, text=' Papers, please', relief='flat', image=self.corner, compound='left', anchor='w').pack(side='top', fill='x')
		Button(x.frame, text=' Do Not Feed the Monkeys', relief='flat', image=self.corner, compound='left', anchor='w').pack(side='top', fill='x')
		Frame(x.frame, highlightbackground=self.neon, highlightthickness=1).pack(side='top', fill='x')
		Button(x.frame, text=' Welcome to the game', relief='flat', image=self.corner, compound='left', anchor='w').pack(side='top', fill='x')
		Button(x.frame, text=' Hypnospace outlaw', relief='flat', image=self.corner, compound='left', anchor='w').pack(side='top', fill='x')
		Frame(x.frame, highlightbackground=self.neon, highlightthickness=1).pack(side='top', fill='x')
		x.theme(x.frame, fg='#ffffff', bg=x.hue)
		self._Base = x

		x = Window(mode='border', color2='green')
		x.attributes('-topmost', True)
		x.attributes('-alpha', Zeta.Setting.opacityneon)
		Button(x.frame, text=' NEO scavenger', relief='flat', image=self.corner, compound='left', anchor='w').pack(side='top', fill='x')
		Button(x.frame, text=' Cataclysm: Dark Days Ahead', relief='flat', image=self.corner, compound='left', anchor='w').pack(side='top', fill='x')
		Frame(x.frame, highlightbackground=self.neon, highlightthickness=1).pack(side='top', fill='x')
		Button(x.frame, text=' The long dark', relief='flat', image=self.corner, compound='left', anchor='w').pack(side='top', fill='x')
		Button(x.frame, text=' The forest | Green hell', relief='flat', image=self.corner, compound='left', anchor='w').pack(side='top', fill='x')
		Frame(x.frame, highlightbackground=self.neon, highlightthickness=1).pack(side='top', fill='x')
		x.theme(x.frame, fg='#ffffff', bg=x.hue)
		self._Survival = x

		x = Window(mode='border', color2='green')
		x.attributes('-topmost', True)
		x.attributes('-alpha', Zeta.Setting.opacityneon)
		Button(x.frame, text=' Inscryption', relief='flat', image=self.corner, compound='left', anchor='w').pack(side='top', fill='x')
		Button(x.frame, text=' Loop hero', relief='flat', image=self.corner, compound='left', anchor='w').pack(side='top', fill='x')
		Frame(x.frame, highlightbackground=self.neon, highlightthickness=1).pack(side='top', fill='x')
		x.theme(x.frame, fg='#ffffff', bg=x.hue)
		self._Strategy = x

		x = Window(mode='border', color2='green')
		x.attributes('-topmost', True)
		x.attributes('-alpha', Zeta.Setting.opacityneon)
		Button(x.frame, text=' Faith', relief='flat', image=self.corner, compound='left', anchor='w').pack(side='top', fill='x')
		Button(x.frame, text=' WORLD OF HORROR', relief='flat', image=self.corner, compound='left', anchor='w').pack(side='top', fill='x')
		Button(x.frame, text=' Termina', relief='flat', image=self.corner, compound='left', anchor='w').pack(side='top', fill='x')
		Frame(x.frame, highlightbackground=self.neon, highlightthickness=1).pack(side='top', fill='x')
		x.theme(x.frame, fg='#ffffff', bg=x.hue)
		self._Adventure = x