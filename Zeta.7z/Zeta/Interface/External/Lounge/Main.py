import Zeta

from Zeta.Panel import *
import os
import subprocess

ZLCORE = Zeta.System.Path.Core.ZLCORE

class Lounge(Window):
	def __init__(self, *args, **kwargs):
		Window.__init__(self, mode='border', color2='white', *args, **kwargs)
		self.title('===[ Sidebar: File ]===')
		self.attributes('-topmost', True)
		self.attributes('-alpha', 0.77)
		width = Zeta.System.Size.Window.mpv[0] - 1
		height = Zeta.System.Size.Window.mpv[1]
		bottom = Zeta.System.Size.taskbar
		self.geometry(f"{width}x{height}-1-{bottom}")

		notebook = Notebook(self.frame)
		notebook.enable_traversal()
		notebook.pack(fill='both')
		frame1 = Frame(notebook)
		frame2 = Frame(notebook)
		frame1.pack(fill='both')
		frame2.pack(fill='both')

		notebook.add(frame1, text='Video')
		notebook.add(frame2, text='Audio')

		Button(frame1, text='Temp').pack()
		Button(frame1, text='MV').pack()
		Button(frame2, text='MP3').pack()

		self.hide()
		self.theme(self.frame, bg='#000000', fg='#ffffff')