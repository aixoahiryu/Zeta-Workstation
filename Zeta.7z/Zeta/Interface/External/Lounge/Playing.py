import Zeta

from Zeta.Panel import *
import os
import subprocess

class Playing(Window):
	def __init__(self, *args, **kwargs):
		Window.__init__(self, mode='border', color2='green', *args, **kwargs)
		self.geometry('-10+25')
		self.attributes('-topmost', True)
		self.attributes('-alpha', Zeta.Setting.opacityneon)
		self.imghdd=Zeta.Image.Icon.Load(icon='hddw', icontype='bw').image
		self.corner=Zeta.Image.Icon.Load(icon='cornerw', icontype='bw').image
		self.InitWindow()

		Button2(self.frame, text='+', image=self.corner, side='right', fill='y', hover=self._Play, toggle=self._Play, geometry='bottom')
		Frame(self.frame, highlightbackground=self.neon, highlightthickness=1).pack(side='right', fill='y')

		self.theme(self.frame, bg=self.hue, fg='#ffffff')

	def InitWindow(self):
		x = Window(mode='border', color2='green')
		x.attributes('-topmost', True)
		x.attributes('-alpha', Zeta.Setting.opacityneon)
		Button(x.frame, text=' Audio', relief='flat', image=self.corner, compound='left', anchor='w').pack(side='top', fill='x')
		Button(x.frame, text=' Video', relief='flat', image=self.corner, compound='left', anchor='w').pack(side='top', fill='x')
		Button(x.frame, text=' Image', relief='flat', image=self.corner, compound='left', anchor='w').pack(side='top', fill='x')
		Frame(x.frame, highlightbackground=self.neon, highlightthickness=1).pack(side='top', fill='x')
		x.theme(x.frame, fg='#ffffff', bg=x.hue)
		self._Play = x