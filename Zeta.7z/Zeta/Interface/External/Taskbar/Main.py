import Zeta
from Zeta.Panel import *
from .Overflow import Overflow

import os

ZLCORE = Zeta.System.Path.Core.ZLCORE

class Taskbar(Toplevel):
	def __init__(self, Workspace, *args, **kwargs):
		Toplevel.__init__(self, *args, **kwargs)
		self.attributes('-topmost', True)
		self.attributes('-alpha', 0.77)
		self.title('Task bar')
		width = Zeta.System.Size.Screen.width
		height = 25
		self.geometry(f"{width}x{height}+1+0")
		self.overrideredirect(1)
		#self.configure(bg=colorbg, bd=1, relief='groove')
		Label(self, text=r'[ Workspace ]').place(relx=0.48, rely=0)

		appframe = Frame(self)
		appframe.grid(sticky='NSW', column=0, row=0)
		#Button(appframe, text='1', relief='flat', background='#3c3c3c').grid(column=0, row=0, sticky='NW')
		Button(appframe, text='1', relief='flat', foreground='#6effbe').grid(column=0, row=0, sticky='NW')
		Button(appframe, text='2', relief='flat').grid(column=1, row=0, sticky='NW')
		Button(appframe, text='3', relief='flat').grid(column=2, row=0, sticky='NW')
		Button(appframe, text='4', relief='flat').grid(column=3, row=0, sticky='NW')
		Button(appframe, text='#', relief='flat').grid(column=4, row=0, sticky='NW')
		self.imgcode=Zeta.Image.Icon.Load(icon='code', icontype='neon').image
		Button(appframe, text=' Program', relief='flat', image=self.imgcode, compound='left').grid(column=5, row=0, sticky='NW')
		self.imgterm=Zeta.Image.Icon.Load(icon='term3', icontype='neon').image
		Button(appframe, text=' Hacking', relief='flat', image=self.imgterm, compound='left').grid(column=6, row=0, sticky='NW')
		self.imgfile=Zeta.Image.Icon.Load(icon='file', icontype='neon').image
		Button(appframe, text=' File', relief='flat', foreground='#6effbe', image=self.imgfile, compound='left').grid(column=7, row=0, sticky='NW')
		self.imglink=Zeta.Image.Icon.Load(icon='qr', icontype='neon').image
		Button(appframe, text=' Network', relief='flat', image=self.imglink, compound='left').grid(column=8, row=0, sticky='NW')
		
		trayframe = Frame(self)
		trayframe.grid(sticky='NSE', column=1, row=0)
		self.grid_columnconfigure(1, weight=1)
		self.imgcpu=Zeta.Image.Icon.Load(icon='cpuw', icontype='bw').image
		Button(trayframe, text=' 13%', relief='flat', image=self.imgcpu, compound='left').grid(column=0, row=0, sticky='NW')
		self.imghdd=Zeta.Image.Icon.Load(icon='hddw', icontype='bw').image
		Button(trayframe, text=' 322G', relief='flat', image=self.imghdd, compound='left').grid(column=1, row=0, sticky='NW')
		self.imgnetwork=Zeta.Image.Icon.Load(icon='networkw', icontype='bw').image
		Button(trayframe, text=' 0.7 MB/s', relief='flat', image=self.imgnetwork, compound='left').grid(column=2, row=0, sticky='NW')
		self.imgram=Zeta.Image.Icon.Load(icon='ramw', icontype='bw').image
		Button(trayframe, text=' 2.2 GB', relief='flat', image=self.imgram, compound='left').grid(column=3, row=0, sticky='NW')
		self.imgtemp=Zeta.Image.Icon.Load(icon='tempw', icontype='bw').image
		Button(trayframe, text=' 33°C', relief='flat', image=self.imgtemp, compound='left').grid(column=4, row=0, sticky='NW')
		self.imgvolume=Zeta.Image.Icon.Load(icon='volumew', icontype='bw').image
		Button(trayframe, text=' Ballad', relief='flat', image=self.imgvolume, compound='left').grid(column=5, row=0, sticky='NW')
		self.imgmenu=Zeta.Image.Icon.Load(icon='menuw', icontype='bw').image
		
		overflow = Overflow()
		btnoverflow = Button(trayframe, text='', relief='flat', image=self.imgmenu, compound='none')
		btnoverflow.grid(column=6, row=0, sticky='NW')
		Workspace.toggle_bind(btnoverflow, overflow)

		self.theme(self, bg='#000000', fg='#ffffff')


if __name__ == "__main__":
    app = Taskbar()
    app.mainloop()