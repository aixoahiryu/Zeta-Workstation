import Zeta
from Zeta.Panel import *

class FileMenu(Window):
	def __init__(self, *args, **kwargs):
		Window.__init__(self, mode='border', color2='green', *args, **kwargs)
		self.attributes('-topmost', True)
		self.attributes('-alpha', 0.77)

		self.imggemini=Zeta.Image.Icon.Load(icon='geminiw', icontype='bw').image
		Button(self.frame, text=' Thaumiel', relief='flat', image=self.imggemini, compound='left', anchor='w').pack(side='top', fill='x')
		self.imgeye=Zeta.Image.Icon.Load(icon='eyew', icontype='bw').image
		Button(self.frame, text=' The eye', relief='flat', image=self.imgeye, compound='left', anchor='w').pack(side='top', fill='x')
		self.imgmoon=Zeta.Image.Icon.Load(icon='moonw', icontype='bw').image
		Button(self.frame, text=' Moon cycle', relief='flat', image=self.imgmoon, compound='left', anchor='w').pack(side='top', fill='x')
		self.imgsun=Zeta.Image.Icon.Load(icon='sunw', icontype='bw').image
		Button(self.frame, text=' Sun cycle', relief='flat', image=self.imgsun, compound='left', anchor='w').pack(side='top', fill='x')
		self.imgdice=Zeta.Image.Icon.Load(icon='dicew', icontype='bw').image
		Button(self.frame, text=' Chaos theory', relief='flat', image=self.imgdice, compound='left', anchor='w').pack(side='top', fill='x')
		self.imgcalendar=Zeta.Image.Icon.Load(icon='calendarw', icontype='bw').image
		Button(self.frame, text=' Calendar', relief='flat', image=self.imgcalendar, compound='left', anchor='w').pack(side='top', fill='x')
		self.imghorse=Zeta.Image.Icon.Load(icon='horsew', icontype='bw').image
		Button(self.frame, text=' Strategy', relief='flat', image=self.imghorse, compound='left', anchor='w').pack(side='top', fill='x')
		self.imgwave=Zeta.Image.Icon.Load(icon='wave2w', icontype='bw').image
		Button(self.frame, text=' Flunctuation', relief='flat', image=self.imgwave, compound='left', anchor='w').pack(side='top', fill='x')
		
		self.hide()
		self.theme(self.frame, bg=self.hue, fg=self.neon)

class FileMenu2(Menu):
	def __init__(self, *args, **kwargs):
		Menu.__init__(self, tearoff=0, *args, **kwargs)

		self.add_command(label="Zeta", command=lambda: Zeta.System.OS.open(Zeta.System.Path.Core.ZETA))
		self.add_command(label="X", command=lambda: Zeta.System.OS.open(Zeta.System.Path.Core.X))
		self.add_separator()
		self.add_command(label="# Scraps")
		self.add_separator()
		#subedit = Menu(self, tearoff=0)
		#self.add_cascade(label="Edit", menu=subedit, command=menu_edit)
		# self.imgterm = Zeta.Image.Icon.Load('termbw', 'bw').image
		# self.add_command(label="Terminal", image=self.imgterm, compound='left', anchor='w', command=lambda: (self.controller.toggle_sidebar(), Zeta.System.OS.terminal(self.fullpath)))
		# self.imgdetach = Zeta.Image.Icon.Load('windowbw', 'bw').image
		# self.add_command(label="Detach", image=self.imgdetach, compound='left', anchor='w', command=self.menu_detach)
		# self.tree.bind("<Button-3>", lambda event: menubar.post(event.x_root, event.y_root))
