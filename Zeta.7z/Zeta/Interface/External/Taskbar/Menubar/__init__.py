from .Program import ProgramMenu
from .Hacking import HackingMenu
from .File import FileMenu
from .Network import NetworkMenu