import Zeta
from Zeta.Panel import *

class Taskbar2(Toplevel):
	def __init__(self, Workspace, *args, **kwargs):
		Toplevel.__init__(self, *args, **kwargs)
		self.attributes('-topmost', True)
		self.attributes('-alpha', Zeta.Setting.opacityneon)
		self.title('Task bar')
		width = Zeta.System.Size.Screen.width
		height = Zeta.System.Size.taskbar
		self.geometry(f"{width}x{height}+0-0")
		self.overrideredirect(1)

		self.imgmenu=Zeta.Image.Icon.Load(icon='menuw', icontype='bw').image
		self.imghdd=Zeta.Image.Icon.Load(icon='hddw', icontype='bw').image
		self.corner=Zeta.Image.Icon.Load(icon='cornerw', icontype='bw').image
		self.imgex=Zeta.Image.Icon.Load(icon='mathw', icontype='bw').image
		self.imgplay=Zeta.Image.Icon.Load(icon='playw', icontype='bw').image
		self.imgtext=Zeta.Image.Icon.Load(icon='textw', icontype='bw').image

		self.placeholder = ''
		self.InitWindow()

		self.frame1 = Frame(self)
		self.frame1.pack(side='left', fill='both')
		self.frame2 = Frame(self)
		self.frame2.pack(side='right', fill='both')

		Button2(self.frame1, image=self.imgmenu, side='left', fill='y', hover=self.placeholder, toggle=self.placeholder, geometry='top')
		Label(self.frame1, text='# [ ').pack(side='left', fill='y')
		Button2(self.frame1, text='META', side='left', fill='y', hover=self.placeholder, toggle=self.placeholder, geometry='top')
		Button2(self.frame1, text='Root', side='left', fill='y', hover=self._Root, toggle=self._Root, geometry='top')
		Button2(self.frame1, text='Search', side='left', fill='y', hover=self._Search, toggle=self._Search, geometry='top')
		Button2(self.frame1, text='Link', side='left', fill='y', hover=self._Link, toggle=self._Link, geometry='top')
		Label(self.frame1, text=' ]').pack(side='left', fill='y')
		Button2(self.frame1, text='[Note]', side='left', fill='y', hover=self.placeholder, toggle=self.placeholder, geometry='top')
		Button2(self.frame1, text='[Reference]', side='left', fill='y', hover=self._Reference, toggle=self._Reference, geometry='top')
		Button2(self.frame1, text='[Network]', side='left', fill='y', hover=self._Network, toggle=self._Network, geometry='top')

		Button2(self.frame2, image=self.imgmenu, command= lambda: Workspace.hide(Workspace.active), side='right', fill='y', hover=self.placeholder, toggle=self.placeholder, geometry='top')
		btnairlock = Button2(self.frame2, text='Ω[ Airlock ]', side='right', fill='y', hover=self.placeholder, toggle=self.placeholder, geometry='top')
		btnscraps = Button2(self.frame2, text='Σ[ Scraps ]', side='right', fill='y', hover=self.placeholder, toggle=self.placeholder, geometry='top')
		Label(self.frame2, text=' ]').pack(side='right', fill='y')
		btnraw = Button2(self.frame2, text='Raw', side='right', fill='y', hover=self._Raw, toggle=self._Raw, geometry='top')
		btnfile = Button2(self.frame2, text='File', side='right', fill='y', hover=self._File, toggle=self._File, geometry='top')
		Label(self.frame2, text='Δ[ ').pack(side='right', fill='y')
		Button2(self.frame2, text=' Journal', image=self.imghdd, compound='left', side='right', fill='y', hover=self.placeholder, toggle=self.placeholder, geometry='top')
		Button2(self.frame2, image=self.imgplay, side='right', fill='y', hover=self.placeholder, toggle=self.placeholder, geometry='top')
		Button2(self.frame2, image=self.imgtext, side='right', fill='y', hover=self.placeholder, toggle=self.placeholder, geometry='top')
		Button2(self.frame2, image=self.imgex, side='right', fill='y', hover=self.placeholder, toggle=self.placeholder, geometry='top')

		self.theme(self, bg='#000000', fg='#ffffff')
		# btnscraps['foreground'] = Zeta.Color.Neon('green').hex
		# btnfile['foreground'] = Zeta.Color.Neon('yellow').hex
		# btnraw['foreground'] = Zeta.Color.Neon('yellow').hex
		# btnairlock['foreground'] = Zeta.Color.Neon('red').hex

	def InitWindow(self):
		x = Window(mode='border', color2='white')
		x.attributes('-topmost', True)
		x.attributes('-alpha', Zeta.Setting.opacity)
		Button(x.frame, text=' Requirement', relief='flat', anchor='w').pack(side='top', fill='x')
		Button(x.frame, text=' Specification', relief='flat', anchor='w').pack(side='top', fill='x')
		Frame(x.frame, highlightbackground=x.neon, highlightthickness=1).pack(side='top', fill='x')
		x.theme(x.frame, fg='#ffffff', bg=x.hue)
		self._Root = x

		x = Window(mode='border', color2='white')
		x.attributes('-topmost', True)
		x.attributes('-alpha', Zeta.Setting.opacity)
		Button(x.frame, text=' Keyword', relief='flat', anchor='w').pack(side='top', fill='x')
		Button(x.frame, text=' Variant', relief='flat', anchor='w').pack(side='top', fill='x')
		Frame(x.frame, highlightbackground=x.neon, highlightthickness=1).pack(side='top', fill='x')
		x.theme(x.frame, fg='#ffffff', bg=x.hue)
		self._Search = x

		x = Window(mode='border', color2='white')
		x.attributes('-topmost', True)
		x.attributes('-alpha', Zeta.Setting.opacity)
		Button(x.frame, text=' Main', relief='flat', anchor='w').pack(side='top', fill='x')
		Button(x.frame, text=' Repository', relief='flat', anchor='w').pack(side='top', fill='x')
		Frame(x.frame, highlightbackground=x.neon, highlightthickness=1).pack(side='top', fill='x')
		x.theme(x.frame, fg='#ffffff', bg=x.hue)
		self._Link = x

		x = Window(mode='border', color2='white')
		x.attributes('-topmost', True)
		x.attributes('-alpha', Zeta.Setting.opacity)
		Button(x.frame, text=' Documentation', relief='flat', anchor='w').pack(side='top', fill='x')
		Button(x.frame, text=' Book', relief='flat', anchor='w').pack(side='top', fill='x')
		Frame(x.frame, highlightbackground=x.neon, highlightthickness=1).pack(side='top', fill='x')
		x.theme(x.frame, fg='#ffffff', bg=x.hue)
		self._Reference = x

		x = Window(mode='border', color2='white')
		x.attributes('-topmost', True)
		x.attributes('-alpha', Zeta.Setting.opacity)
		Button(x.frame, text=' Articles', relief='flat', anchor='w').pack(side='top', fill='x')
		Button(x.frame, text=' Forums', relief='flat', anchor='w').pack(side='top', fill='x')
		Button(x.frame, text=' Q & A', relief='flat', anchor='w').pack(side='top', fill='x')
		Button(x.frame, text=' Tutorial', relief='flat', anchor='w').pack(side='top', fill='x')
		Frame(x.frame, highlightbackground=x.neon, highlightthickness=1).pack(side='top', fill='x')
		Button(x.frame, text=' Anonymous', relief='flat', anchor='w').pack(side='top', fill='x')
		Frame(x.frame, highlightbackground=x.neon, highlightthickness=1).pack(side='top', fill='x')
		x.theme(x.frame, fg='#ffffff', bg=x.hue)
		self._Network = x

		x = Window(mode='border', color2='white')
		x.attributes('-topmost', True)
		x.attributes('-alpha', Zeta.Setting.opacity)
		Button(x.frame, text=' Scraps', relief='flat', anchor='w').pack(side='top', fill='x')
		Button(x.frame, text=' Sandbox', relief='flat', anchor='w').pack(side='top', fill='x')
		Frame(x.frame, highlightbackground=x.neon, highlightthickness=1).pack(side='top', fill='x')
		x.theme(x.frame, fg='#ffffff', bg=x.hue)
		self._File = x

		x = Window(mode='border', color2='white')
		x.attributes('-topmost', True)
		x.attributes('-alpha', Zeta.Setting.opacity)
		Button(x.frame, text=' Resource', relief='flat', anchor='w').pack(side='top', fill='x')
		Button(x.frame, text=' Download', relief='flat', anchor='w').pack(side='top', fill='x')
		Frame(x.frame, highlightbackground=x.neon, highlightthickness=1).pack(side='top', fill='x')
		x.theme(x.frame, fg='#ffffff', bg=x.hue)
		self._Raw = x