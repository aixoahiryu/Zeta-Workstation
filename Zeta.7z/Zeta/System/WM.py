import Zeta

def transparent(root):
	if Zeta.System.OS.Windows: root.wm_attributes("-transparentcolor", "white")
	if Zeta.System.OS.Linux: root.configure(bg='')
	if Zeta.System.OS.Mac: (root.wm_attributes("-transparent", True), root.config(bg='systemTransparent'))

def toggle(master):
	if master.on:
		for i in master.toggle: i.hide()
	else:
		for i in master.toggle: i.show()
	
	master.on = not master.on

def toggle_bind(master, child):
	if not hasattr(master, 'toggle'):
		master.toggle = []
		master.on = False
		master.bind('<Button-1>', lambda e: toggle(master))

	if isinstance(child, list): master.toggle = child
	else: master.toggle.append(child)


class Workspace():
	def __init__(self, panel):
		# Panel = {'System': {'taskbar': '', 'wallpaper': ''}, 'File': {'root': ''}, 'Network': {'root': ''}, 'Lounge': {'root': ''}}
		self.panel = panel
		self.active = ''
		self.hidden = False

	def toggle(self, group=''):
		if self.hidden:
			if group=='': self.show(self.active)
			else: self.show(group)
			self.show('System')
		else:
			self.hide()
		self.hidden = not self.hidden

	def hide(self, group=''):
		if group=='':
			for g in self.panel.values():
				for w in g.values(): w.hide()
		else:
			for w in self.panel[group].values(): w.hide()

	def show(self, group=''):
		if group=='':
			for g in self.panel.values():
				for w in g.values(): w.show()
		else:
			for w in self.panel[group].values(): w.show()
			self.active = group