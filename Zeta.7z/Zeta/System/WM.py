import Zeta

def transparent(root):
	if Zeta.System.OS.Windows: root.wm_attributes("-transparentcolor", "white")
	if Zeta.System.OS.Linux: root.configure(bg='')
	if Zeta.System.OS.Mac: (root.wm_attributes("-transparent", True), root.config(bg='systemTransparent'))

def toggle(master):
	if master.on:
		for i in master.toggle: i.hide()
	else:
		for i in master.toggle: i.show()
	
	master.on = not master.on

def toggle_bind(master, child):
	master.toggle = []
	master.on = False

	if isinstance(child, list): master.toggle = child
	else: master.toggle.append(child)
	master.bind('<Button-1>', lambda e: toggle(master))