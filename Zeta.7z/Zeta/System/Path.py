import Zeta
import inspect
import os

class Core():
	ZLCORE = r'D:\MEGA\ZL-Core'
	ZETA = os.path.split(inspect.getfile(Zeta))[0]
	X = os.path.join(os.path.split(ZETA)[0], 'X')
	downstream = r'D:\ZL-Core'

	Sidebar = r'D:\ZL-Core\Toolbar\_\[ Sidebar ]'
	Planner = r'D:\MEGA\ZL-Core\Commit\_'

class Browser():
	main = r'C:\Users\Administrator\AppData\Local\Chromium\Application\chrome.exe' # --disk-cache-size=0 --force-dark-mode --media-cache-size=0 --profile-directory="Default" --process-per-site
	experiment = r'D:\Tools\Vivaldi\Application\vivaldi.exe' # --disk-cache-size=0 --force-dark-mode --media-cache-size=0 --process-per-site
	lite = r'C:\Program Files\Links\links-g.exe'

class Scraps():
	path = r'D:\Scraps'

class Resource():
	mp3 = r'D:\MP3'
	video = r'D:\Temp'

	data = r'D:\Data'
	politics = r'C:\Users\Administrator\Desktop\P'
	shared = r'D:\Shared'

	furry = r'D:\Furry\Archive'