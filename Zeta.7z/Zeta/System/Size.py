from tkinter import *

taskbar = 30
topbar = 50

class Screen():
	width = 1366
	height = 768

class Window():
	main = [920, 740]
	side = [444, 740]
	mpv = [444, 270]
	npp = [444, 424]
	aimp = [444, 50]