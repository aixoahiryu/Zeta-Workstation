import Zeta
from Zeta.Panel import *
import tkinter as tk
from tkinter.scrolledtext import ScrolledText
from tkinter.filedialog import askopenfilename, asksaveasfilename

class TextBox(Frame):
	def __init__(self, master, file='', darkmode=True, richtext=False, color2='', neonmode=False):
		Frame.__init__(self, master)
		self.pack(fill='both', expand=True)
		# self.text = ScrolledText(self, height=30, wrap='none', tabs='0.5c', undo=True, setgrid=True, pady=2, padx=3, font=("Lucida Console", 8, "normal"))
		# self.text.pack(fill='both', expand=True) # in_=
		textContainer = tk.Frame(self)
		self.text = tk.Text(textContainer, wrap="none", undo=True, tabs='0.5c', font=("Lucida Console", 8, "normal"))
		textVsb = tk.Scrollbar(textContainer, orient="vertical", command=self.text.yview)
		textHsb = tk.Scrollbar(textContainer, orient="horizontal", command=self.text.xview)
		self.text.configure(yscrollcommand=textVsb.set, xscrollcommand=textHsb.set)
		self.text.grid(row=0, column=0, sticky="nsew")
		textVsb.grid(row=0, column=1, sticky="ns")
		textHsb.grid(row=1, column=0, sticky="ew")
		textContainer.grid_rowconfigure(0, weight=1)
		textContainer.grid_columnconfigure(0, weight=1)
		textContainer.pack(side="top", fill="both", expand=True)

		self.read(file)

		self.bind_all('<Control-o>', lambda e: self.open())
		self.bind_all('<Control-e>', lambda e: self.edit(self.file))
		self.bind_all('<w>', lambda e: self.wrap())
		self.bind_all('<r>', lambda e: self.readonly())

	def open(self):
		path = askopenfilename() #filetypes=validFileTypes, initialdir=initialdir
		self.read(path)

	def read(self, path):
		if path=='': return

		self.text['state'] = 'normal'
		self.file = path
		with open(path, 'r+', encoding='utf-8') as target:
			content = target.read()
			self.text.delete('1.0', 'end')
			self.text.insert('end', content)
		self.text['state'] = 'disabled'

	def edit(self, path):
		if path!='': Zeta.System.OS.edit(path)

	def wrap(self):
		if self.text['wrap']=='none': self.text['wrap'] = 'word'
		else: self.text['wrap'] = 'none'

	def readonly(self):
		if self.text['state']=='normal': self.text['state'] = 'disabled'
		else: self.text['state'] = 'normal'



class TextPanel(Window):
	def __init__(self, mode='basic', color2='green', file='', *args, **kargs):
		Window.__init__(self, mode=mode, color2=color2, *args, **kargs)
		self.geometry("444x555")
		maintext = TextBox(self.frame, file=file)

		self.theme(self.frame, fg=self.neon, bg=self.hue)

if __name__ == '__main__':
	TextPanel(title='Text panel', file=r'D:\_\Interface\Void.py').mainloop()