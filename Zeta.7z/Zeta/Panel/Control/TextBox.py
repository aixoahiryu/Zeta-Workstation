import Zeta
from Zeta.Panel import *
import tkinter as tk
from tkinter.scrolledtext import ScrolledText
from tkinter.filedialog import askopenfilename, asksaveasfilename

class TextBox(Frame):
	def __init__(self, master, file='', darkmode=True, richtext=False, color2='', neonmode=False):
		Frame.__init__(self, master)
		self.pack(fill='both', expand=True)
		# self.text = ScrolledText(self, height=30, wrap='none', tabs='0.5c', undo=True, setgrid=True, pady=2, padx=3, font=("Lucida Console", 8, "normal"))
		# self.text.pack(fill='both', expand=True) # in_=
		textContainer = tk.Frame(self)
		self.text = tk.Text(textContainer, wrap="none", undo=True, tabs='0.5c', font=("Lucida Console", 8, "normal"))
		textVsb = tk.Scrollbar(textContainer, orient="vertical", command=self.text.yview)
		textHsb = tk.Scrollbar(textContainer, orient="horizontal", command=self.text.xview)
		self.text.configure(yscrollcommand=lambda f, l: self.autoscroll(textVsb, f, l), xscrollcommand=lambda f, l:self.autoscroll(textHsb, f, l))
		self.text.grid(row=0, column=0, sticky="nsew")
		textVsb.grid(row=0, column=1, sticky="ns")
		textHsb.grid(row=1, column=0, sticky="ew")
		textContainer.grid_rowconfigure(0, weight=1)
		textContainer.grid_columnconfigure(0, weight=1)
		textContainer.pack(side="top", fill="both", expand=True)

		if file!='': self.read(file)

		self.text.bind('<Control-o>', lambda e: self.open())
		self.text.bind('<Control-e>', lambda e: self.edit(self.path))
		self.text.bind('<Control-r>', lambda e: self.read(self.path))
		self.text.bind('<Control-w>', lambda e: self.winfo_toplevel().close())
		self.text.bind('<Alt-r>', lambda e: self.readonly())
		self.text.bind('<Control-p>', lambda e: (self.winfo_toplevel().clipboard_clear(),self.winfo_toplevel().clipboard_append(self.path),self.winfo_toplevel().update()))
		self.winfo_toplevel().bind_all('<w>', lambda e: self.wrap())
		self.winfo_toplevel().bind_all('<l>', lambda e: self.os('lite'))
		self.winfo_toplevel().bind_all('<b>', lambda e: self.os('browser'))
		self.winfo_toplevel().bind_all('<e>', lambda e: self.os('editor'))
		self.winfo_toplevel().bind_all('<s>', lambda e: self.os('sidebar'))

		menubar = Menu(self, tearoff=0)
		menubar.add_command(label="Launch", command=self.os)
		menubar.add_command(label="Edit", command=lambda: self.edit(self.path))
		menubar.add_separator()
		menubar.add_command(label="Browser", command=lambda: self.os('browser'))
		menubar.add_command(label="Lite", command=lambda: self.os('lite'))
		menubar.add_command(label="Editor", command=lambda: self.os('editor'))
		menubar.add_command(label="Sidebar", command=lambda: self.os('sidebar'))
		menubar.add_separator()
		menubar.add_command(label="Wordwrap", command=self.wrap)
		menubar.add_command(label="Read-only", command=self.readonly)
		self.text.bind("<Button-3>", lambda event: menubar.post(event.x_root, event.y_root))

	def autoscroll(self, sbar, first, last):
		first, last = float(first), float(last)
		if first <= 0 and last >= 1:
			sbar.grid_remove()
		else:
			sbar.grid()
		sbar.set(first, last)

	def open(self):
		path = askopenfilename() #filetypes=validFileTypes, initialdir=initialdir
		self.read(path)

	def read(self, path):
		if path=='': return

		self.text['state'] = 'normal'
		self.path = path
		with open(path, 'r+', encoding='utf-8') as target:
			content = target.read()
			self.text.delete('1.0', 'end')
			self.text.insert('end', content)
		self.text['state'] = 'disabled'

	def edit(self, path):
		if path!='': Zeta.System.OS.edit(path)

	def wrap(self):
		if self.text['state']=='normal': return
		if self.text['wrap']=='none': self.text['wrap'] = 'word'
		else: self.text['wrap'] = 'none'

	def readonly(self):
		if self.text['state']=='normal': self.text['state'] = 'disabled'
		else: self.text['state'] = 'normal'

	def os(self, program=''):
		if self.text['state']=='normal': return
		Zeta.System.OS.launch(self.text.selection_get(), program)


class TextPanel(Window):
	def __init__(self, mode='basic', color2='green', file='', *args, **kargs):
		Window.__init__(self, mode=mode, color2=color2, *args, **kargs)
		self.geometry("444x333")
		maintext = TextBox(self.frame, file=file)

		self.theme(self.frame, fg=self.neon, bg=self.hue)

if __name__ == '__main__':
	TextPanel(title='Text panel', file=r'D:\_\Interface\Void.py').mainloop()