import Zeta
from tkinter import *

class Button2(Button):
	def __init__(self, master, side='left', fill='x', relief='flat', hover='', toggle='', geometry='right', anchor='w', anchor2='widget', *args, **kwargs):
		Button.__init__(self, master, relief=relief, anchor=anchor, *args, **kwargs)
		self.pack(side=side, fill=fill)
		self.Htarget = hover
		self.Ttarget = toggle

		if hover!='': Zeta.System.WM.hover_bind(self, self.Htarget, geometry=geometry, anchor=anchor2)
		if toggle!='': Zeta.System.WM.toggle_bind(self, self.Ttarget, geometry=geometry, anchor=anchor2)