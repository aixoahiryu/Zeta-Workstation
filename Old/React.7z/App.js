import React, { useState, useEffect } from 'react';
import { AppRegistry, useColorScheme } from 'react-native';
import { Provider as PaperProvider } from 'react-native-paper';
import { DarkTheme,DefaultTheme,NavigationContainer } from '@react-navigation/native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { EventEmitter } from 'events';

import { name as appName } from './app.json';
import App from './src/App';
import TabContainer from './src/nav/bottom-tab';
import DefaultData from './database/default';

export default function Main() {
	const [isDark, setIsDark] = useState( async () => {
        AsyncStorage.getItem('darkmode-enabled').then( (data) => setIsDark(JSON.parse(data)) );
      } );

	useEffect(() => {
		AsyncStorage.getItem('background-hour').then( (data) => {
           	if (data == null) { DefaultData() }
        } );

		setInterval( () => {
            AsyncStorage.getItem('darkmode-enabled').then( (data) => {
            	if (data != isDark) { setIsDark(JSON.parse(data)) }
            } );
        }, 1000);
	});
	const emitter1 = new EventEmitter();
	emitter1.on('theme-change', () => {
		AsyncStorage.getItem('darkmode-enabled').then( (data) => setIsDark(JSON.parse(data)) );
	});
	

  return (
    <PaperProvider theme={{ version: 2 }}>
	    <NavigationContainer theme={isDark ? DarkTheme : DefaultTheme }>
	      <TabContainer />
	    </NavigationContainer>
    </PaperProvider>
  );
}

AppRegistry.registerComponent(appName, () => Main);
